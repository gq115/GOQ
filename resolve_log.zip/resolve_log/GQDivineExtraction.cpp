#include "GQDivineExtraction.h"
using namespace std;


GQDivineExtraction::GQDivineExtraction()
{
}


GQDivineExtraction::~GQDivineExtraction()
{
}


bool GQDivineExtraction::LoadExtractionItemData() {
	if (!m_tblExtractionItem.Open("data\\ExtractionItem.dat"))
	{
		return FALSE;
	}

	return TRUE;
}

void GQDivineExtraction::GQWrite() {
	printf("Begin Write ExtractionItem.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/ExtractionItem.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ExtractionItem.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	ST_EXTRACTIONITEM	*pExt = NULL;
	oFile << "bitemid " << "," << "extraction " << "," 
		<< "Ratio1 " << "," << "product1 " << "," << "product1min " << "," 
		<< "product1max " << "," << "Ratio2 " << "," << "product2 " << "," 
		<< "product2min " << "," << "product2max " << "," << "Ratio3 " << "," 
		<< "product3 " << "," << "product3min " << "," << "product3max" << "\n";
	state = m_tblExtractionItem.GetFirstItem();
	while (pData = m_tblExtractionItem.GetNextItem(state)) {
		pExt = (ST_EXTRACTIONITEM *)pData;
		if (pExt->nItemID <= -1)
			continue;
		if (pExt == NULL) {
			continue;
		}
		oFile << pExt->nItemID << ",";
		oFile << pExt->nAbstractionItemID << ",";
		oFile << pExt->wRatio[0] << ",";
		oFile << pExt->nProductItemID[0] << ",";
		oFile << pExt->wProductMin[0] << ",";
		oFile << pExt->wProductMax[0] << ",";
		oFile << pExt->wRatio[1] << ",";
		oFile << pExt->nProductItemID[1] << ",";
		oFile << pExt->wProductMin[1] << ",";
		oFile << pExt->wProductMax[1] << ",";
		oFile << pExt->wRatio[2] << ",";
		oFile << pExt->nProductItemID[2] << ",";
		oFile << pExt->wProductMin[2] << ",";
		oFile << pExt->wProductMax[2] << "\n";
	}

	oFile.close();
	printf("End Write ExtractionItem.CSV\n");
}
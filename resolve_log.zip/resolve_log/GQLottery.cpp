#include "GQLottery.h"
using namespace std;


GQLottery::GQLottery()
{
}


GQLottery::~GQLottery()
{
}


bool GQLottery::LoadLotteryData() {
	STATE	state;
	LotteryTable *pTable;
	DWORD	dwPrevTotalRate;
	int		nCurItemID;

	if (!m_tblLottery.Open("data\\Lottery.dat"))
		return FALSE;

	state = m_tblLottery.GetFirstItem();

	nCurItemID = 0;
	dwPrevTotalRate = 0;
	while (pTable = (LotteryTable *)m_tblLottery.GetNextItem(state))
	{
		if (nCurItemID != pTable->nItemID)
		{
			nCurItemID = pTable->nItemID;
			dwPrevTotalRate = pTable->dwRate;
			continue;
		}

		//20131017 ����ȣ(���� : ���Ƿ� Ȯ�� 1000000�������� ���濡 ���� �ڷ��� ����)
		pTable->dwRate += dwPrevTotalRate;
		dwPrevTotalRate = pTable->dwRate;
	}

	// 20140123 �߰�(����ȣ: �̴ϰ��� ���Ըӽ� ��� ������ �ε�)
	LotteryRateTable *pRateTable;
	WORD	wCurrInstance = 0;
	WORD	wLotteryRate = 0;

	if (!m_tblLotteryRate.Open("data\\LotteryRate.dat"))
		return FALSE;

	state = m_tblLotteryRate.GetFirstItem();

	//Rate Converting
	dwPrevTotalRate = 0;
	while (pRateTable = (LotteryRateTable *)m_tblLotteryRate.GetNextItem(state))
	{
		if (wCurrInstance != pRateTable->wInstance)
		{
			wCurrInstance = pRateTable->wInstance;
			dwPrevTotalRate = pRateTable->dwRate;
			continue;
		}
		pRateTable->dwRate += dwPrevTotalRate;
		dwPrevTotalRate = pRateTable->dwRate;
	}

	return TRUE;
}

void GQLottery::GQWrite() {
	printf("Begin Write Lottery.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Lottery.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("fixed.CSV Lottery error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	LotteryTable	*pLTable = NULL;
	oFile << "BitemID " << "," << "ResultID " << "," << "Amount " << "," 
		<< "Rate " << "," << "instancetype " << "," << "message " << "," 
		<< "LimitedCount" << "\n";
	state = m_tblLottery.GetFirstItem();
	while (pData = m_tblLottery.GetNextItem(state)) {
		pLTable = (LotteryTable *)pData;
		if (pLTable->nItemID <= -1)
			continue;
		if (pLTable == NULL) {
			continue;
		}
		oFile << pLTable->nItemID << ",";
		oFile << pLTable->nResultID << ",";
		oFile << pLTable->wAmount << ",";
		oFile << pLTable->dwRate << ",";
		oFile << pLTable->wInstance << ",";
		oFile << (int)pLTable->cMessage << ",";
		oFile << pLTable->wLimitedCount << "\n";
	}

	oFile.close();
	printf("End Write Lottery.CSV\n");




	printf("Begin Write LotteryRate.CSV\n");
	oFile.open("dataCSV/LotteryRate.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("fixed.CSV LotteryRate error!!!\n");
		return;
	}

	LotteryRateTable	*pRTabl = NULL;
	state = m_tblLotteryRate.GetFirstItem();
	oFile << "Lottery_Rate" << "," << "Rate" << "," << "instancetype" << "\n";
	while (pData = m_tblLotteryRate.GetNextItem(state)) {
		pRTabl = (LotteryRateTable *)pData;
		if (pRTabl == NULL) {
			continue;
		}
		oFile << pRTabl->wLotteryRate << ",";
		oFile << pRTabl->dwRate << ",";
		oFile << pRTabl->wInstance << "\n";
	}

	oFile.close();
	printf("End Write LotteryRate.CSV\n");
}
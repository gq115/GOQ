#include "GQPolymorph.h"
using namespace std;


GQPolymorph::GQPolymorph()
{
}


GQPolymorph::~GQPolymorph()
{
}

void GQPolymorph::GQOpen() {
	printf("Begin Load PolyMorph.dat\n");
	if (m_cPolymorph.Open("data\\PolyMorph.dat")) {
		printf("End Load PolyMorph.dat\n");
	}
	else {
		printf("Error NewGrowth PolyMorph.dat\n");
	}
	return;
}

void GQPolymorph::GQWrite() {
	printf("Begin Write PolyMorph.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/PolyMorph.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("PolyMorph.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	struct POLYMORPH_BASE	*pPoly = NULL;
	oFile << "pCode " << "," << "npcCode " << "," << "MoveType " << "," << "MoveSpeed " << "," << "option1 " << "," << "value1 " << "," << "option2 " << "," << "value2 " << "," << "option3 " << "," << "value3 " << "," << "option4 " << "," << "value4 " << "," << "option5 " << "," << "value5 " << "," << "Skill1 " << "," << "SkillLevel1 " << "," << "Skill2 " << "," << "SkillLevel2 " << "," << "Skill3 " << "," << "SkillLevel3 " << "," << "Skill4 " << "," << "SkillLevel4 " << "," << "Skill5 " << "," << "SkillLevel5" << "\n";
	state = m_cPolymorph.GetFirstItem();
	while (pData = m_cPolymorph.GetNextItem(state)) {
		pPoly = (struct POLYMORPH_BASE *)pData;
		if (pPoly->wPCode <= -1)
			continue;
		if (pPoly == NULL) {
			continue;
		}
		oFile << pPoly->wPCode << ",";
		oFile << pPoly->wNPCCode << ",";
		oFile << pPoly->wMoveType << ",";
		oFile << pPoly->wMoveSpeed << ",";
		oFile << pPoly->opt[0].wOption << ",";
		oFile << pPoly->opt[0].wValue << ",";
		oFile << pPoly->opt[1].wOption << ",";
		oFile << pPoly->opt[1].wValue << ",";
		oFile << pPoly->opt[2].wOption << ",";
		oFile << pPoly->opt[2].wValue << ",";
		oFile << pPoly->opt[3].wOption << ",";
		oFile << pPoly->opt[3].wValue << ",";
		oFile << pPoly->opt[4].wOption << ",";
		oFile << pPoly->opt[4].wValue << ",";

		oFile << pPoly->skill[0].wSkillID << ",";
		oFile << pPoly->skill[0].wSkillLevel << ",";
		oFile << pPoly->skill[1].wSkillID << ",";
		oFile << pPoly->skill[1].wSkillLevel << ",";
		oFile << pPoly->skill[2].wSkillID << ",";
		oFile << pPoly->skill[2].wSkillLevel << ",";
		oFile << pPoly->skill[3].wSkillID << ",";
		oFile << pPoly->skill[3].wSkillLevel << ",";
		oFile << pPoly->skill[4].wSkillID << ",";
		oFile << pPoly->skill[4].wSkillLevel << "\n";
	}

	oFile.close();
	printf("End Write PolyMorph.CSV\n");
}
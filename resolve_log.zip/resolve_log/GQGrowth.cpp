#include "GQGrowth.h"
using namespace std;


GQGrowth::GQGrowth()
{
}


GQGrowth::~GQGrowth()
{
}


//���� growth.dat
void GQGrowth::makegindex()
{
	for (int i = 0; i < MAX_GROWTHITEM; i++)
	{
		if (growthitemlist[i].bitemid >= 0 && growthitemlist[i].bitemid < MAX_BASE_ITEM_CODE) // <djelee> : 2011.04.08 : üũ ���� ���� 
			growthitemindex[growthitemlist[i].bitemid] = i;
	}
}
void GQGrowth::LoadGrowth() {
	long rc = -1;
	DBG_UNREFERENCED_LOCAL_VARIABLE(rc);

	HANDLE hRFile = CreateFile("data/growth.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		DWORD dwTemp;
		ZeroMemory(growthitemlist, sizeof(growthitemlist));
		ReadFile(hRFile, growthitemlist, sizeof(growthitemlist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);
		makegindex();
	}
}
void GQGrowth::WriteGrowth() {
	printf("Begin Write growth.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/growth.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("growth.CSV open error!!!\n");
		return;
	}
	/*oFile << "bitemid " << "," << "lvl " << "," << "nextexp " << "," 
		<< "nextbitem " << "," << "addopt1 " << "," << "addopt2 " << "," 
		<< "addopt3 " << "," << "addopt4 " << "," << "addskill1 " << "," 
		<< "skilllevel1 " << "," << "addskill2 " << "," << "skilllevel2" << "\n";*/

	for (int i = 0; i < MAX_GROWTHITEM; i++) {
		if (growthitemlist[i].bitemid <= 0) {
			continue;
		}

		oFile << growthitemlist[i].bitemid << ",";
		oFile << growthitemlist[i].lvl << ",";
		oFile << growthitemlist[i].nextexp << ",";
		oFile << growthitemlist[i].nextbitemid << ",";
		oFile << growthitemlist[i].addoption[0] << ",";
		oFile << growthitemlist[i].addoption[1] << ",";
		oFile << growthitemlist[i].addoption[2] << ",";
		oFile << growthitemlist[i].addoption[3] << ",";
		oFile << growthitemlist[i].addskill[0] << ",";
		oFile << growthitemlist[i].addskill[1] << ",";
		oFile << growthitemlist[i].skilllevel[0] << ",";
		oFile << growthitemlist[i].skilllevel[1] << "\n";
	}

	oFile.close();
	printf("End Write growth.CSV\n\n");
}

void GQGrowth::GQOpen() {
	printf("Begin Load NewGrowth.dat\n");
	if (m_cNewGrowth.Open("data\\NewGrowth.dat")) {
		printf("End Load NewGrowth.dat\n");
	}
	else {
		printf("Error NewGrowth fixed.dat\n");
	}
	return;
}

void GQGrowth::GQWrite() {
	printf("Begin Write NewGrowth.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/NewGrowth.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("NewGrowth.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	SGrowth	*pGrowth = NULL;
	oFile << "bitemid " << "," << "lvl " << "," << "nextexp " << ","
		<< "nextbitem " << "," << "addopt1 " << "," << "addopt2 " << ","
		<< "addopt3 " << "," << "addopt4 " << "," << "addskill1 " << ","
		<< "skilllevel1 " << "," << "addskill2 " << "," << "skilllevel2" << "\n";
	state = m_cNewGrowth.GetFirstItem();
	while (pData = m_cNewGrowth.GetNextItem(state)) {
		pGrowth = (SGrowth *)pData;
		if (pGrowth->bitemid <= -1)
			continue;
		if (pGrowth == NULL) {
			continue;
		}
		oFile << pGrowth->bitemid << ",";
		oFile << pGrowth->lvl << ",";
		oFile << pGrowth->nextexp << ",";
		oFile << pGrowth->nextbitemid << ",";
		oFile << pGrowth->addoption[0] << ",";
		oFile << pGrowth->addoption[1] << ",";
		oFile << pGrowth->addoption[2] << ",";
		oFile << pGrowth->addoption[3] << ",";
		oFile << pGrowth->addskill[0] << ",";
		oFile << pGrowth->skilllevel[0] << ",";
		oFile << pGrowth->addskill[1] << ",";
		oFile << pGrowth->skilllevel[1] << "\n";
	}

	oFile.close();
	printf("End Write NewGrowth.CSV\n");
}
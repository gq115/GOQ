#include "GQItemShop.h"
using namespace std;


GQItemShop::GQItemShop()
{
}


GQItemShop::~GQItemShop()
{
}



void GQItemShop::GQOpen() {
	printf("Begin Load ItemShop.dat\n");
	if (m_cNewItemShopList.Open("data\\ItemShop.dat")) {
		printf("End Load ItemShop.dat\n");
	}
	else {
		printf("Error NewGrowth ItemShop.dat\n");
	}
	return;
}

void GQItemShop::GQWrite() {
	printf("Begin Write ItemShop.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/ItemShop.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ItemShop.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	struct SNewItemShopList	*pShop = NULL;
	oFile << "GroupID " << "," << "ItemID " << ","  
		<< "SalePercent " << "," << "ItemShop50 " << "," << "ItemShop57 " << ","
		<< "ItemShop58" << "\n";
	state = m_cNewItemShopList.GetFirstItem();
	while (pData = m_cNewItemShopList.GetNextItem(state)) {
		pShop = (struct SNewItemShopList *)pData;
		if (pShop->nItemID <= -1)
			continue;
		if (pShop == NULL) {
			continue;
		}
		oFile << (int)pShop->btGroupID << ",";
		oFile << pShop->nItemID << ",";
		oFile << pShop->nSalePercent << ",";
		oFile << (int)pShop->btShop50 << ",";
		oFile << (int)pShop->btShop57 << ",";
		oFile << (int)pShop->btShop58 << "\n";
	}

	oFile.close();
	printf("End Write ItemShop.CSV\n");
}
#include "GQItem.h"
using namespace std;



GQItem::GQItem()
{
}


GQItem::~GQItem()
{
}


//���� BaseItem.dat
int lowbound[7] = { -15,-15,-15,0,-10,-15,0 };
int highbound[7] = { 5,5,5,35,10,5,10 };
void GQItem::makeirange()		//lowhigh�� ����
{
	for (int k = 0; k < 7; k++)
	{

		for (int j = 0; j < MAX_LEVEL; j++)

		{
			int n_lev = j;
			int ilvlmin, ilvlmax;

			ilvlmin = n_lev + lowbound[k];
			ilvlmax = n_lev + highbound[k];						//������ ���ü� �ִ� ������ -15 ,+ 5

			if (ilvlmin < 0)
			{
				ilvlmin = 0;
			}
			else if (ilvlmin > 99)
			{
				ilvlmin = 99;
			}

			if (ilvlmax < 0)
			{
				ilvlmax = 0;
			}
			else if (ilvlmax > 99)
			{
				ilvlmax = 99;
			}

			int i = 0;									//low�����ϱ�
			while (ilvllist[k][ilvlmin + i] == -1)		//�ش� lvl�� ���� ��� �ǳʶٱ�
			{
				i++;
				if (ilvlmin + i > ilvlmax)
				{
					break;
				}
			}
			if (ilvlmin + i > ilvlmax)
			{
				lowhigh[k][j][0] = -1;
			}
			else
			{
				//lowhigh[k][j][0] = (ilvlmin+i>99)? maxtype[k]-1 : ilvllist[k][ilvlmin+i];		//low����
				lowhigh[k][j][0] = ilvllist[k][ilvlmin + i];
				if (ilvlmax > 98)								//high�����ϱ�
				{
					lowhigh[k][j][1] = maxtype[k] - 1;
				}
				else
				{
					int l = 1;
					while (ilvllist[k][ilvlmax + l] == -1)
					{		//�ش� lvl�� ���� ��� �ǳʶٱ� 
						l++;
						if (ilvlmax + l > 99)
						{
							break;
						}
					}
					lowhigh[k][j][1] = (ilvlmax + l > 99) ? maxtype[k] - 1 : ilvllist[k][ilvlmax + l] - 1;	//high����
				}
			}
		}
	}
}
void GQItem::makegirange()		//lowhigh�� ����
{
	for (int k = 0; k < MAX_WEAPON_CLASS; k++)
		for (int j = 0; j < 100; j++) {
			int n_lev = j;
			int ilvlmin, ilvlmax;
			ilvlmin = n_lev - 10;						//������ ���ü� �ִ� ������ -10 ,+ 5
			if (ilvlmin < 0) ilvlmin = 0;
			else if (ilvlmin > 99) ilvlmin = 99;
			ilvlmax = n_lev + 5;
			if (ilvlmax < 0) ilvlmax = 0;
			else if (ilvlmax > 99) ilvlmax = 99;
			int i = 0;									//low�����ϱ�
			while (gilvllist[k][ilvlmin + i] == -1) {		//�ش� lvl�� ���� ��� �ǳʶٱ�
				i++;
				if (ilvlmin + i > ilvlmax)
					break;
			}
			if (ilvlmin + i > ilvlmax) {
				glowhigh[k][j][0] = -1;
			}
			else {
				//lowhigh[k][j][0] = (ilvlmin+i>99)? maxtype[k]-1 : ilvllist[k][ilvlmin+i];		//low����
				glowhigh[k][j][0] = gilvllist[k][ilvlmin + i];
				if (ilvlmax > 98)								//high�����ϱ�
					glowhigh[k][j][1] = gmaxtype[k] - 1;
				else {
					int l = 1;
					while (gilvllist[k][ilvlmax + l] == -1) {		//�ش� lvl�� ���� ��� �ǳʶٱ� 
						l++;
						if (ilvlmax + l > 99)
							break;
					}
					glowhigh[k][j][1] = (ilvlmax + l > 99) ? gmaxtype[k] - 1 : gilvllist[k][ilvlmax + l] - 1;	//high����
				}
			}
		}
}
void GQItem::LoadBaseItem() {
	long rc = -1;
	int i = 0;

	HANDLE hRFile = CreateFile("data//BaseItem.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		for (i = 0; i < 7; i++)
		{
			maxtype[i] = 0;
		}

		for (i = 0; i < MAX_WEAPON_CLASS; i++)
		{
			gmaxtype[i] = 0;
		}

		DWORD dwTemp;
		int qwe = sizeof(baseitem);
		ReadFile(hRFile, &rc, sizeof(rc), &dwTemp, NULL);
		ZeroMemory(bitemlist, sizeof(bitemlist));
		ZeroMemory(bitemindex, sizeof(bitemindex));
		//ZeroMemory(ilvllist, sizeof(ilvllist));
		memset(ilvllist, -1, sizeof(ilvllist));
		ZeroMemory(basetypelist, sizeof(basetypelist));
		ZeroMemory(maxtype, sizeof(maxtype));
		ZeroMemory(gmaxtype, sizeof(gmaxtype));
		ZeroMemory(gbasetypelist, sizeof(gbasetypelist));
		ZeroMemory(glowhigh, sizeof(glowhigh));
		ZeroMemory(gmaxtype, sizeof(gmaxtype));
		for (i = 0; i < rc; i++)
		{
			if (i < MAX_BASE_ITEM)
			{
				ReadFile(hRFile, &bitemlist[i], sizeof(bitemlist[i]), &dwTemp, NULL);

				int baseitemid = bitemlist[i].baseitemid;
				if (baseitemid < 0 || baseitemid >= MAX_BASE_ITEM_CODE)
				{
					_RPTF1(_CRT_WARN, "baseitemid - %d\n", baseitemid);
					continue;
				}
				bitemindex[baseitemid] = i;
				if (i >= MAX_BASE_ITEM)
				{
					break;
				}
				//bitemlist[i].requiredvirtue -=15;

				int ilvl = bitemlist[i].ilvl;
				if (ilvl >= 0 && ilvl <= 99)
				{
					switch (bitemlist[i].itemtype)
					{
					case itypeweapon:
						if (baseitemid < 3000 || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[3][ilvl] == -1)
							{
								ilvllist[3][ilvl] = maxtype[3];
							}
							basetypelist[3][maxtype[3]++] = i;
						}
						else if ((baseitemid >= 3000 && baseitemid < 4000) || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[0][ilvl] == -1)
							{
								ilvllist[0][ilvl] = maxtype[0];
							}
							basetypelist[0][maxtype[0]++] = i;
						}
						break;
					case itypeshield:
					case itypearmor:
					case itypehelm:
					case itypegloves:
					case itypeboots:
					case itypebelt:
						if (baseitemid < 3000 || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[4][ilvl] == -1)
							{
								ilvllist[4][ilvl] = maxtype[4];
							}
							basetypelist[4][maxtype[4]++] = i;
						}
						else if ((baseitemid >= 3000 && baseitemid < 4000) || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[1][ilvl] == -1)
							{
								ilvllist[1][ilvl] = maxtype[1];
							}
							basetypelist[1][maxtype[1]++] = i;
						}
						break;
					case itypeamulet:
					case itypering:
					case itypependant:
						if (baseitemid < 3000 || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[5][ilvl] == -1)
							{			//lowhigh�� ��������� �����۾�.
								ilvllist[5][ilvl] = maxtype[5];
							}
							basetypelist[5][maxtype[5]++] = i;		//�ش� type�� list�� ���
						}
						else if ((baseitemid >= 3000 && baseitemid < 4000) || (baseitemid >= 30000 && baseitemid < 40000))
						{
							if (ilvllist[2][ilvl] == -1)
							{
								ilvllist[2][ilvl] = maxtype[2];
							}
							basetypelist[2][maxtype[2]++] = i;
						}
						break;
					case itypepotion:
						if (ilvllist[6][ilvl] == -1)
						{
							ilvllist[6][ilvl] = maxtype[6];
						}
						basetypelist[6][maxtype[6]++] = i;
						break;
					case itypescroll:
					default:
						break;
					}

					if (baseitemid < 3000 || (baseitemid >= 30000 && baseitemid < 40000))
					{
						int wclass = bitemlist[i].weaponclass;
						if (wclass >= 0 && wclass < MAX_WEAPON_CLASS)
						{
							if (gilvllist[wclass][ilvl] == -1)
							{
								gilvllist[wclass][ilvl] = gmaxtype[wclass];
							}
							gbasetypelist[wclass][gmaxtype[wclass]++] = i;
						}
					}
				}
			}
			else
			{
				_RPTF1(_CRT_WARN, "max item number exceeded - %d\n", i);
			}
		}
		//11-41952
		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);
		numbitem = rc;
		makeirange();
		makegirange();
	}
}
void GQItem::WriteBaseItem() {
	printf("Begin Write BaseItem.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/BaseItem.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("BaseItem.CSV open error!!!\n");
		return;
	}
	oFile << "bitemid " << "," << "namek " << "," << "namee " << "," 
		<< "wclass " << "," << "wstyle " << "," << "SetIndex " << "," 
		<< "mindam " << "," << "maxdam " << "," << "attackrate " << "," 
		<< "attrange " << "," << "durability " << "," << "weight " << "," 
		<< "buyprice " << "," << "cashprice " << "," << "sellprice " << "," 
		<< "repairprice " << "," << "instancetype " << "," << "property " << "," 
		<< "property2 " << "," << "property3 " << "," << "Own " << "," << "reqlvl " 
		<< "," << "maxlevel " << "," << "reqstr " << "," << "reqdex " << "," 
		<< "reqint " << "," << "reqcon " << "," << "reqvir " << "," 
		<< "defense " << "," << "defenserate " << "," << "classspec " << "," 
		<< "religionspec " << "," << "limitation " << "," << "itemtype " << "," 
		<< "attackspd " << "," << "w_critic " << "," << "itemlvl " << "," 
		<< "aspdfi " << "," << "aspdva " << "," << "aspdma " << "," 
		<< "aspdsa " << "," << "isspecial " << "," << "bColorChange " << "," 
		<< "colorR " << "," << "colorG " << "," << "colorB " << "," 
		<< "colorA " << "," << "bLoopChange " << "," << "fstart " << "," 
		<< "fend " << "," << "changeelement " << "," << "bTextureTransform " << ","
		<< "masterclass " << "," << "socket " << "," << "unite " << "\n";
	for (int i = 0; i < MAX_BASE_ITEM; i++) {
		if (bitemlist[i].baseitemid <= 0) {
			continue;
		}
		oFile << bitemlist[i].baseitemid << ",";
		while (void * pi = memchr(bitemlist[i].namekorean, ',', INAME_LENGTH)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(bitemlist[i].namekorean, '\n', INAME_LENGTH)) {
			*((char *)pi) = '_';
		}
		oFile << bitemlist[i].namekorean << ",";
		while (void * pi = memchr(bitemlist[i].nameenglish, ',', INAME_LENGTH)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(bitemlist[i].nameenglish, '\n', INAME_LENGTH)) {
			*((char *)pi) = '_';
		}
		oFile << bitemlist[i].nameenglish << ",";
		oFile << (int)bitemlist[i].weaponclass << ",";
		oFile << (int)bitemlist[i].weaponstyle << ",";
		oFile << bitemlist[i].setIndex << ",";
		oFile << bitemlist[i].minimumdamage << ",";
		oFile << bitemlist[i].maximumdamage << ",";
		oFile << bitemlist[i].attackrate << ",";
		oFile << bitemlist[i].attackrange << ",";
		oFile << bitemlist[i].durability << ",";
		oFile << bitemlist[i].weight << ",";
		oFile << bitemlist[i].getPrice << ",";
		oFile << bitemlist[i].dbCashPrice << ",";
		oFile << bitemlist[i].price << ",";
		oFile << bitemlist[i].rePrice << ",";
		oFile << bitemlist[i].instancetype << ",";
		oFile << bitemlist[i].property << ",";
		oFile << bitemlist[i].property2 << ",";
		oFile << bitemlist[i].property3 << ",";
		oFile << (int)bitemlist[i].btOwn << ",";
		oFile << bitemlist[i].sRequiredLevel << ",";
		oFile << bitemlist[i].sMaxLevel << ",";
		oFile << bitemlist[i].requiredstrength << ",";
		oFile << bitemlist[i].requireddexterity << ",";
		oFile << bitemlist[i].requiredintelligence << ",";
		oFile << bitemlist[i].requiredconstitution << ",";
		oFile << (int)bitemlist[i].requiredvirtue << ",";
		oFile << bitemlist[i].defense << ",";
		oFile << bitemlist[i].defenserate << ",";
		oFile << (int)bitemlist[i].classspecification << ",";
		oFile << (int)bitemlist[i].religionspecification << ",";
		oFile << bitemlist[i].limitation << ",";
		oFile << (int)bitemlist[i].itemtype << ",";
		while (void * pi = memchr(bitemlist[i].attackspeed, ',', MAX_CLASS_NUM)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(bitemlist[i].attackspeed, '\n', MAX_CLASS_NUM)) {
			*((char *)pi) = '_';
		}
		oFile << bitemlist[i].attackspeed << ",";
		oFile << (int)bitemlist[i].critical << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << (int)bitemlist[i].isspecial << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << (int)bitemlist[i].chMaster << ",";
		oFile << (int)bitemlist[i].chSocket << ",";
		oFile << 0 << ",";
		oFile << "" << "\n";
	}

	oFile.close();
	printf("End Write BaseItem.CSV\n\n");
}

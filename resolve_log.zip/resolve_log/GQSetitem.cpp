#include "GQSetitem.h"
using namespace std;


GQSetitem::GQSetitem()
{
}


GQSetitem::~GQSetitem()
{
}


//���� setitem.dat
void GQSetitem::makesetindex()
{
	int i = 0;
	for (i = 0; i < MAX_BASE_ITEM_CODE; i++)
	{
		setindex[i] = -1;
	}

	for (i = 0; i < numset; i++)
	{
		int bitem = setlist[i].sitem[0];
		if (bitem >= 0 && bitem < MAX_BASE_ITEM_CODE)
		{
			if (setindex[bitem] == -1)
			{
				setindex[bitem] = i;
			}
		}
	}
}
bool GQSetitem::LoadSetItem() {
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/setitem.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
		return false;

	ZeroMemory(setlist, sizeof(setlist));
	ReadFile(hFile, &numset, sizeof(int), &dwTemp, NULL);

	ReadFile(hFile, setlist, sizeof(setlist), &dwTemp, NULL);

	makesetindex();

	char tale[200];
	ZeroMemory(tale, 200);
	ReadFile(hFile, tale, 200, &dwTemp, NULL);

	CloseHandle(hFile);
	return true;
}

void GQSetitem::GQWrite() {
	printf("Begin Write setitem.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/setitem.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("fixed.CSV setitem error!!!\n");
		return;
	}
	oFile << "sitem1 " << "," << "sitem2 " << "," << "sitem3 " << "," << "sitem4 " << "," << "sitem5 " << "," << "sitem6 " << "," << "bopt1 " << "," << "bval1 " << "," << "bopt2 " << "," << "bval2 " << "," << "bopt3 " << "," << "bval3 " << "," << "bopt4 " << "," << "bval4" << "\n";
	for (int i = 0; i < MAX_SET; i++) {
		if (setlist[i].sitem[0] <= -1 ) {
			continue;
		}
		oFile << setlist[i].sitem[0] << ",";
		oFile << setlist[i].sitem[1] << ",";
		oFile << setlist[i].sitem[2] << ",";
		oFile << setlist[i].sitem[3] << ",";
		oFile << setlist[i].sitem[4] << ",";
		oFile << setlist[i].sitem[5] << ",";
		oFile << setlist[i].option[0] << ",";
		oFile << setlist[i].value[0] << ",";
		oFile << setlist[i].option[1] << ",";
		oFile << setlist[i].value[1] << ",";
		oFile << setlist[i].option[2] << ",";
		oFile << setlist[i].value[2] << ",";
		oFile << setlist[i].option[3] << ",";
		oFile << setlist[i].value[3] << "\n";
	}

	oFile.close();
	printf("End Write setitem.CSV\n");
}

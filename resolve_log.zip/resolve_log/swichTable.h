#pragma once

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <list>
#include <io.h>

#define CRO_CIRCLE 10086
#define CRO_MULTI 3245

struct switchTable {
	char front[128];
	char rear[128];
};

int CRO_SWITCH(int i);
int encrypt(const char *org_pass, char *new_pass);
int decrypt(const char *new_pass, char *org_pass);
int passwdOption(int type, char * passwd1, char * passwd2);
bool BATtoTXT(std::string  rfile, std::string  wfile);
bool TXTtoDAT(std::string  rfile, std::string  wfile);
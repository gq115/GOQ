#include "GQColor.h"
using namespace std;


GQColor::GQColor()
{
}


GQColor::~GQColor()
{
}


template <class T> void BubbleSort(T a[], int b, BOOL bDescending = FALSE, int step = 1)
{
	int	i, j;
	T *pTemp;

	b /= step;
	pTemp = new T[step];
	ZeroMemory(pTemp, sizeof(T) * step);

	if (bDescending)
	{
		for (i = 0; i < b - 1; i++)
		{
			for (j = i + 1; j < b; j++)
			{
				if (a[i*step] < a[j*step])
				{
					memcpy(pTemp, &a[i*step], sizeof(T) * step);
					//temp = a[i*step];
					memcpy(&a[i*step], &a[j*step], sizeof(T) * step);
					memcpy(&a[j*step], pTemp, sizeof(T) * step);

					//a[i*step] = a[j*step];
					//a[j*step] = temp;
				}
			}
		}
	}
	else
	{
		for (i = 0; i < b - 1; i++)
		{
			for (j = i + 1; j < b; j++)
			{
				if (a[i*step] > a[j*step])
				{
					memcpy(pTemp, &a[i*step], sizeof(T) * step);
					memcpy(&a[i*step], &a[j*step], sizeof(T) * step);
					memcpy(&a[j*step], pTemp, sizeof(T) * step);

					/*temp = a[i];
					a[i] = a[j];
					a[j] = temp;*/
				}
			}
		}
	}

	// 20060808 ����(�̼���:C6283 ���� ����, delete [] �� �����ؾ���)
	delete[] pTemp;
}
bool GQColor::LoadColorTables() {
	//�ش� �̻� ���̺��� ���� �ε��ϰ� �����Ѵ�.
	if (!m_cOption.Open("data\\ColorOpt.dat"))
	{
		return FALSE;
	}

	if (!m_cClass.Open("data\\ColorItemClass.dat"))
	{
		return FALSE;
	}

	if (!m_cCombine.Open("data\\ColorCombine.dat"))
	{
		return FALSE;
	}

	if (!m_cSet.Open("data\\ColorSetItem.dat"))
	{
		return FALSE;
	}

	DWORD optionCount = 0;
	{
		struct COLOR_OPTION* pData;
		STATE state = m_cOption.GetFirstItem();
		while (m_cOption.GetNextItem(state))
			optionCount++;
		m_atlMapOption.InitHashTable(optionCount);
		state = m_cOption.GetFirstItem();
		while (pData = (COLOR_OPTION *)m_cOption.GetNextItem(state))
		{
			unsigned short key = (unsigned short)(pData->btItemClass << MAX_COLOR_NUM | pData->btColor);
			if (m_atlMapOption.Lookup(key))
				continue;
			m_atlMapOption.SetAt(key, pData);
		}
		m_atlMapOption.AssertValid();
	}

	DWORD classCount = 0;
	{
		struct COLOR_ITEMCLASS* pData;
		STATE state = m_cClass.GetFirstItem();
		while (m_cClass.GetNextItem(state))
			classCount++;
		m_atlMapClass.InitHashTable(classCount);
		state = m_cClass.GetFirstItem();
		while (pData = (COLOR_ITEMCLASS *)m_cClass.GetNextItem(state))
		{
			if (m_atlMapClass.Lookup(pData->nSetIndex))
				continue;
			m_atlMapClass.SetAt(pData->nSetIndex, pData);
		}
		m_atlMapClass.AssertValid();
	}

	DWORD setCount = 0;
	{
		struct COLOR_SETITEM* pData;
		STATE state = m_cSet.GetFirstItem();
		while (m_cSet.GetNextItem(state))
			setCount++;
		m_atlMapSet.InitHashTable(setCount);
		state = m_cSet.GetFirstItem();
		while (pData = (COLOR_SETITEM *)m_cSet.GetNextItem(state))
		{
			unsigned short key = (unsigned short)(pData->btItemClass << MAX_COLOR_NUM | pData->btColor);
			if (m_atlMapSet.Lookup(key))
				continue;
			m_atlMapSet.SetAt(key, pData);
		}
		m_atlMapSet.AssertValid();
	}

	STATE	state;
	LPVOID	pData;
	COLOR_COMBINE	*pCombine;

	state = m_cCombine.GetFirstItem();
	while (pData = m_cCombine.GetNextItem(state))
	{
		pCombine = (COLOR_COMBINE *)pData;
		//DBLoader���� ���� ������ ��Ʈ�Ѵ�.
		BubbleSort(pCombine->nMaterial, MAX_MATERAL_NUM, TRUE);
		m_mapCombine.insert(hashTable::value_type(pCombine->nMaterial[0], (LPVOID)pCombine));
	}

	return TRUE;
}


void GQColor::GQWrite() {
	printf("Begin Write ColorOpt.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/ColorOpt.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ColorOpt.CSV open error!!!\n");
		return;
	}


	POSITION pos;
	int key;
	COLOR_OPTION *pOption;
	pos = m_atlMapOption.GetStartPosition();
	oFile << "index" << "," <<"itemclass" << "," << "color" << "," 
		  <<"option1" << "," <<"value1" << "," <<"option2" << "," <<"value2" << "," 
		  <<"option3" << "," <<"value3" << "," << "option4" << "," << "value4" << "\n";

	oFile << "" << ",";
	while (pos != NULL)
	{
		key = m_atlMapOption.GetKeyAt(pos);
		pOption = (COLOR_OPTION *)m_atlMapOption.GetNextValue(pos);
		if (pOption == NULL)
			continue;

		oFile << pOption->nIndex << ",";
		oFile << (int)pOption->btItemClass << ",";
		oFile << (int)pOption->btColor << ",";
		oFile << pOption->opt[0].wOption << ",";
		oFile << pOption->opt[0].wValue << ",";
		oFile << pOption->opt[1].wOption << ",";
		oFile << pOption->opt[1].wValue << ",";
		oFile << pOption->opt[2].wOption << ",";
		oFile << pOption->opt[2].wValue << ",";
		oFile << pOption->opt[3].wOption << ",";
		oFile << pOption->opt[3].wValue << "\n";
	}
	oFile.close();
	printf("End Write ColorOpt.CSV\n");


	
	oFile.open("dataCSV/ColorItemClass.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ColorItemClass.CSV open error!!!\n");
		return;
	}
	POSITION pos1;
	int key1;
	COLOR_ITEMCLASS *pItemC;
	pos1 = m_atlMapClass.GetStartPosition();
	oFile << "index " << "," << "itemclass " << "," << "setindex " << "," << "memo" << "\n";

	while (pos1 != NULL)
	{
		key1 = m_atlMapClass.GetKeyAt(pos1);
		pItemC = (COLOR_ITEMCLASS *)m_atlMapClass.GetNextValue(pos1);
		if (pItemC == NULL)
			continue;
		oFile << pItemC->nIndex << ",";
		oFile << (int)pItemC->btItemClass << ",";
		oFile << pItemC->nSetIndex << ",";
		oFile << pItemC->reserved << "\n";
	}
	oFile.close();
	printf("End Write ColorItemClass.CSV\n");



	oFile.open("dataCSV/ColorSetItem.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ColorSetItem.CSV open error!!!\n");
		return;
	}
	POSITION pos2;
	int key2;
	COLOR_SETITEM *pSItem;
	pos2 = m_atlMapSet.GetStartPosition();
	oFile << "index " << "," << "itemclass " << "," << "color " << ","
		<< "option1 " << "," << "value1 " << "," << "option2 " << "," << "value2 " << "," << "option3 " << "," << "value3" << "\n";
	while (pos2 != NULL)
	{
		key2 = m_atlMapSet.GetKeyAt(pos2);
		pSItem = (COLOR_SETITEM *)m_atlMapSet.GetNextValue(pos2);
		if (pSItem == NULL)
			continue;
		oFile << pSItem->wIndex << ",";
		oFile << (int)pSItem->btItemClass << ",";
		oFile << (int)pSItem->btColor << ",";
		oFile << pSItem->opt[0].wOption << ",";
		oFile << pSItem->opt[0].wValue << ",";
		oFile << pSItem->opt[1].wOption << ",";
		oFile << pSItem->opt[1].wValue << ",";
		oFile << pSItem->opt[2].wOption << ",";
		oFile << pSItem->opt[2].wValue << "\n";
	}
	oFile.close();
	printf("End Write ColorSetItem.CSV\n");


	oFile.open("dataCSV/ColorCombine.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("ColorCombine.CSV open error!!!\n");
		return;
	}
	oFile << "index " << "," << "MidGroupID " << "," << "itemclass " << "," 
		<< "color " << "," << "material1 " << "," << "material2 " << "," 
		<< "material3 " << "," << "material4 " << "," << "material5 " << "," 
		<< "material6 " << "," << "productcolor " << "," << "fproductcolor " << "," 
		<< "minprob " << "," << "maxprob " << "," << "goldperprob" << "\n";
	typedef multimap<WORD, LPVOID>::iterator  MULTIMAP_ITERA;
	for (MULTIMAP_ITERA pIter = m_mapCombine.begin(); pIter != m_mapCombine.end(); pIter++) {
		COLOR_COMBINE *pCCombin = (COLOR_COMBINE *)pIter->second;
		if (pCCombin == NULL) {
			continue;
		}
		oFile << pCCombin->nIndex << ",";
		oFile << pCCombin->nMidGroupID << ",";
		oFile << (int)pCCombin->btItemClass << ",";
		oFile << (int)pCCombin->btColor << ",";
		oFile << pCCombin->nMaterial[0] << ",";
		oFile << pCCombin->nMaterial[1] << ",";
		oFile << pCCombin->nMaterial[2] << ",";
		oFile << pCCombin->nMaterial[3] << ",";
		oFile << pCCombin->nMaterial[4] << ",";
		oFile << pCCombin->nMaterial[5] << ",";
		oFile << (int)pCCombin->btFailProductColor << ",";
		oFile << (int)pCCombin->btFailProductColor << ",";
		oFile << pCCombin->wMinProb << ",";
		oFile << pCCombin->wMaxProb << ",";
		oFile << pCCombin->nGoldPerProb << "\n";

		//pair<MULTIMAP_ITERA, MULTIMAP_ITERA> range;
		//range = m_mapCombine.equal_range( pIter->first );
		//for (MULTIMAP_ITERA pINIter = range.first; pINIter != range.second; pINIter++) {
		//	COLOR_COMBINE *pCCombin = (COLOR_COMBINE *)pINIter->second;
		//	if (pCCombin == NULL) {
		//		continue;
		//	}
		//	oFile << pCCombin->nIndex << ",";
		//	oFile << pCCombin->nMidGroupID << ",";
		//	oFile << (int)pCCombin->btItemClass << ",";
		//	oFile << (int)pCCombin->btColor << ",";
		//	oFile << pCCombin->nMaterial[0] << ",";
		//	oFile << pCCombin->nMaterial[1] << ",";
		//	oFile << pCCombin->nMaterial[2] << ",";
		//	oFile << pCCombin->nMaterial[3] << ",";
		//	oFile << pCCombin->nMaterial[4] << ",";
		//	oFile << pCCombin->nMaterial[5] << ",";
		//	oFile << (int)pCCombin->btFailProductColor << ",";
		//	oFile << (int)pCCombin->btFailProductColor << ",";
		//	oFile << pCCombin->wMinProb << ",";
		//	oFile << pCCombin->wMaxProb << ",";
		//	oFile << pCCombin->nGoldPerProb << "\n";
		//}
	}
	oFile.close();
	printf("End Write ColorCombine.CSV\n");
}
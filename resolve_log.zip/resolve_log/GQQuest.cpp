#include "GQQuest.h"
using namespace std;


GQQuest::GQQuest()
{
}


GQQuest::~GQQuest()
{
}


bool GQQuest::LoadQuestData() {
	HANDLE hFile;
	DWORD dwTemp;
	int m_iVariableCount = 0;
	int m_iQuestCount = 0;

	hFile = CreateFile("data/SQuest.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}

	ReadFile(hFile, &m_iVariableCount, sizeof(m_iVariableCount), &dwTemp, NULL);
	for (int i = 0; i < m_iVariableCount; i++)
	{
		QuestVariable tvar;
		if (tvar.ReadData(hFile)) {
			m_qvar[tvar.GetVariableID()] = tvar;
		}
		else {
			CloseHandle(hFile);
			return false;
		}
	}

	ReadFile(hFile, &m_iQuestCount, sizeof(m_iQuestCount), &dwTemp, NULL);
	for (int i = 0; i < m_iQuestCount; i++) {
		Quest tquest;
		if (tquest.ReadData(hFile)) {
			tquest.SetVariable(m_qvar);
			m_Quest1[tquest.GetQuestID()] = tquest;
		}
		else {
			CloseHandle(hFile);
			return false;
		}
	}

	CloseHandle(hFile);
	return true;
}


bool GQQuest::LoadQuestTables() {
	//HANDLE hFile = CreateFile("data/Quest.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	//if (hFile == INVALID_HANDLE_VALUE)
	//{
	//	return false;
	//}

	if (!m_Quest.Open("data\\Quest.dat"))
	{
		return FALSE;
	}

	int nCount = 0;

	SQuest *pQuest;
	STATE state = m_Quest.GetFirstItem();
	while (m_Quest.GetNextItem(state))
	{
		nCount++;
	}
	m_mapQuest.InitHashTable(nCount);

	state = m_Quest.GetFirstItem();
	while (pQuest = (SQuest*)m_Quest.GetNextItem(state))
	{
		int nKey = pQuest->nID;
		if (m_mapQuest.Lookup(nKey))
		{
			continue;
		}
		m_mapQuest.SetAt(nKey, pQuest);

		switch (pQuest->btAcceptance)
		{
		case E_ACCEPTABLE_CONNECT:
			m_mapAcceptableConnection.SetAt(nKey, &nKey);
			break;

		case E_ACCEPTABLE_COMPLETE:
			m_mapAcceptableCompletion.SetAt(nKey, &nKey);
			break;

		case E_ACCEPTABLE_ZONE:
			m_mapAcceptableZone.SetAt(nKey, &nKey);
			break;

		case E_ACCEPTABLE_LEVEL:
			m_mapAcceptableLevel.SetAt(nKey, &nKey);
			break;

		case E_ACCEPTABLE_ITEM:
			m_mapAcceptableItem.SetAt(nKey, &nKey);
			break;
		}
	}
	m_mapQuest.AssertValid();

	return TRUE;
}

bool GQQuest::LoadQuestStepTables() {
	if (!m_QuestStep.Open("data\\QuestStep.dat"))
	{
		return FALSE;
	}

	int nCount = 0;

	SQuestStep *pQuestStep;
	STATE state = m_QuestStep.GetFirstItem();
	while (m_QuestStep.GetNextItem(state))
	{
		nCount++;
	}

	state = m_QuestStep.GetFirstItem();
	while (pQuestStep = (SQuestStep*)m_QuestStep.GetNextItem(state))
	{
		m_multiMapQuestStep.insert(QUEST_STEP_VALUE(pQuestStep->nQuestID, pQuestStep));
	}

	return TRUE;
}

bool GQQuest::LoadQuestRewardTables() {
	if (!m_QuestReward.Open("data\\QuestReward.dat"))
	{
		return FALSE;
	}

	int nCount = 0;

	SQuestReward *pQuestReward;
	STATE state = m_QuestReward.GetFirstItem();
	while (m_QuestReward.GetNextItem(state))
	{
		nCount++;
	}

	state = m_QuestReward.GetFirstItem();
	while (pQuestReward = (SQuestReward*)m_QuestReward.GetNextItem(state))
	{
		m_multiMapQuestReward.insert(QUEST_STEP_VALUE(pQuestReward->nIndex, pQuestReward));
	}

	return TRUE;
}

bool GQQuest::LoadQuestZoneTables() {
	if (!m_QuestZone.Open("data\\QuestZone.dat"))
	{
		return FALSE;
	}

	int nCount = 0;

	SQuestZone *pQuestZone;
	STATE state = m_QuestZone.GetFirstItem();
	while (m_QuestZone.GetNextItem(state))
	{
		nCount++;
	}
	m_mapQuestZone.InitHashTable(nCount);

	state = m_QuestZone.GetFirstItem();
	while (pQuestZone = (SQuestZone*)m_QuestZone.GetNextItem(state))
	{
		int nKey = pQuestZone->nIndex;
		if (m_mapQuestZone.Lookup(nKey))
		{
			continue;
		}
		m_mapQuestZone.SetAt(nKey, pQuestZone);
	}
	m_mapQuestZone.AssertValid();

	return TRUE;
}

void GQQuest::GQWrite() {
	printf("Begin Write QuestZone.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/QuestZone.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("QuestZone.CSV open error!!!\n");
		return;
	}
	POSITION pos;
	int key;
	SQuestZone *pQuestZ;
	pos = m_mapQuestZone.GetStartPosition();
	oFile << "Index " << "," << "ZoneID " << "," << "X " << "," << "Y " << "," << "Radius" << "\n";
	while (pos != NULL)
	{
		key = m_mapQuestZone.GetKeyAt(pos);
		pQuestZ = (SQuestZone *)m_mapQuestZone.GetNextValue(pos);
		if (pQuestZ == NULL)
			continue;
		if (pQuestZ->nIndex <=-1 ) {
			continue;
		}
		oFile << pQuestZ->nIndex << ",";
		oFile << pQuestZ->nZoneID << ",";
		oFile << pQuestZ->nX << ",";
		oFile << pQuestZ->nY << ",";
		oFile << pQuestZ->nRadius << "\n";
	}

	oFile.close();
	printf("End Write QuestZone.CSV\n");


	printf("Begin Write QuestReward.CSV\n");
	oFile.open("dataCSV/QuestReward.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("QuestReward.CSV open error!!!\n");
		return;
	}
	oFile << "index " << "," << "Type " << "," << "Kind " << "," 
		<< "ItemID " << "," << "ItemGrade " << "," << "Value " << "," 
		<< "Skill " << "," << "SkillLevel" << "\n";
	typedef multimap<int, LPVOID>::iterator  MULTIMAP_ITERA;
	for (MULTIMAP_ITERA pIter = m_multiMapQuestReward.begin(); pIter != m_multiMapQuestReward.end(); pIter++) {
		SQuestReward *pQuestR = (SQuestReward *)pIter->second;
		if (pQuestR == NULL) {
			continue;
		}
		if ( pQuestR->nIndex <= -1 ) {
			continue;
		}
		oFile << pQuestR->nIndex << ",";
		oFile << (int)pQuestR->btType << ",";
		oFile << pQuestR->nKind << ",";
		oFile << pQuestR->nItemID << ",";
		oFile << pQuestR->nItemGrade << ",";
		oFile << pQuestR->nValue << ",";
		oFile << pQuestR->nSkill << ",";
		oFile << pQuestR->nSkillLevel << "\n";
	}

	oFile.close();
	printf("End Write QuestReward.CSV\n");


	printf("Begin Write QuestStep.CSV\n");
	oFile.open("dataCSV/QuestStep.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("QuestStep.CSV open error!!!\n");
		return;
	}
	oFile << "QuestID " << "," << "StepID " << "," << "Title " << "," 
		<< "Description " << "," << "Type " << "," << "NpcID " << "," 
		<< "NpcGrade " << "," << "NpcCount " << "," << "ItemID " << "," 
		<< "ItemGrade " << "," << "ItemCount " << "," << "RewardAcceptance " << "," 
		<< "RewardIndex " << "," << "ZoneIndex " << "," << "EffectIndex " << "," 
		<< "DialogIndex" << "\n";
	for (MULTIMAP_ITERA pIter = m_multiMapQuestStep.begin(); pIter != m_multiMapQuestStep.end(); pIter++) {
		SQuestStep *pQuestS = (SQuestStep *)pIter->second;
		if (pQuestS == NULL) {
			continue;
		}
		if (pQuestS->nQuestID <= 0) {
			continue;
		}
		oFile << pQuestS->nQuestID << ",";
		oFile << pQuestS->nStepID << ",";
		oFile << pQuestS->chTitle << ",";
		oFile << pQuestS->chDescription << ",";
		oFile << (int)pQuestS->btType << ",";
		oFile << pQuestS->nNpcID << ",";
		oFile << pQuestS->nNpcGrade << ",";
		oFile << pQuestS->nNpcCount << ",";
		oFile << pQuestS->nItemID << ",";
		oFile << pQuestS->nItemGrade << ",";
		oFile << pQuestS->nItemCount << ",";
		oFile << (int)pQuestS->btRewardAcceptance << ",";
		oFile << pQuestS->nRewardIndex << ",";
		oFile << pQuestS->nZoneIndex << ",";
		oFile << pQuestS->nEffectIndex << ",";
		oFile << pQuestS->nDialogIndex << "\n";
	}

	oFile.close();
	printf("End Write QuestStep.CSV\n");

	

	
	printf("Begin Write quest.CSV\n");
	oFile.open("dataCSV/quest.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("quest.CSV open error!!!\n");
		return;
	}
	SQuest *pQuest;
	pos = m_mapQuest.GetStartPosition();
	oFile << "id " << "," << "title " << "," << "Description " << "," 
		<< "Section " << "," << "Acceptance " << "," << "Repetition " << "," 
		<< "accumulation " << "," << "Group " << "," << "Class " << "," 
		<< "MinLevel " << "," << "MaxLevel " << "," << "Time " << "," 
		<< "PreQuest1 " << "," << "PreQuest2 " << "," << "PreQuest3 " << "," 
		<< "PreQuest4 " << "," << "NextQuest " << "," << "zone " << "," 
		<< "Npc " << "," << "accitem" << "\n";

	while (pos != NULL)
	{
		m_mapQuest.GetKeyAt(pos);
		pQuest = (SQuest *)m_mapQuest.GetNextValue(pos);
		if (pQuest == NULL)
			continue;
		if (pQuest->nID <= 0) {
			continue;
		}
		oFile << pQuest->nID << ",";
		oFile << pQuest->chTitle << ",";
		oFile << pQuest->chDescription << ",";
		oFile << (int)pQuest->btSection << ",";
		oFile << (int)pQuest->btAcceptance << ",";
		oFile << (int)pQuest->btRepetition << ",";
		oFile << pQuest->nAccumulation << ",";
		oFile << (int)pQuest->btGroup << ",";
		oFile << (int)pQuest->btClass << ",";
		oFile << pQuest->nMinLevel << ",";
		oFile << pQuest->nMaxLevel << ",";
		oFile << pQuest->nTime << ",";
		oFile << pQuest->nPreQuest[0] << ",";
		oFile << pQuest->nPreQuest[1] << ",";
		oFile << pQuest->nPreQuest[2] << ",";
		oFile << pQuest->nPreQuest[3] << ",";
		oFile << pQuest->nNextQuest << ",";
		oFile << pQuest->nZone << ",";
		oFile << pQuest->nNpc << ",";
		oFile << pQuest->nUseItem << "\n";
	}

	oFile.close();
	printf("End Write quest.CSV\n");
}
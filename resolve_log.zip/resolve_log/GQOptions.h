#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQOptions
{
public:
	GQOptions();
	~GQOptions();


	options oplist[MAX_OPTION_NUM];						//option������
	int 	maxop;											//option����
	int 	oindex[MAX_OPTION_CODE];						//option id�� oplist�� ��ȣ ��������
	int 	exoplist[MAX_WEAPON_CLASS][MAX_OPTION_NUM];
	int 	imoplist[MAX_WEAPON_CLASS][MAX_OPTION_NUM];
	int 	maxex[MAX_WEAPON_CLASS];
	int 	maxim[MAX_WEAPON_CLASS];
	int 	olvlex[MAX_WEAPON_CLASS][100];
	int 	olvlim[MAX_WEAPON_CLASS][100];
	int		lowhighex[MAX_WEAPON_CLASS][100][2];
	int		lowhighim[MAX_WEAPON_CLASS][100][2];
	void makeoindex();
	void makeorange();
	void LoadOption();
	void WriteOption();
};


#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"


class GQQuest
{
public:
	GQQuest();
	~GQQuest();


public:
	QuestVariable	m_qvar[MAX_VARIABLE];
	Quest		m_Quest1[MAX_QUESTLIST];
	bool LoadQuestData();


	CSimpleDataTable	m_Quest;
	ATL::CAtlMap<int, void*>	m_mapQuest;
	ATL::CAtlMap<int, void*>	m_mapAcceptableConnection;
	ATL::CAtlMap<int, void*>	m_mapAcceptableCompletion;
	ATL::CAtlMap<int, void*>	m_mapAcceptableZone;
	ATL::CAtlMap<int, void*>	m_mapAcceptableLevel;
	ATL::CAtlMap<int, void*>	m_mapAcceptableItem;
	bool LoadQuestTables();				//OK


	typedef std::multimap<int, LPVOID>			MULTIMAP_QUEST_STEP;
	typedef MULTIMAP_QUEST_STEP::iterator		QUEST_STEP_IT;
	typedef MULTIMAP_QUEST_STEP::value_type		QUEST_STEP_VALUE;
	CSimpleDataTable	m_QuestStep;
	MULTIMAP_QUEST_STEP	m_multiMapQuestStep;
	bool LoadQuestStepTables();			//OK

	CSimpleDataTable	m_QuestReward;
	MULTIMAP_QUEST_STEP m_multiMapQuestReward;
	bool LoadQuestRewardTables();		//OK

	CSimpleDataTable	m_QuestZone;
	ATL::CAtlMap<int, void*>	m_mapQuestZone;
	bool LoadQuestZoneTables();			//OK
	void GQWrite();
};


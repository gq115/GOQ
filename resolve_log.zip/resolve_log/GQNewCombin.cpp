#include "GQNewCombin.h"
using namespace std;


GQNewCombin::GQNewCombin()
{
}


GQNewCombin::~GQNewCombin()
{
}

void GQNewCombin::makecindex()
{
	int i = 0;

	for (i = 0; i < MAX_BASE_ITEM_CODE; i++)
	{
		cindex[i] = -1;
	}

	for (i = 0; i < m_total_combine_number; i++)
	{
		int bitem = creItemInfo[i].ingredient[0];

		if (bitem >= 0 && bitem < MAX_BASE_ITEM_CODE)
		{
			if (cindex[bitem] == -1)
			{
				cindex[bitem] = i;
			}
		}
	}
}
bool GQNewCombin::LoadTbl() {
	HANDLE hFile;
	DWORD dwTemp;

	ZeroMemory(creItemInfo, sizeof(creItemInfo));

	hFile = CreateFile("data/combine.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
		return false;

	ReadFile(hFile, &m_total_combine_number, sizeof(int), &dwTemp, NULL);

	ReadFile(hFile, creItemInfo, sizeof(creItemInfo), &dwTemp, NULL);


	makecindex();

	char tale[200];
	ZeroMemory(tale, 200);
	ReadFile(hFile, tale, 200, &dwTemp, NULL);

	CloseHandle(hFile);
	return true;
}
void GQNewCombin::WriteTbl() {					//�����⣬��Ҫ����ѡ��
	printf("Begin Write combine.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/combine.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("combine.CSV open error!!!\n");
		return;
	}


	for (int i = 0; i < MAX_COMBINE; i++) {
		if (creItemInfo[i].id <= 0) {
			continue;
		}
	}

	oFile.close();
	printf("Begin Write combine.CSV\n");
}


void GQNewCombin::GQOpen() {
	printf("Begin Load NewCombineList.dat\n");
	if (m_cNewCombineList.Open("data\\NewCombineList.dat")) {
		printf("End Load NewCombineList.dat\n");
	}
	else {
		printf("Error NewGrowth NewCombineList.dat\n");
	}
	return;
}

void GQNewCombin::GQWrite() {
	printf("Begin Write NewCombineList.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/NewCombineList.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("NewCombineList.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	SNewCombineList	*pCombine = NULL;
	oFile << "MidGroupID " << "," << "newcombineset " << "," 
		<< "SuccessItem " << "," << "FailedItem " << "," << "InherentMaterial " << "," 
		<< "material1 " << "," << "cnt1 " << "," << "material2 " << "," << "cnt2 " << "," 
		<< "material3 " << "," << "cnt3 " << "," << "material4 " << "," << "cnt4 " << "," 
		<< "material5 " << "," << "cnt5 " << "," << "material6 " << "," << "cnt6 " << "," 
		<< "CraftStone " << "," << "baseprob " << "," << "goldprob " << "," << "maxprob" << "\n";
	state = m_cNewCombineList.m_cNewCombine.GetFirstItem();
	while (pData = m_cNewCombineList.m_cNewCombine.GetNextItem(state)) {
		pCombine = (SNewCombineList *)pData;
		if (pCombine->nNewCombineSet <= -1)
			continue;
		if (pCombine == NULL) {
			continue;
		}
		oFile << pCombine->nMidGroupID << ",";
		oFile << pCombine->nNewCombineSet << ",";
		oFile << pCombine->nSuccessItem << ",";
		oFile << pCombine->nFailedItem << ",";
		oFile << pCombine->nInherentMat << ",";
		oFile << pCombine->nMat[0] << ",";
		oFile << pCombine->nCnt[0] << ",";
		oFile << pCombine->nMat[1] << ",";
		oFile << pCombine->nCnt[1] << ",";
		oFile << pCombine->nMat[2] << ",";
		oFile << pCombine->nCnt[2] << ",";
		oFile << pCombine->nMat[3] << ",";
		oFile << pCombine->nCnt[3] << ",";
		oFile << pCombine->nMat[4] << ",";
		oFile << pCombine->nCnt[4] << ",";
		oFile << pCombine->nMat[5] << ",";
		oFile << pCombine->nCnt[5] << ",";
		oFile << pCombine->nCraftstone << ",";
		oFile << pCombine->nBaseprob << ",";
		oFile << pCombine->nGoldprob << ",";
		oFile << pCombine->nMaxprob << "\n";
	}

	oFile.close();
	printf("End Write NewCombineList.CSV\n");
}

#include "GQRefine.h"
using namespace std;


GQRefine::GQRefine()
{
}


GQRefine::~GQRefine()
{
}


//���� refine.dat 
void GQRefine::LoadRefine() {
	long rc = -1;
	DBG_UNREFERENCED_LOCAL_VARIABLE(rc);

	for (int i = 0; i < MAX_BASE_ITEM_CODE; i++) {
		refineMap[i] = -1;
	}

	HANDLE hRFile = CreateFile("data/refine.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		DWORD dwTemp;
		ZeroMemory(reflist, sizeof(reflist));
		ReadFile(hRFile, reflist, sizeof(reflist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);
		refcount = 0;
		for (int i = 0; i < MAX_REFINE; i++) {
			if (reflist[i].mat1) {
				int mat2 = reflist[i].mat2;
				if (refineMap[mat2] == -1)
					refineMap[mat2] = i;
				refcount++;
			}
			else break;
		}
	}
}
void GQRefine::WriteRefine() {
	printf("Begin Write refine.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/refine.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("refine.CSV open error!!!\n");
		return;
	}
	oFile << "refcd " << "," << "mat1 " << "," << "mat2 " << "," << "product1 " << "," << "pprob1 " << "," << "errmsg1 " << "," << "message1 " << "," << "product2 " << "," << "pprob2 " << "," << "errmsg2 " << "," << "message2 " << "," << "product3 " << "," << "pprob3 " << "," << "errmsg3 " << "," << "message3 " << "," << "product4 " << "," << "pprob4 " << "," << "errmsg4 " << "," << "message4" << "\n";
	for (int i = 0; i < MAX_REFINE; i++) {
		if (reflist[i].refcd <= 0) {
			continue;
		}

		oFile << reflist[i].refcd << ",";
		oFile << reflist[i].mat1 << ",";
		oFile << reflist[i].mat2 << ",";
		oFile << reflist[i].product[0] << ",";
		oFile << reflist[i].pprob[0] << ",";
		oFile << reflist[i].errmsg[0] << ",";
		oFile << (int)reflist[i].cMessage[0] << ",";
		oFile << reflist[i].product[1] << ",";
		oFile << reflist[i].pprob[1] << ",";
		oFile << reflist[i].errmsg[1] << ",";
		oFile << (int)reflist[i].cMessage[1] << ",";
		oFile << reflist[i].product[2] << ",";
		oFile << reflist[i].pprob[2] << ",";
		oFile << reflist[i].errmsg[2] << ",";
		oFile << (int)reflist[i].cMessage[2] << ",";
		oFile << reflist[i].product[3] << ",";
		oFile << reflist[i].pprob[3] << ",";
		oFile << reflist[i].errmsg[3] << ",";
		oFile << (int)reflist[i].cMessage[3] << "\n";
	}

	oFile.close();
	printf("Begin Write refine.CSV\n");
}

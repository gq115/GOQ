#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQNewCombin
{
public:
	GQNewCombin();
	~GQNewCombin();

	int 	cindex[MAX_BASE_ITEM_CODE];
	int 	m_total_combine_number;
	SCombine creItemInfo[MAX_COMBINE];
	CNewCombineList			m_cNewCombineList;
	void makecindex();
	bool LoadTbl();
	void WriteTbl();
	void GQOpen();
	void GQWrite();
};


#pragma once

#include <iostream>
#include <fstream>
#include <list>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include "diyStruct.h"

bool UserRead(std::string fileName);
bool FieldRead(std::string fileName);
bool ItemRead(std::string fileName);
bool GrowthRead(std::string fileName);
bool ServerRead(std::string fileName);

bool writeUserInfo(std::string fileName);
bool writeFieldInfo(std::string fileName);
bool writeItemInfo(std::string fileName);
bool writeGrowthInfo(std::string fileName);
bool writeServerInfo(std::string fileName);


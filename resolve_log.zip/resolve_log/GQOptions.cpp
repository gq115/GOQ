#include "GQOptions.h"
using namespace std;


GQOptions::GQOptions()
{
}


GQOptions::~GQOptions()
{
}

//���� Option.dat
void GQOptions::makeoindex()		//index�� �����ϴ� option list������ ��ġ�� ����صδ� list�� �����Ѵ�.
{
	for (int i = 0; i < maxop; i++)
	{
		oindex[oplist[i].optionid] = i;
	}
}
void GQOptions::makeorange()
{
	for (int type = 0; type < MAX_WEAPON_CLASS; type++)
	{
		for (int n_lev = 0; n_lev < 100; n_lev++)
		{
			int olvlmin, olvlmax;

			olvlmin = n_lev - 5;
			if (olvlmin < 0)
			{
				olvlmin = 0;
			}
			else if (olvlmin > 99)
			{
				olvlmin = 99;
			}

			olvlmax = n_lev + 5;
			if (olvlmax < 0)
			{
				olvlmax = 0;
			}
			else if (olvlmax > 99)
			{
				olvlmax = 99;
			}

			int i = 0;
			while (olvlex[type][olvlmin + i] == -1)
			{
				i++;
				if (olvlmin + i > olvlmax)
				{
					break;
				}
			}

			if (olvlmin + i > olvlmax)
			{
				lowhighex[type][n_lev][0] = -1;
			}
			else
			{
				lowhighex[type][n_lev][0] = olvlex[type][olvlmin + i];
				if (olvlmax > 98)
				{
					lowhighex[type][n_lev][1] = maxex[type] - 1;
				}
				else
				{
					int l = 1;
					while (olvlex[type][olvlmax + l] == -1)
					{
						l++;
						if (olvlmax + l > 99)
						{
							break;
						}
					}
					lowhighex[type][n_lev][1] = (olvlmax + l > 99) ? maxex[type] - 1 : olvlex[type][olvlmax + l] - 1;
				}
			}

			i = 0;
			while (olvlim[type][olvlmin + i] == -1)
			{
				i++;
				if (olvlmin + i > olvlmax)
					break;
			}

			if (olvlmin + i > olvlmax)
			{
				lowhighim[type][n_lev][0] = -1;
			}
			else
			{
				//lowhighim[type][n_lev][0] = (olvlmin+i>99)? maxim[type]-1 : olvlim[type][olvlmin+i];
				lowhighim[type][n_lev][0] = olvlim[type][olvlmin + i];
				if (olvlmax > 98)
				{
					lowhighim[type][n_lev][1] = maxim[type] - 1;
				}
				else
				{
					int l = 1;
					while (olvlim[type][olvlmax + l] == -1)
					{
						l++;
						if (olvlmax + l > 99)
						{
							break;
						}
					}
					lowhighim[type][n_lev][1] = (olvlmax + l > 99) ? maxim[type] - 1 : olvlim[type][olvlmax + l] - 1;
				}
			}
		}
	}
}
void GQOptions::LoadOption() {
	ZeroMemory(oplist, sizeof(oplist));
	ZeroMemory(oindex, sizeof(oindex));
	ZeroMemory(maxex, sizeof(maxex));
	ZeroMemory(maxim, sizeof(maxim));
	ZeroMemory(imoplist, sizeof(imoplist));
	ZeroMemory(exoplist, sizeof(exoplist));

	long rc = -1;
	int i = 0;

	HANDLE hRFile = CreateFile("data/Option.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		DWORD dwTemp;
		ReadFile(hRFile, &rc, sizeof(rc), &dwTemp, NULL);
		ReadFile(hRFile, oplist, sizeof(oplist), &dwTemp, NULL);
		ReadFile(hRFile, oindex, sizeof(oindex), &dwTemp, NULL);
		maxop = rc;
		for (i = 0; i < MAX_WEAPON_CLASS; i++)
		{
			maxex[i] = 0;
			maxim[i] = 0;
		}

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		makeoindex();

		for (i = 0; i < maxop; i++)
		{
			int av = oplist[i].availableon;
			int avgrade = oplist[i].avgrade;
			int olvl = oplist[i].optionlevel;
			if (olvl >= 0 && olvl < 100)
			{
				for (int j = 1; j < MAX_WEAPON_CLASS; j++)
				{
					int k = 1;
					k = k << (j - 1);
					if (av & k)
					{
						if (avgrade & 1)
						{
							if (maxex[j] >= MAX_OPTION_NUM)
								continue;
							if (olvlex[j][olvl] == -1)
								olvlex[j][olvl] = maxex[j];
							exoplist[j][maxex[j]++] = i;
						}
						if (avgrade & 2)
						{
							if (maxim[j] >= MAX_OPTION_NUM)
								continue;
							if (olvlim[j][olvl] == -1)
								olvlim[j][olvl] = maxim[j];
							imoplist[j][maxim[j]++] = i;
						}
					}
				}
			}
		}
		makeorange();
	}
}
void GQOptions::WriteOption() {
	printf("Begin Write Option.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Option.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("Option.CSV open error!!!\n");
		return;
	}
	oFile << "oid " << "," << "option_sort_id " << "," << "name " << "," << "description " << "," << "value_1 " << "," << "value_2 " << "," << "required_lvl " << "," << "option_lvl " << "," << "available_on " << "," << "avgrade " << "," << "multiple " << "," << "oclass " << "," << "classtype" << "\n";
	for (int i = 0; i < MAX_OPTION_NUM; i++) {
		if (oplist[i].optionid <= 0) {
			continue;
		}

		oFile << oplist[i].optionid << ",";
		oFile << oplist[i].optionsortid << ",";
		while (void * pi = memchr(oplist[i].name, ',', 50)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(oplist[i].name, '\n', 50)) {
			*((char *)pi) = '_';
		}
		oFile << oplist[i].name << ",";
		while (void * pi = memchr(oplist[i].description, ',', 100)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(oplist[i].description, '\n', 100)) {
			*((char *)pi) = '_';
		}
		oFile << oplist[i].description << ",";
		oFile << oplist[i].value1 << ",";
		oFile << oplist[i].value2 << ",";
		oFile << oplist[i].sRequiredLevel << ",";
		oFile << oplist[i].optionlevel << ",";
		oFile << oplist[i].availableon << ",";
		oFile << oplist[i].avgrade << ",";
		oFile << oplist[i].multiple << ",";
		oFile << oplist[i].oclass << ",";
		oFile << oplist[i].nClassType << "\n";
	}

	oFile.close();
	printf("End Write Option.CSV\n\n");
}



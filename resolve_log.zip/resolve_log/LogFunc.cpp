#include "LogFunc.h"

using namespace std;


extern list<USERLOG> listUser;
extern list<FIELDLOG> listField;
extern list<ITEMLOG> listItem;
extern list<GROWTHLOG> listGrowth;
extern list<SERVERLOG> listServer;

//���ܣ� ��ȡ�û���Ϣ�ļ�
//ͷ�ܳ���		ͷʵ�ʳ���		���ݳ���
//564			360				78
bool UserRead(string fileName) {
	LOG_FILE header;
	USERLOG tempUser;
	char buf[256] = { '\0' };
	FILE * fp_User = nullptr;
	strcpy_s(buf, fileName.c_str());
	fopen_s(&fp_User, buf, "r+b");
	if (fp_User) {
		fseek(fp_User, 0, SEEK_END);
		int fileLen = ftell(fp_User);
		int waitLen = fileLen;
		fseek(fp_User, 0, SEEK_SET);

		fread(&header, 1, sizeof(LOG_FILE), fp_User);
		fseek(fp_User, 203, SEEK_CUR);
		waitLen -= 564;

		while (waitLen > 0) {
			int readLen = fread(&tempUser, 1, 78, fp_User);
			if (readLen <= 0) {
				break;
			}
			waitLen -= 78;
			listUser.push_back(tempUser);
			ZeroMemory(&tempUser, sizeof(tempUser));
		}
	}
	else {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}
	fclose(fp_User);
	return true;
}

//���ܣ� ��ȡ������Ϣ�ļ�
//ͷ�ܳ���		ͷʵ�ʳ���		���ݳ���
//480			360				100 
bool FieldRead(string fileName) {
	LOG_FILE header;
	FIELDLOG tempField;
	char buf[256] = { '\0' };
	FILE * fp_Field = nullptr;
	strcpy_s(buf, fileName.c_str());
	fopen_s(&fp_Field, buf, "r+b");
	if (fp_Field) {
		fseek(fp_Field, 0, SEEK_END);
		int fileLen = ftell(fp_Field);
		int waitLen = fileLen;
		fseek(fp_Field, 0, SEEK_SET);

		fread(&header, 1, sizeof(LOG_FILE), fp_Field);
		fseek(fp_Field, 119, SEEK_CUR);
		waitLen -= 480;

		while (waitLen > 0) {
			int readLen = fread(&tempField, 1, 100, fp_Field);
			if (readLen <= 0) {
				break;
			}

			while (strchr((char *)tempField.strValue, ',') != nullptr) {
				int point = strchr((char *)tempField.strValue, ',') - (const char *)tempField.strValue;
				tempField.strValue[point] = '.';
			}
			waitLen -= 100;
			listField.push_back(tempField);
			ZeroMemory(&tempField, sizeof(tempField));
		}
	}
	else {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}
	fclose(fp_Field);
	return true;
}

//���ܣ� ��ȡ��Ʒ��Ϣ�ļ�
//ͷ�ܳ���		ͷʵ�ʳ���		���ݳ���
//620			360				134
bool ItemRead(string fileName) {
	LOG_FILE header;
	ITEMLOG tempItem;
	char buf[256] = { '\0' };
	FILE * fp_Item = nullptr;
	strcpy_s(buf, fileName.c_str());
	fopen_s(&fp_Item, buf, "r+b");
	if (fp_Item) {
		fseek(fp_Item, 0, SEEK_END);
		int fileLen = ftell(fp_Item);
		int waitLen = fileLen;
		fseek(fp_Item, 0, SEEK_SET);

		fread(&header, 1, sizeof(LOG_FILE), fp_Item);
		fseek(fp_Item, 259, SEEK_CUR);
		waitLen -= 620;

		while (waitLen > 0) {
			int readLen = fread(&tempItem, 1, 134, fp_Item);
			if (readLen <= 0) {
				break;
			}
			waitLen -= 134;
			listItem.push_back(tempItem);
			ZeroMemory(&tempItem, sizeof(tempItem));
		}
	}
	else {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}
	fclose(fp_Item);
	return true;
}

//���ܣ� ��ȡ�ɳ���Ʒ��Ϣ�ļ�
//ͷ�ܳ���		ͷʵ�ʳ���		���ݳ���
//472			360				100
bool GrowthRead(string fileName) {
	LOG_FILE header;
	GROWTHLOG tempGrowth;
	char buf[256] = { '\0' };
	FILE * fp_Growth = nullptr;
	strcpy_s(buf, fileName.c_str());
	fopen_s(&fp_Growth, buf, "r+b");
	if (fp_Growth) {
		fseek(fp_Growth, 0, SEEK_END);
		int fileLen = ftell(fp_Growth);
		int waitLen = fileLen;
		fseek(fp_Growth, 0, SEEK_SET);

		fread(&header, 1, sizeof(LOG_FILE), fp_Growth);
		fseek(fp_Growth, 111, SEEK_CUR);
		waitLen -= 472;

		while (waitLen > 0) {
			int readLen = fread(&tempGrowth, 1, 100, fp_Growth);
			if (readLen <= 0) {
				break;
			}
			waitLen -= 100;
			listGrowth.push_back(tempGrowth);
			ZeroMemory(&tempGrowth, sizeof(tempGrowth));
		}
	}
	else {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}
	fclose(fp_Growth);
	return true;
}

//���ܣ� ��ȡ������Ϣ�ļ�
//ͷ�ܳ���		ͷʵ�ʳ���		���ݳ���
//556			360				369
bool ServerRead(string fileName) {
	LOG_FILE header;
	SERVERLOG tempServer;
	char buf[256] = { '\0' };
	FILE * fp_Server = nullptr;
	strcpy_s(buf, fileName.c_str());
	fopen_s(&fp_Server, buf, "r+b");
	if (fp_Server) {
		fseek(fp_Server, 0, SEEK_END);
		int fileLen = ftell(fp_Server);
		int waitLen = fileLen;
		fseek(fp_Server, 0, SEEK_SET);

		fread(&header, 1, sizeof(LOG_FILE), fp_Server);
		fseek(fp_Server, 195, SEEK_CUR);
		waitLen -= 556;

		while (waitLen > 0) {
			int readLen = fread(&tempServer, 1, 369, fp_Server);
			if (readLen <= 0) {
				break;
			}

			while (strchr((char *)tempServer.strDescription, ',') != nullptr) {
				int point = strchr((char *)tempServer.strDescription, ',') - (const char *)tempServer.strDescription;
				tempServer.strDescription[point] = '.';
			}
			waitLen -= 369;
			listServer.push_back(tempServer);
			ZeroMemory(&tempServer, sizeof(tempServer));
		}
	}
	else {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}
	fclose(fp_Server);
	return true;
}


//ת���û���Ϣ
bool writeUserInfo(string fileName) {
	char tempBuf[1024] = {};
	char timeBuf[128] = { '\0' };
	time_t t;
	struct tm * stm;
	ofstream oFile;


	oFile.open(fileName.c_str(), ios::out);
	if (!oFile.is_open()) {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}

	//д��ͷ����
	oFile << "LogID" << ',';
	oFile << "�˺�" << ',';
	oFile << "��ɫ��" << ',';
	oFile << "�����¼�" << ',';
	oFile << "����������" << ',';
	oFile << "SerialC" << ',';
	oFile << "Time" << ',';
	oFile << "��������" << ',';
	oFile << '\n';

	//д��������Ϣ
	for (USERLOG tempUser : listUser) {
		oFile << tempUser.LogID << ',';
		oFile << tempUser.strAccount << ',';
		oFile << tempUser.strCharacter << ',';
		oFile << tempUser.stEvent << ',';
		oFile << tempUser.DateTime.dwTickCount << ',';
		oFile << tempUser.DateTime.dwTime << ',';
		t = tempUser.DateTime.dwTime;
		stm = gmtime(&t);
		strftime(timeBuf, 128, "%Y-%m-%d %H:%M:%S", stm);
		oFile << timeBuf << ',';
		oFile << tempUser.strServerKey << '\n';
	}

	oFile.close();
	return true;
}

//ת��������Ϣ
bool writeFieldInfo(string fileName) {
	char tempBuf[1024] = {};
	char timeBuf[128] = { '\0' };
	ofstream oFile;


	oFile.open(fileName.c_str(), ios::out);
	if (!oFile.is_open()) {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}

	//д��ͷ����
	oFile << "LogID" << ',';
	oFile << "zoneID" << ',';
	oFile << "zoneTitle" << '\n';

	//д��������Ϣ
	for (FIELDLOG tempField : listField) {
		oFile << tempField.LogID << ',';
		oFile << tempField.stCode << ',';
		oFile << tempField.strValue << '\n';
	}

	oFile.close();
	return true;
}


//ת���û���Ϣ
bool writeItemInfo(string fileName) {
	char tempBuf[1024] = {};
	char timeBuf[128] = { '\0' };
	time_t t;
	struct tm * stm;
	ofstream oFile;


	oFile.open(fileName.c_str(), ios::out);
	if (!oFile.is_open()) {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}

	//д��ͷ����
	oFile << "ServerLogID" << ',';
	oFile << "LogID" << ',';
	oFile << "ItemID" << ',';
	oFile << "SerialC" << ',';
	oFile << "SerialT" << ',';
	oFile << "Time" << ',';
	oFile << "ItemGrade" << ',';
	oFile << "isGrowth" << '\n';

	//д��������Ϣ
	for (ITEMLOG tempItem : listItem) {
		oFile << tempItem.ServerLogID << ',';
		oFile << tempItem.LogID << ',';
		oFile << tempItem.nItemID << ',';
		oFile << tempItem.SerialCount << ',';
		oFile << tempItem.SerialTime << ',';

		t = tempItem.SerialTime;
		stm = gmtime(&t);
		strftime(timeBuf, 128, "%Y-%m-%d %H:%M:%S", stm);
		oFile << timeBuf << ',';

		oFile << (int)tempItem.btGrade << ',';
		oFile << (int)tempItem.isGrowth << '\n';
	}

	oFile.close();
	return true;
}

//ת���ɳ���Ϣ
bool writeGrowthInfo(string fileName) {
	char tempBuf[1024] = {};
	char timeBuf[128] = { '\0' };
	time_t t;
	struct tm * stm;
	ofstream oFile;


	oFile.open(fileName.c_str(), ios::out);
	if (!oFile.is_open()) {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}

	//д��ͷ����
	oFile << "LogID" << ',';
	oFile << "Level" << ',';
	oFile << "Exp" << ',';
	oFile << "Name" << ',';
	oFile << "SerialC" << ',';
	oFile << "SerialT" << ',';
	oFile << "Time" << '\n';

	//д��������Ϣ
	for (GROWTHLOG tempGrowth : listGrowth) {
		oFile << tempGrowth.LogID << ',';
		oFile << tempGrowth.dwLevel << ',';
		oFile << tempGrowth.dwExp << ',';
		oFile << tempGrowth.GrowthData.name << ',';
		oFile << tempGrowth.GrowthData.serialc << ',';
		oFile << tempGrowth.GrowthData.serialt << ',';

		t = tempGrowth.GrowthData.serialt;
		stm = gmtime(&t);
		strftime(timeBuf, 128, "%Y-%m-%d %H:%M:%S", stm);
		oFile << timeBuf << '\n';
	}

	oFile.close();
	return true;
}

//ת��������Ϣ
bool writeServerInfo(string fileName) {
	char tempBuf[1024] = {};
	char timeBuf[128] = { '\0' };
	time_t t;
	struct tm * stm;
	ofstream oFile;


	oFile.open(fileName.c_str(), ios::out);
	if (!oFile.is_open()) {
		cout << fileName.c_str() << " open error!" << endl;
		return false;
	}

	//д��ͷ����
	oFile << "LogID" << ',';
	oFile << "ServerKey" << ',';
	oFile << "SerialC" << ',';
	oFile << "SerialT" << ',';
	oFile << "Time" << ',';
	oFile << "Class" << ',';
	oFile << "Event" << ',';
	oFile << "Value" << ',';
	oFile << "Descrip" << '\n';

	//д��������Ϣ
	for (SERVERLOG tempServer : listServer) {
		oFile << tempServer.LogID << ',';
		oFile << tempServer.strServerKey << ',';
		oFile << tempServer.DateTime.dwTickCount << ',';
		oFile << tempServer.DateTime.dwTime << ',';

		t = tempServer.DateTime.dwTime;
		stm = gmtime(&t);
		strftime(timeBuf, 128, "%Y-%m-%d %H:%M:%S", stm);
		oFile << timeBuf << ',';

		oFile << (int)tempServer.btClass << ',';
		oFile << tempServer.stEvent << ',';
		oFile << tempServer.strValue << ',';
		oFile << tempServer.strDescription << '\n';
	}

	oFile.close();
	return true;
}
#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"


class GQZone
{
public:
	GQZone();
	~GQZone();

	SZone m_Zonelist[MAX_ZONE];
	void LoadZone();
	

	CNotUseZone m_NotUseZoneList;
	CSimpleDataTable DataTable;
	INT nTempZoneList[MAX_ZONE];
	bool LoadNotUseZoneList();

	CHuntingZone m_HuntingZoneList;
	CSimpleDataTable	DataTable1;
	bool LoadHuntingZoneList();


	void GQWrite();
};


#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQSkill
{
public:
	GQSkill();
	~GQSkill();

	typedef std::multimap < int, STItemSkillGroup * > mmapItemSkillGroup;
	mmapItemSkillGroup m_mapItemSkillGroup;
	bool LoadItemSkillGroupData();

	CSSkill	m_Skilllist[MAX_SKILL_CODE];
	int m_nMaxskill;
	void LoadSkill();
	void WriteSkill();


	void LoadOSkill();
};


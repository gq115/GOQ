#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQNPCProto
{
public:
	GQNPCProto();
	~GQNPCProto();

public:
	NPCProto m_protolist[MAX_NPC_PROTO];
	short m_protoindex[MAX_NPC_CODE];
	int		m_num_nt;
	void makepindex();
	void LoadNPCProto();

	CSimpleDataTable	m_tblSummonNPCItem;
	bool LoadSummonNPCItemData();

	HANDLE		m_hSleepEvent;
	npcinfo*	m_npclist[MAX_NPC];
	DWORD m_npclistFlags[MAX_NPC / 32 + 1];
	DWORD m_npclistDelayTimeFlags[MAX_NPC / 32 + 1];

	snpcinfo *snpclist[MAX_SUMMON_NPC];
	bool LoadSNPCList();


	int m_summnpcnum;
	void Initialize1();

	bool setbasenpcinfo(BaseNPCInfo *bninfo, int index);
	int		m_npcnum;
	int m_nMaxNPC;
	void LoadNPCList();

	void GQWrite();
};


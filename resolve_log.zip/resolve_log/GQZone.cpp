#include "GQZone.h"
using namespace std;


GQZone::GQZone()
{
}


GQZone::~GQZone()
{
}

void GQZone::LoadZone() {
	HANDLE hRFile = CreateFile("data/Zone.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - Zone.dat  \n");
		ZeroMemory(m_Zonelist, sizeof(m_Zonelist));

		DWORD dwTemp;
		ReadFile(hRFile, m_Zonelist, sizeof(m_Zonelist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - Zone.dat END \n");
	}
}

bool GQZone::LoadNotUseZoneList() {
	PST_NOTUSEZONELIST pNotUseZoneList;
	USHORT usIndex = 0;

	if (!DataTable.Open("data\\NotUseZoneList.dat"))
	{
		return FALSE;
	}

	STATE stItem = DataTable.GetFirstItem();
	while (pNotUseZoneList = (PST_NOTUSEZONELIST)DataTable.GetNextItem(stItem))
	{
		nTempZoneList[usIndex++] = pNotUseZoneList->nZone;
	}

	if (0 == usIndex)
	{
		return FALSE;
	}

	m_NotUseZoneList.SetZone(nTempZoneList, sizeof(INT) * usIndex, usIndex);

	return TRUE;
}

bool GQZone::LoadHuntingZoneList() {
	PST_HUNTINGZONE		pHuntingZone;
	INT					nHuntingZoneCount = 0;

	if (!DataTable1.Open("data\\HuntingZoneList.dat"))
	{
		return FALSE;
	}

	STATE stItem = DataTable1.GetFirstItem();
	while (pHuntingZone = (PST_HUNTINGZONE)DataTable1.GetNextItem(stItem))
	{
		if (TRUE == m_HuntingZoneList.SetHuntingZone(pHuntingZone))
		{
			++nHuntingZoneCount;
		}
		else
		{
			return FALSE;
		}
	}

	if (0 == nHuntingZoneCount)
	{
		return FALSE;
	}

	return TRUE;
}


void GQZone::GQWrite() {
	printf("Begin Write Zone.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Zone.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("Zone.CSV setitem error!!!\n");
		return;
	}
	oFile << "zoneId " << "," << "zonetype " << "," << "zoneLevel " << "," << "zoneGold " << "," << "doorCount " << "," << "startXPos " << "," << "startYPos " << "," << "startZPos " << "," << "superZoneId " << "," << "isRoom " << "," << "direction " << "," << "athread " << "," << "MinLevel " << "," << "MaxLevel " << "," << "Class" << "\n";
	for (int i = 0; i < MAX_ZONE; i++) {
		if (m_Zonelist[i].m_nZoneId <= -1) {
			continue;
		}
		oFile << m_Zonelist[i].m_nZoneId << ",";
		oFile << m_Zonelist[i].m_sType << ",";
		oFile << (int)m_Zonelist[i].m_nZoneLevel << ",";
		oFile << m_Zonelist[i].m_sZoneGold << ",";
		oFile << (int)m_Zonelist[i].m_DoorCount << ",";
		oFile << m_Zonelist[i].m_StartingPoint.x << ",";
		oFile << m_Zonelist[i].m_StartingPoint.y << ",";
		oFile << m_Zonelist[i].m_StartingPoint.z << ",";
		oFile << m_Zonelist[i].m_nSuperZoneId << ",";
		oFile << m_Zonelist[i].m_nIsRoom << ",";
		oFile << m_Zonelist[i].m_nDirection << ",";
		oFile << m_Zonelist[i].m_sAthread << ",";
		oFile << m_Zonelist[i].m_sMinlevel << ",";
		oFile << m_Zonelist[i].m_sMaxlevel << ",";
		oFile << m_Zonelist[i].m_nClass << "\n";
	}

	oFile.close();
	printf("End Write Zone.CSV\n");



	printf("Begin Write NotUseZoneList.CSV\n");
	oFile.open("dataCSV/NotUseZoneList.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("NotUseZoneList.CSV setitem error!!!\n");
		return;
	}
	oFile << "Zone" << "\n";
	for (int i = 0; i < MAX_ZONE; i++) {
		if (nTempZoneList[i] <= -1) {
			continue;
		}

		oFile << nTempZoneList[i] << "\n";
	}

	oFile.close();
	printf("End Write NotUseZoneList.CSV\n");



	printf("Begin Write HuntingZoneList.CSV\n");
	oFile.open("dataCSV/HuntingZoneList.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("HuntingZoneList.CSV setitem error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	ST_HUNTINGZONE	*pHunt = NULL;
	oFile << "Kind " << "," << "MinLevel " << "," << "MaxLevel " << "," << "ResiFire " << "," << "ResiWater " << "," << "ResiLightning " << "," << "ResiPoison " << "," << "Item1 " << "," << "Item2 " << "," << "Item3 " << "," << "Item4 " << "," << "Item5 " << "," << "Item6 " << "," << "Item7 " << "," << "Item8 " << "," << "Item9 " << "," << "Item10 " << "," << "Skill1 " << "," << "Skill2 " << "," << "Skill3 " << "," << "Skill4 " << "," << "Skill5 " << "," << "Skill6 " << "," << "Skill7 " << "," << "Skill8 " << "," << "Skill9 " << "," << "Skill10" << "\n";
	state = DataTable1.GetFirstItem();
	while (pData = DataTable1.GetNextItem(state)) {
		pHunt = (ST_HUNTINGZONE *)pData;
		if (pHunt == NULL) {
			continue;
		}
		oFile << pHunt->nKind << ",";
		oFile << pHunt->sMinLevel << ",";
		oFile << pHunt->sMaxLevel << ",";
		oFile << pHunt->sResiFire << ",";
		oFile << pHunt->sResiWater << ",";
		oFile << pHunt->sResiLightning << ",";
		oFile << pHunt->sResiPoison << ",";
		oFile << pHunt->nItemID[0] << ",";
		oFile << pHunt->nItemID[1] << ",";
		oFile << pHunt->nItemID[2] << ",";
		oFile << pHunt->nItemID[3] << ",";
		oFile << pHunt->nItemID[4] << ",";
		oFile << pHunt->nItemID[5] << ",";
		oFile << pHunt->nItemID[6] << ",";
		oFile << pHunt->nItemID[7] << ",";
		oFile << pHunt->nItemID[8] << ",";
		oFile << pHunt->nItemID[9] << ",";

		oFile << pHunt->wdSkillID[0] << ",";
		oFile << pHunt->wdSkillID[1] << ",";
		oFile << pHunt->wdSkillID[2] << ",";
		oFile << pHunt->wdSkillID[3] << ",";
		oFile << pHunt->wdSkillID[4] << ",";
		oFile << pHunt->wdSkillID[5] << ",";
		oFile << pHunt->wdSkillID[6] << ",";
		oFile << pHunt->wdSkillID[7] << ",";
		oFile << pHunt->wdSkillID[8] << ",";
		oFile << pHunt->wdSkillID[9] << "\n";
	}

	oFile.close();
	printf("End Write HuntingZoneList.CSV\n");
}
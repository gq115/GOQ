#pragma once

#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

#pragma pack(1)
class DatFunc
{
public:
	DatFunc();
	~DatFunc();




	SMoneyInOut m_Smio[MAX_ZONE];
	void LoadTaxFile();

	LottoTime	*m_TimeTable;
	int m_iLottoCount;
	bool GetLottoList();

	CTeleport				m_cTeleport;
	CQueue3					m_queInstanceMsg;
	CMultiScroll			m_cMultiScroll;
	CHonorRewardList		m_cHonorRewardList;
	CTitleList				m_cTitleList;
	CCollectionBookTable	m_cCollectionBook;
	CPVPGrade				m_cPVPGrade;
	CGuildLevel				m_cGuildLevel;
	void CreateModuleMap();

	short m_aistate[MAX_STATECHPATTERN][MAX_STATE][MAX_CIRCUMSTANCE][2];
	bool LoadAIStateData();

	decision m_aidecision[MAX_DECISION_CODE][MAX_STATE][MAX_VALUE_NUM];
	bool LoadAIDecisionData();

	short m_aipattern[MAX_AI_CODE][3];
	bool LoadAIPatternData();


	SLevel m_Levellist[MAX_LEVEL_2ND_MASTER];
	void LoadExpGoal();

	SCharacterClass m_ChrClass[100];
	void LoadCharacterClass();

	SGrade m_gradelist[MAX_GRADE];
	void LoadGrade();

	int m_nMopnum;
	
	SMOption m_Moplist[MAX_MONSTER_OPTION];
	void LoadMOption();

	
	int m_nMaxvirnum;
	SVirtue m_Virlist[MAX_VIRTUE];
	void LoadVirtue();

	CSimpleDataTable	m_cTable;
	bool LoadMode();


	short aistate[MAX_STATECHPATTERN][MAX_STATE][MAX_CIRCUMSTANCE][2];
	bool LoadAIState();

	decision aidecision[MAX_DECISION_CODE][MAX_STATE][MAX_VALUE_NUM];
	bool LoadAIDecision();

	short aipattern[MAX_AI_CODE][3];
	bool LoadAIPattern();
};
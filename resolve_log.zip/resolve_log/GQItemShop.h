#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQItemShop
{
public:
	GQItemShop();
	~GQItemShop();

	CNewItemShopList		m_cNewItemShopList;
	void GQOpen();
	void GQWrite();
};


#include "GQSkill.h"
using namespace std;


GQSkill::GQSkill()
{
}


GQSkill::~GQSkill()
{
}

bool GQSkill::LoadItemSkillGroupData() {
	DATATABLE_HEADER	header;
	DWORD	dwResult;
	LPVOID	pData;
	DWORD	num;

	HANDLE hRFile = CreateFile("data/ItemSkillGroup.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!! : data/ItemSkillGroup.dat \n");

		return FALSE;
	}
	else
	{
		if (!ReadFile(hRFile, (LPVOID)&header, sizeof(DATATABLE_HEADER), &dwResult, NULL))
		{
			return FALSE;
		}

		for (num = 0; num < header.dwRecordCount; num++)
		{
			pData = new CHAR[header.wRecordSize];
			if (!ReadFile(hRFile, pData, header.wRecordSize, &dwResult, NULL))
			{
				delete[]pData;
				break;
			}

			if (header.wRecordSize != dwResult)
			{
				delete[]pData;
				break;
			}

			STItemSkillGroup aItemSkill;
			memcpy(&aItemSkill, pData, sizeof(STItemSkillGroup));
			//m_mapItemSkillGroup.insert( mmapItemSkillGroup::value_type( aItemSkill.nGroupID, &aItemSkill ) );
			m_mapItemSkillGroup.insert(mmapItemSkillGroup::value_type(aItemSkill.nGroupID, (STItemSkillGroup*)pData));
		}

		CloseHandle(hRFile);
	}

	return TRUE;
}

void GQSkill::LoadSkill() {
	HANDLE hRFile = CreateFile("data/Skill.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - Skill.dat  \n");
		ZeroMemory(m_Skilllist, sizeof(m_Skilllist));

		DWORD dwTemp;
		ReadFile(hRFile, &m_nMaxskill, sizeof(m_nMaxskill), &dwTemp, NULL);
		ReadFile(hRFile, m_Skilllist, sizeof(m_Skilllist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - Skill.dat END \n");
	}
}
void GQSkill::WriteSkill() {
	printf("Begin Write Skill.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Skill.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("Skill.CSV open error!!!\n");
		return;
	}

	oFile << "s_id " << "," << "s_name_k " << "," << "s_name_e " << "," << "s_type " << "," << "s_target " << "," << "s_att " << "," << "s_vid1 " << "," << "s_vid2 " << "," << "s_vid3 " << "," << "s_vid4 " << "," << "s_vid5 " << "," << "s_vid6 " << "," << "s_vid7 " << "," << "s_vid8 " << "," << "s_vid9 " << "," << "s_vid10 " << "," << "s_targetrange " << "," << "s_desc " << "," << "s_maxslvl " << "," << "s_casttime " << "," << "s_areatype" << "\n";
	for (int i = 0; i < MAX_SKILL_CODE; i++) {
		if (m_Skilllist[i].m_nSkillid <= 0) {
			continue;
		}
		oFile << m_Skilllist[i].m_nSkillid << ",";
		while (void * pi = memchr(m_Skilllist[i].m_szNamek, ',', 50)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(m_Skilllist[i].m_szNamek, '\n', 50)) {
			*((char *)pi) = '_';
		}
		oFile << m_Skilllist[i].m_szNamek << ",";
		while (void * pi = memchr(m_Skilllist[i].m_szNamee, ',', 50)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(m_Skilllist[i].m_szNamee, '\n', 50)) {
			*((char *)pi) = '_';
		}
		oFile << m_Skilllist[i].m_szNamee << ",";
		oFile << m_Skilllist[i].m_chType << ",";
		oFile << m_Skilllist[i].m_chTarget << ",";
		oFile << m_Skilllist[i].m_nAtt << ",";
		oFile << m_Skilllist[i].m_nVid[0] << ",";
		oFile << m_Skilllist[i].m_nVid[1] << ",";
		oFile << m_Skilllist[i].m_nVid[2] << ",";
		oFile << m_Skilllist[i].m_nVid[3] << ",";
		oFile << m_Skilllist[i].m_nVid[4] << ",";
		oFile << m_Skilllist[i].m_nVid[5] << ",";
		oFile << m_Skilllist[i].m_nVid[6] << ",";
		oFile << m_Skilllist[i].m_nVid[7] << ",";
		oFile << m_Skilllist[i].m_nVid[8] << ",";
		oFile << m_Skilllist[i].m_nVid[9] << ",";
		oFile << m_Skilllist[i].m_sTargetrange << ",";
		while (void * pi = memchr(m_Skilllist[i].m_szDesc, ',', 200)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(m_Skilllist[i].m_szDesc, '\n', 200)) {
			*((char *)pi) = '_';
		}
		oFile << m_Skilllist[i].m_szDesc << ",";
		oFile << m_Skilllist[i].m_sMaxslvl << ",";
		oFile << m_Skilllist[i].m_nCasttime << ",";
		oFile << (int)m_Skilllist[i].m_nAreatype << "\n";
		//CSSkillLevel m_Slvl[MAX_SLVL];
	}

	oFile.close();
	printf("Begin Write Skill.CSV\n");
}



void GQSkill::LoadOSkill() {}

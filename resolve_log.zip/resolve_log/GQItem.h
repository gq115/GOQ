#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQItem
{
public:
	GQItem();
	~GQItem();

	void makeirange();
	void makegirange();
	void LoadBaseItem();
	void WriteBaseItem();


public:
	baseitem		bitemlist[MAX_BASE_ITEM];
	unsigned int	bitemindex[MAX_BASE_ITEM_CODE];
	int				numbitem;
	int 	ilvllist[7][MAX_LEVEL];				//0: special weapon, 1: special armor, 2: special accessory, 3: weapon, 4: armor 5: accessory 6:potion 
	int 	lowhigh[7][MAX_LEVEL][2];
	int 	basetypelist[7][MAX_BASE_ITEM];
	int 	gbasetypelist[MAX_WEAPON_CLASS][MAX_BASE_ITEM];
	int 	gmaxtype[MAX_WEAPON_CLASS];
	int 	glowhigh[MAX_WEAPON_CLASS][100][2];
	int 	gilvllist[MAX_WEAPON_CLASS][100];
	int 	maxtype[7];
};


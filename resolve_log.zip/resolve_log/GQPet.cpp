#include "GQPet.h"
using namespace std;

GQPet::GQPet()
{
}


GQPet::~GQPet()
{
}

void GQPet::GQOpen() {
	printf("Begin Load Pet.dat\n");
	if ( m_cPetData.Open("data\\Pet.dat")) {
		printf("End Load Pet.dat\n");
	}
	else {
		printf("Error Load Pet.dat\n");
	}
	return;
}

void GQPet::GQWrite() {
	printf("Begin Write Pet.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Pet.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("Pet.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	SPetItem	*pPet = NULL;
	state = m_cPetData.GetFirstItem();
	oFile << "pitemid " << "," << "plevel " << "," << "nextexp " << "," << "nextpitemid " << "," << "curhpdown " << "," << "maxhpdown " << "," << "curmaxstash " << "," << "petoption " << "," << "petfunction" << "\n";
	while (pData = m_cPetData.GetNextItem(state)) {
		pPet = (SPetItem *)pData;
		if (pPet->nItemID <= -1)
			continue;
		if ( pPet == NULL ) {
			continue;
		}
		oFile << pPet->nItemID << ",";
		oFile << pPet->sLevel << ",";
		oFile << pPet->nNextExp << ",";
		oFile << pPet->nNextItemID << ",";
		oFile << pPet->sCurHPDown << ",";
		oFile << pPet->sMaxHPDown << ",";
		oFile << pPet->sCurMaxStash << ",";
		oFile << pPet->sPetOption << ",";
		oFile << pPet->sPetFunction << "\n";
	}

	oFile.close();
	printf("End Write Pet.CSV\n");
}
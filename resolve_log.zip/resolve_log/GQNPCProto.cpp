#include "GQNPCProto.h"
using namespace std;


GQNPCProto::GQNPCProto()
{
}


GQNPCProto::~GQNPCProto()
{
}

void GQNPCProto::makepindex()
{
	for (int i = 0; i < MAX_NPC_PROTO; i++)
	{
		int n_cd = m_protolist[i].m_cd;
		if (n_cd == 16)
		{
			int a = 0;
		}

		if (n_cd >= 0 && n_cd < MAX_NPC_CODE)
		{
			m_protoindex[n_cd] = i;
		}
	}
}
void GQNPCProto::LoadNPCProto() {
	HANDLE hRFile = CreateFile("data/NpcProto.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file open error!!!\n");
	}
	else
	{
		DWORD dwTemp;
		ZeroMemory(m_protolist, sizeof(m_protolist));
		ZeroMemory(m_protoindex, sizeof(m_protoindex));
		ReadFile(hRFile, m_protolist, sizeof(m_protolist), &dwTemp, NULL);
		makepindex();
		/*for (int i = 0; i < MAX_NPC; i++)
		{
			m_npclist[i]->setProtoChanged(true);
		}*/
		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);
		CloseHandle(hRFile);
	}
}


bool GQNPCProto::LoadSNPCList() {
	HANDLE hFile;
	DWORD dwTemp;
	int tnpcnum;
	hFile = CreateFile("data/npclist.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		for (int k = 0; k < MAX_SUMMON_NPC; k++)
		{
			snpclist[k] = new snpcinfo;
		}
		ReadFile(hFile, &tnpcnum, sizeof(int), &dwTemp, NULL);
		if (tnpcnum > MAX_SUMMON_NPC)
		{
			CloseHandle(hFile);
			return false;
		}

		ReadFile(hFile, snpclist, sizeof(snpcinfo)*MAX_SUMMON_NPC, &dwTemp, NULL);
		if (sizeof(snpcinfo)*MAX_SUMMON_NPC != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}

		CloseHandle(hFile);
		m_summnpcnum = tnpcnum;
		return true;
	}
	return false;
}

void GQNPCProto::Initialize1() {
	long rc = -1;
	HANDLE hRFile = CreateFile("data/NpcList.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file open error!!!\n");
	}
	else
	{

		DWORD dwTemp;
		BaseNPCInfo ninformation;

		ReadFile(hRFile, &rc, sizeof(rc), &dwTemp, NULL);

		int index = 0;
		for (int i = 0; i < rc; i++)
		{
			if (index < MAX_SUMMON_NPC)
			{
				ReadFile(hRFile, &ninformation, sizeof(ninformation), &dwTemp, NULL);

				snpclist[index]->SetBaseSummonInfo(&ninformation, index);
				index++;
			}
		}

		CloseHandle(hRFile);

		m_summnpcnum = index;
	}
}


bool GQNPCProto::LoadSummonNPCItemData() {
	STATE	state;
	ST_SUMMONNPCITEM *pTable;
	int		nPrevTotalRate;
	int		nCurItemID;

	if (!m_tblSummonNPCItem.Open("data\\SummonNPCItem.dat"))
	{
		return FALSE;
	}

	state = m_tblSummonNPCItem.GetFirstItem();

	//Rate Converting
	nCurItemID = 0;
	nPrevTotalRate = 0;
	while (pTable = (ST_SUMMONNPCITEM *)m_tblSummonNPCItem.GetNextItem(state))
	{
		if (nCurItemID != pTable->nItemID)
		{
			nCurItemID = pTable->nItemID;
			nPrevTotalRate = pTable->wRate;
			continue;
		}

		pTable->wRate = (WORD)(pTable->wRate + nPrevTotalRate);
		nPrevTotalRate = pTable->wRate;
	}

	return TRUE;
}



bool GQNPCProto::setbasenpcinfo(BaseNPCInfo *bninfo, int index)
{
	//proto���� �ش� npc������ ã�� �ִ´�.
	int n_cd = bninfo->m_cd;

	if (n_cd >= 0 && n_cd < MAX_NPC_CODE)
	{
		short pindex = m_protoindex[n_cd];
		if (pindex >= 0 && pindex < MAX_NPC_PROTO)
		{
			m_npclist[index]->SetBaseNPCInfo(bninfo, &m_protolist[pindex], index);
			m_npclistFlags[index / 32] |= 1 << (index % 32);
			return true;
		}
		else
		{
			_RPTF2(_CRT_WARN, "pindex -%d , n_cd - %d\n", pindex, n_cd);
		}
	}
	else
	{
		_RPTF1(_CRT_WARN, "n_cd -%d\n", n_cd);
	}
	return false;
}
void GQNPCProto::LoadNPCList() {
	long rc = -1;
	HANDLE hRFile = CreateFile("data/NpcList.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file open error!!!\n");
	}
	else
	{
		for (int k = 0; k < MAX_NPC; k++)
		{
			m_npclist[k] = new npcinfo;
		}
		for (int j = 0; j < MAX_ZONE; j++)
		{
			//g_older.m_Zonelist[j].m_nNpccount = 0;
		}


		DWORD dwTemp;
		BaseNPCInfo ninformation;

		ReadFile(hRFile, &rc, sizeof(rc), &dwTemp, NULL);

		int index = 1;
		for (int i = 0; i < rc; i++)
		{
			if (index < MAX_NPC)
			{
				ReadFile(hRFile, &ninformation, sizeof(ninformation), &dwTemp, NULL);
				int zone = ninformation.m_zone;
				if (zone >= 0 && zone < MAX_ZONE)
				{
					if (setbasenpcinfo(&ninformation, index))
					{
						index++;
					}
				}
			}
		}
		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);
		m_npcnum = index;
		m_nMaxNPC = index;
		CloseHandle(hRFile);
	}
}


void GQNPCProto::GQWrite() {
	printf("Begin Write NpcList.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/NpcList.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("NpcList.CSV open error!!!\n");
		return;
	}
	oFile << "n_cd " << "," << "n_ai " << "," << "n_point_x " << "," 
		<< "n_point_y " << "," << "n_point_z " << "," << "zone_num " << "," 
		<< "npcreaction " << "," << "npcaipatterncode " << "," 
		<< "direction " << "," << "dangerhp " << "," << "ID" << "\n";
	for (int i = 0; i < MAX_NPC; i++) {
		if (m_npclist[i] == NULL) {
			continue;
		}
		if (m_npclist[i]->m_info.m_id <= 0) {
			continue;
		}
		oFile << m_npclist[i]->m_info.m_cd << ",";
		oFile << m_npclist[i]->m_info.m_ai << ",";
		oFile << m_npclist[i]->m_info.m_point.x << ",";
		oFile << m_npclist[i]->m_info.m_point.y << ",";
		oFile << m_npclist[i]->m_info.m_point.z << ",";
		oFile << m_npclist[i]->m_info.m_zone << ",";
		oFile << m_npclist[i]->m_info.m_npcreaction << ",";
		oFile << m_npclist[i]->m_info.m_aipattern << ",";
		oFile << m_npclist[i]->m_info.m_direction << ",";
		oFile << m_npclist[i]->m_info.m_dangerhp << ",";
		oFile << m_npclist[i]->m_info.m_id << "\n";
	}

	oFile.close();
	printf("End Write NpcList.CSV\n");


	printf("Begin Write NpcProto.CSV\n");
	oFile.open("dataCSV/NpcProto.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("NpcProto.CSV open error!!!\n");
		return;
	}
	oFile << "n_cd " << "," << "n_namek " << "," << "n_namee " << "," << "n_height " << "," << "n_hp " << "," << "n_exp " << "," << "n_def " << "," << "n_defrate " << "," << "n_attd_min " << "," << "n_attd_max " << "," << "n_attrate " << "," << "n_critic_prob " << "," << "n_critic " << "," << "n_resi_fire " << "," << "n_resi_water " << "," << "n_resi_light " << "," << "n_resi_poiso " << "," << "n_spd " << "," << "n_reg " << "," << "n_hostile " << "," << "n_seelev " << "," << "n_lev " << "," << "n_bodysize " << "," << "n_attackrange " << "," << "n_reactionrange " << "," << "n_grade " << "," << "n_sid1 " << "," << "n_slvl1 " << "," << "n_sid2 " << "," << "n_slvl2 " << "," << "n_sid3 " << "," << "n_slvl3 " << "," << "n_sid4 " << "," << "n_slvl4 " << "," << "n_sid5 " << "," << "n_slvl5 " << "," << "n_attd_mag " << "," << "n_attd_magcd " << "," << "n_hpspd " << "," << "n_elementcode " << "," << "n_elementdmg " << "," << "n_elementprob " << "," << "n_quest" << "\n";
	for (int i = 0; i < MAX_NPC_PROTO; i++) {
		if (m_protolist[i].m_cd <= 0) {
			continue;
		}
		oFile << m_protolist[i].m_cd << ",";
		while (void * pi = memchr(m_protolist[i].m_namek, ',', MNAME_LENGTH)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(m_protolist[i].m_namek, '\n', MNAME_LENGTH)) {
			*((char *)pi) = '_';
		}
		oFile << m_protolist[i].m_namek << ",";
		while (void * pi = memchr(m_protolist[i].m_namee, ',', MNAME_LENGTH)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(m_protolist[i].m_namee, '\n', MNAME_LENGTH)) {
			*((char *)pi) = '_';
		}
		oFile << m_protolist[i].m_namee << ",";
		oFile << (int)m_protolist[i].m_height << ",";
		oFile << m_protolist[i].m_hp << ",";
		oFile << m_protolist[i].m_exp << ",";
		oFile << m_protolist[i].m_def << ",";
		oFile << m_protolist[i].m_defrate << ",";
		oFile << m_protolist[i].m_attd_min << ",";
		oFile << m_protolist[i].m_attd_max << ",";
		oFile << m_protolist[i].m_attrate << ",";
		oFile << (int)m_protolist[i].m_critic_prob << ",";
		oFile << (int)m_protolist[i].m_critic << ",";
		oFile << m_protolist[i].m_resi_fire << ",";
		oFile << m_protolist[i].m_resi_water << ",";
		oFile << m_protolist[i].m_resi_light << ",";
		oFile << m_protolist[i].m_resi_poiso << ",";
		oFile << (int)m_protolist[i].m_spd << ",";
		oFile << (int)m_protolist[i].m_reg << ",";
		oFile << (int)m_protolist[i].m_hostile << ",";
		oFile << m_protolist[i].m_sSeeLev << ",";
		oFile << m_protolist[i].m_lev << ",";
		oFile << m_protolist[i].m_body_size << ",";
		oFile << m_protolist[i].m_attack_range << ",";
		oFile << m_protolist[i].m_reaction_range << ",";
		oFile << m_protolist[i].m_grade << ",";
		oFile << m_protolist[i].m_sid[0] << ",";
		oFile << m_protolist[i].m_slvl[0] << ",";
		oFile << m_protolist[i].m_sid[1] << ",";
		oFile << m_protolist[i].m_slvl[1] << ",";
		oFile << m_protolist[i].m_sid[2] << ",";
		oFile << m_protolist[i].m_slvl[2] << ",";
		oFile << m_protolist[i].m_sid[3] << ",";
		oFile << m_protolist[i].m_slvl[3] << ",";
		oFile << m_protolist[i].m_sid[4] << ",";
		oFile << m_protolist[i].m_slvl[4] << ",";
		oFile << m_protolist[i].m_attd_mag << ",";
		oFile << m_protolist[i].m_attd_magcd << ",";
		oFile << (int)m_protolist[i].m_hpspd << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << ",";
		oFile << 0 << "\n";
	}

	oFile.close();
	printf("End Write NpcProto.CSV\n");
}
#include "GQPeriodEffect.h"
using namespace std;


GQPeriodEffect::GQPeriodEffect()
{
}


GQPeriodEffect::~GQPeriodEffect()
{
}


void GQPeriodEffect::GQOpen() {
	printf("Begin Load PeriodEffect.dat\n");
	if (m_cEffect.Open("data\\PeriodEffect.dat")) {
		printf("End Load PeriodEffect.dat\n");
	}
	else {
		printf("Error NewGrowth PeriodEffect.dat\n");
	}
	return;
}

void GQPeriodEffect::GQWrite() {
	printf("Begin Write PeriodEffect.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/PeriodEffect.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("PeriodEffect.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	struct EFFECT_TABLE_BASE	*pEffect = NULL;
	oFile << "EffectIndex " << "," << "Comment " << "," << "RemainTimePerMin " << "," << "TimeType " << "," << "ApplyType " << "," << "Desc " << "," << "Class " << "," << "Level " << "," << "Function " << "," << "Parameta1 " << "," << "Parameta2 " << "," << "Parameta3 " << "," << "Parameta4 " << "," << "Parameta5 " << "," << "Parameta6 " << "," << "Parameta7 " << "," << "Parameta8 " << "," << "Parameta9 " << "," << "Parameta10 " << "\n";
	state = m_cEffect.GetFirstItem();
	while (pData = m_cEffect.GetNextItem(state)) {
		pEffect = (struct EFFECT_TABLE_BASE *)pData;
		if (pEffect->wEffectIndex <= -1)
			continue;
		if (pEffect == NULL) {
			continue;
		}
		oFile << pEffect->wEffectIndex << ",";
		oFile << (char *)pEffect->reserved << ",";
		oFile << pEffect->nRemainTimePerMin << ",";
		oFile << (int)pEffect->btTimeType << ",";
		oFile << (int)pEffect->btApplyType << ",";
		oFile << pEffect->strDesc << ",";
		oFile << pEffect->wClass << ",";
		oFile << pEffect->btLevel << ",";
		oFile << pEffect->wFunction << ",";
		oFile << pEffect->wParameta[0] << ",";
		oFile << pEffect->wParameta[1] << ",";
		oFile << pEffect->wParameta[2] << ",";
		oFile << pEffect->wParameta[3] << ",";
		oFile << pEffect->wParameta[4] << ",";
		oFile << pEffect->wParameta[5] << ",";
		oFile << pEffect->wParameta[6] << ",";
		oFile << pEffect->wParameta[7] << ",";
		oFile << pEffect->wParameta[8] << ",";
		oFile << pEffect->wParameta[9] << "\n";
	}

	oFile.close();
	printf("End Write PeriodEffect.CSV\n");
}

#include "myConmon.h"

////////////////////////////////////////////////////////////////////////
///////////////////////////// CStack ///////////////////////////////////
////////////////////////////////////////////////////////////////////////
CStack::CStack()
{
	Clean();
}

CStack::~CStack()
{
	Destroy();
}

void CStack::Initialize(int nCount)
{
	if (m_pBuffer)
	{
		Destroy();
	}

	m_pBuffer = (int *)new DWORD[nCount];
	_ASSERTE(m_pBuffer);
	if (m_pBuffer == NULL)
	{
		return;
	}

	m_nMaxStackSize = nCount;
}

BOOL CStack::Push(int nValue)
{
	if (m_nPointer >= m_nMaxStackSize)
		return FALSE; //OVER

	m_pBuffer[++m_nPointer - 1] = nValue;
	return TRUE;
}

int CStack::Pop(void)
{
	if (m_nPointer < 1)
		return -1;

	return m_pBuffer[--m_nPointer];
}

BOOL CStack::IsStack()
{
	if (m_nPointer < 1)
		return FALSE;

	return TRUE;
}


void CStack::Destroy()
{
	if (m_pBuffer)
	{
		delete[] m_pBuffer;
		Clean();
	}
}

void CStack::Clean()
{
	m_pBuffer = NULL;
	m_nDataSize = 0;
	m_nPointer = 0;
	m_nMaxStackSize = 0;
}






//////////////////////////////////////////////////////////////////
/////////////////////////////  CLinkedList  //////////////////////
//////////////////////////////////////////////////////////////////
CLinkedList::CLinkedList()
{
	Clean();
}

CLinkedList::~CLinkedList()
{
}

const CLinkedList& CLinkedList::operator+=(CLinkedList &cList)
{
	STATE	state;
	LPVOID	pData;

	state = cList.GetFirstItem();

	while (pData = cList.GetNextItem(state))
	{
		if (!AddList(pData))
		{
			_ASSERTE(0 && "CLinkedList::operator+= is failed.");
			break;
		}
	}

	return *this;
}

BOOL CLinkedList::Initialize(int nSize, DWORD dwDataType)
{
	Destroy();

	m_pHead = new _LList_;
	_ASSERTE(m_pHead);
	if (m_pHead == NULL)
	{
		return FALSE;
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CLinkedList::Initialize\t%d\t%d", nSize, sizeof(_LList_));
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	m_dwDataType = dwDataType;
	m_nListSize = nSize;
	m_bAutoDelete = FALSE;
	m_pHead->data = NULL;
	m_pHead->next = NULL;
	m_pHead->prev = NULL;
	m_pTail = m_pHead;
	Home();
	return TRUE;
}

void CLinkedList::Clear()
{
	_LList_	*list, *next;

	if (m_pHead == NULL)
		return;
	if (m_pHead->next == NULL)
		return;

	for (list = m_pHead->next; list; list = next)
	{
		// 20120611 �߰�(�̼���:list NULL üũ)
		if (list)
		{
			next = list->next;
		}
		else
		{
			return;
		}

		//if(list->data && m_bAutoDelete)
		//{
		//	delete (list->data);
		//	list->data = NULL;
		//}
		if (list)
		{
			if (list->data && m_bAutoDelete)
			{
				delete (list->data);
				list->data = NULL;
			}

			delete (list);
			list = NULL;
		}
	}
}

void CLinkedList::Destroy()
{
	Clear();
	if (m_pHead)
	{
		delete (m_pHead);
		m_pHead = NULL;
	}
	DestroyIndex();
	Clean();
}

void CLinkedList::Home()
{
	m_statePos = GetFirstItem();
}

void * CLinkedList::Next()
{
	return GetNextItem(m_statePos);
}

void CLinkedList::Delete(BOOL bNextAfterDeleted)
{
	DeleteItem(m_statePos, bNextAfterDeleted);
}


int CLinkedList::GetMaxCount()
{
	return m_nListSize;
}

void CLinkedList::Clean()
{
	m_bAutoDelete = 0;
	m_pHead = NULL;
	m_pTail = NULL;
	m_nListSize = 0;
	m_nCount = 0;
	m_pIndexHead = NULL;
	m_dwDataType = 0;
	m_pLocked = NULL;
	m_statePos = 0;
	// 20120611 �߰�(�̼���:��� ���� �ʱ�ȭ)
	m_nIndexCount = 0;
}

_LList_ * CLinkedList::GetHead()
{
	return	m_pHead;
}

void * CLinkedList::GetAt(int nIndex)
{
	STATE	state;

	state = GetState(nIndex);

	if (!state)
		return NULL;

	return ((_LList_ *)state)->data;
}

BOOL CLinkedList::SetAt(int nIndex, void *data)
{
	_LList_	*list;
	int		count = 0;

	if (m_pHead == NULL)
		return FALSE;

	if (m_pHead->next == NULL)
		return FALSE;

	if (m_pIndexHead)
	{
		if (nIndex >= m_nIndexCount)
			return FALSE;

		((_LList_ *)m_pIndexHead[nIndex])->data = data;
		return TRUE;
	}

	for (list = m_pHead->next; list && count < nIndex; list = list->next)
	{
		count++;
	}

	// 20060607 �߰�(�̼���:C6011 NULL ������ ������)
	if (list)
	{
		list->data = data;
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

void* CLinkedList::FindList(LPCTSTR strFindKey, int nCount)
{
	_LList_	*list;
	int		len;

	if (m_pHead == NULL)
		return FALSE;

	if (m_pHead->next == NULL)
		return FALSE;

	len = (int)strlen(strFindKey);

	for (list = m_pHead->next; list; list = list->next)
	{
		if (!memcmp((char *)list->data + nCount, strFindKey, len))
			return list->data;
	}
	return NULL;
}

int CLinkedList::GetCurrentCount()
{
	return	m_nCount;
}

BOOL CLinkedList::Sort(int nStartPt, BOOL bAscending, int nSelect)
{
	void *v, *temp;
	int	i, j;
	int left, right;

	CreateIndex();
	m_clsStack.Initialize(max(100, m_nCount >> 2));

	left = 0;
	right = m_nCount - 1;
	if (!m_clsStack.Push(right))
		goto END;

	if (!m_clsStack.Push(left))
		goto END;

	while (m_clsStack.IsStack())
	{
		left = m_clsStack.Pop();
		right = m_clsStack.Pop();

		if (right - left + 1 > 1)
		{

			switch (bAscending)
			{
			case TRUE:
				if (intCmp(GetAt(left), GetAt((right + left) >> 1), nStartPt, nSelect) > 0)
				{
					v = GetAt(left);
					SetAt(left, GetAt((right + left) >> 1));
					SetAt((right + left) >> 1, v);
				}
				if (intCmp(GetAt(left), GetAt(right), nStartPt, nSelect) > 0)
				{
					v = GetAt(left);
					SetAt(left, GetAt(right));
					SetAt(right, v);
				}
				if (intCmp(GetAt((right + left) >> 1), GetAt(right), nStartPt, nSelect) > 0)
				{
					v = GetAt((right + left) >> 1);
					SetAt((right + left) >> 1, GetAt(right));
					SetAt(right, v);
				}
				break;

			case FALSE:
				if (intCmp(GetAt(left), GetAt((right + left) >> 1), nStartPt, nSelect) < 0)
				{
					v = GetAt(left);
					SetAt(left, GetAt((right + left) >> 1));
					SetAt((right + left) >> 1, v);
				}
				if (intCmp(GetAt(left), GetAt(right), nStartPt, nSelect) < 0)
				{
					v = GetAt(left);
					SetAt(left, GetAt(right));
					SetAt(right, v);
				}
				if (intCmp(GetAt((right + left) >> 1), GetAt(right), nStartPt, nSelect) < 0)
				{
					v = GetAt((right + left) >> 1);
					SetAt((right + left) >> 1, GetAt(right));
					SetAt(right, v);
				}

				break;
			}

			v = GetAt((right + left) >> 1);
			SetAt((right + left) >> 1, GetAt(right - 1));
			SetAt(right - 1, v);

			i = left;
			j = right - 1;

#pragma warning(push, 4)
#pragma warning(disable: 4127)
			while (TRUE)
			{
				switch (bAscending)
				{
				case TRUE:
					while (i + 1 < right)
					{
						if (intCmp(GetAt(++i), v, nStartPt, nSelect) < 0)
							continue;
						else
							break;
					}
					while (j > 0)
					{
						if (intCmp(GetAt(--j), v, nStartPt, nSelect) > 0)
							continue;
						else
							break;
					}
					break;
				default:
					while (i + 1 < right)
					{
						if (intCmp(GetAt(++i), v, nStartPt, nSelect) > 0)
							continue;
						else
							break;
					}
					while (j > 0)
					{
						if (intCmp(GetAt(--j), v, nStartPt, nSelect) < 0)
							continue;
						else
							break;
					}
					break;
				}
				if (i >= j) break;

				temp = GetAt(i);
				SetAt(i, GetAt(j));
				SetAt(j, temp);
			}
#pragma warning(pop)

			temp = GetAt(i);
			SetAt(i, GetAt(right - 1));
			SetAt(right - 1, temp);

			if (!m_clsStack.Push(right))
				goto END;
			if (!m_clsStack.Push(i + 1))
				goto END;
			if (!m_clsStack.Push(i - 1))
				goto END;
			if (!m_clsStack.Push(left))
				goto END;
		}
	}
END:
	m_clsStack.Destroy();
	DestroyIndex();
	return TRUE;
}


int CLinkedList::intCmp(void *pFirst, void *pSecond, int nStart, int nSelect)
{
	int	num;
	int	nFirstLen, nSecondLen;
	char	*pFirstData, *pSecondData;

	pFirstData = (char *)pFirst + nStart;
	pSecondData = (char *)pSecond + nStart;

	switch (nSelect)
	{
	case SORT_INT:
		return((*(int *)pFirstData - *(int *)pSecondData));
	case SORT_SHORT:
		return((*(short *)pFirstData - *(short *)pSecondData));
	case SORT_CHAR:
		return((*pFirstData - *pSecondData));
	case SORT_STRING:
	case SORT_STRING_NOLEN:	//���� ����
		nFirstLen = (int)strlen(pFirstData);
		nSecondLen = (int)strlen(pSecondData);

		if (nSelect == SORT_STRING)
		{
			if (nFirstLen > nSecondLen)
				return TRUE;
			else if (nFirstLen < nSecondLen)
				return -1;
		}

		for (num = 0; (num < nFirstLen) && pFirstData[num]; num++)
		{
			if (pFirstData[num] > pSecondData[num])
				return TRUE;
			else if (pFirstData[num] < pSecondData[num])
				return -1;
		}
		return FALSE;
	}
	return 0;
}

void CLinkedList::CreateIndex()
{
	int num = 0;
	_LList_	*list;

	DestroyIndex();

	if (m_pHead == NULL)
		return;

	if (m_pHead->next == NULL)
		return;

#ifdef _WIN64
	m_pIndexHead = new __int64[m_nCount];
#else
	m_pIndexHead = new DWORD[m_nCount];
#endif // _WIN64
	_ASSERTE(m_pIndexHead);
	if (m_pIndexHead == NULL)
	{
		return;
	}

	for (list = m_pHead->next; list; list = list->next)
	{
#ifdef _WIN64
		m_pIndexHead[num++] = (__int64)list;
#else
		m_pIndexHead[num++] = (DWORD)list;
#endif // _WIN64
	}
	m_nIndexCount = num;

}

void CLinkedList::DestroyIndex()
{
	if (m_pIndexHead)
	{
		delete[] m_pIndexHead;
		m_pIndexHead = NULL;
		m_nIndexCount = 0;
	}
}


BOOL CLinkedList::DeleteAt(int nIndex)
{
	STATE	state;

	state = GetState(nIndex);

	if (!state)
		return FALSE;

	return DeleteItem(state);
}

BOOL CLinkedList::DeleteAt(void *data)
{
	STATE	state;
	LPVOID	pData;

	state = GetFirstItem();

	while (pData = GetNextItem(state))
	{
		if (pData == data)
		{
			DeleteItem(state);
			return TRUE;
		}
	}
	return FALSE;
}

void * CLinkedList::FindList(void *Key, int nSize, int nCount)
{
	_LList_	*list;

	if (m_pHead == NULL)
		return FALSE;

	if (m_pHead->next == NULL)
		return FALSE;

	for (list = m_pHead->next; list; list = list->next)
	{
		if (!memcmp((char *)list->data + nCount, Key, nSize))
			return list->data;
	}
	return NULL;
}

BOOL CLinkedList::AddList(LPVOID data)	//�� ������ ����Ʈ�� ã�Ƽ� �߰�
{
	return AddListToTail(data);
}

BOOL CLinkedList::AddListToTail(void *data)		//�̰��� ����Ҷ� ���� �߰��ɶ���
{												//������ �ѹ��̶� ����� �ȵ�
	_LList_	 *temp = NULL;

	if (!IsInitialize())
		return FALSE;

	if (IsFull())
		return FALSE;	//FULL

	temp = new _LList_;

	if (temp == NULL)
	{
		return FALSE;
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CLinkedList::AddListToTail\t%d", sizeof(_LList_));
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	temp->data = data;
	temp->next = NULL;
	temp->prev = m_pTail;

	m_pTail->next = temp;
	m_pTail = temp;

	m_nCount++;
	return TRUE;
}

STATE CLinkedList::GetState(int nIndex)
{
	_LList_	*list;
	int		count = 0;

	if (!IsInitialize())
		return 0;

	if (nIndex >= GetCurrentCount() || nIndex < 0)
		return 0;

	if (m_pIndexHead)
	{
		if (nIndex >= m_nIndexCount)
			return NULL;

		return (STATE)m_pIndexHead[nIndex];
	}

	for (list = m_pHead->next; list && count < nIndex; list = list->next)
	{
		count++;
	}

	return (STATE)list;
}

DWORD CLinkedList::GetDataSize()
{
	return m_dwDataType;
}

STATE CLinkedList::GetFirstItem()
{
	if (!IsInitialize())
		return 0;

	if (GetCurrentCount() <= 0)
		return 0;

	return (STATE)m_pHead;
}

void* CLinkedList::GetNextItem(STATE &state)
{
	_LList_	*list;

	if (!IsInitialize())
		return NULL;

	if (GetCurrentCount() <= 0)
		return NULL;

	if (!state)
		return NULL;

	list = (_LList_ *)state;
	state = (STATE)list->next;

	if (state)
	{
		return ((_LList_ *)state)->data;
	}

	return NULL;
}

void* CLinkedList::GetCurItem(STATE state)
{
	if (!IsInitialize())
		return NULL;

	if (GetCurrentCount() <= 0)
		return NULL;

	if (!state)
		return NULL;

	return ((_LList_ *)state)->data;
}

BOOL CLinkedList::InsertItem(STATE state, LPVOID pData, int nInsertMode)
{
	_LList_	*list, *prev, *temp, *next;

	if (!IsInitialize())
		return FALSE;

	if (IsFull())
		return FALSE;	//FULL

	if (!state)
		return FALSE;

	list = (_LList_ *)state;

	// 20120607 ����(�̼���:Cppcheck warning ����)
	// A boolean comparison with the string literal "Create thread error." is always true.
	//_ASSERTE(_CrtCheckMemory() && "InsertItem, state value wrong.");
	_ASSERTE(_CrtCheckMemory());

	temp = new _LList_;

	if (temp == NULL)
		return FALSE;

	switch (nInsertMode)
	{
	case INSERT_BEFORE:
		prev = list->prev;
		if (!prev)
		{
			delete temp;
			return FALSE;
		}

		prev->next = temp;

		temp->prev = prev;
		temp->next = list;
		temp->data = pData;

		list->prev = temp;
		break;

	case INSERT_AFTER:
		temp->data = pData;
		temp->prev = list;

		if (list == m_pTail)
		{
			list->next = temp;
			m_pTail = temp;
			temp->next = NULL;
		}
		else
		{
			next = list->next;
			next->prev = temp;
			temp->prev = list;
			temp->next = next;
			list->next = temp;
		}
		break;
	}
	m_nCount++;
	return TRUE;
}

BOOL CLinkedList::DeleteItem(STATE &state, BOOL bNextAfterDeleted)
{
	_LList_	*list, *prev, *next;

	if (!IsInitialize())
		return FALSE;

	if (GetCurrentCount() <= 0)
		return FALSE;

	if (!state)
		return FALSE;

	list = (_LList_ *)state;

	if (list == m_pHead)
		return FALSE;

	// 20120611 �߰�(�̼���:list NULL üũ)
	if (list == NULL)
	{
		return FALSE;
	}

	prev = list->prev;
	next = list->next;

	if (prev)
	{
		if (list == m_pTail)
		{
			m_pTail = prev;
		}
		prev->next = list->next;
	}
	if (next)
		next->prev = prev;

	// 20120607 ����(�̼���:Cppcheck warning ����)
	// A boolean comparison with the string literal "Create thread error." is always true.
	//_ASSERTE(_CrtCheckMemory() && "DeleteItem Error, state value wrong."); // <djelee> : 2011.04.08 : Memory Leak Check
	_ASSERTE(_CrtCheckMemory()); // <djelee> : 2011.04.08 : Memory Leak Check

	if (list->data &&m_bAutoDelete)
	{
		delete list->data;
		list->data = NULL;
	}
	if (list)
	{
		delete list;
	}

	list = NULL;
	m_nCount--;

	if (bNextAfterDeleted)
		state = (STATE)next;
	else
		state = (STATE)prev;
	return TRUE;
}

#ifdef _WIN64
void* CLinkedList::FindList(__int64 dwData)
#else
void* CLinkedList::FindList(DWORD dwData)
#endif // _WIN64
{
	STATE	state;
#ifdef _WIN64
	__int64 dwFind;
#else
	DWORD	dwFind;
#endif // _WIN64

	state = GetFirstItem();

	if (!state)
		return NULL;

#ifdef _WIN64
	while (dwFind = (__int64)GetNextItem(state))
#else
	while (dwFind = (DWORD)GetNextItem(state))
#endif // _WIN64
	{
		if (dwFind == dwData)
			return (LPVOID)dwFind;
	}
	return NULL;
}

BOOL CLinkedList::DeleteList(DWORD dwData)
{
	STATE	state;
	DWORD	dwFind;

	state = GetFirstItem();

	if (!state)
		return FALSE;

	while (dwFind = (DWORD)GetNextItem(state))
	{
		if (dwFind == dwData)
		{
			return DeleteItem(state);
		}
	}
	return FALSE;
}

LPVOID CLinkedList::Lock(DWORD dwDataType, LPDWORD pResult)
{
	if (!dwDataType || m_pLocked)
		return NULL;

	int		nWrite;
	int		nSize;
	STATE	state;
	LPVOID	pTemp;

	nSize = dwDataType * GetCurrentCount();

	m_pLocked = new char[nSize];

	if (!m_pLocked)
		return NULL;

	if (pResult)
		*pResult = nSize;

	memset(m_pLocked, 0, nSize);

	state = GetFirstItem();
	nWrite = 0;
	while (pTemp = GetNextItem(state))
	{
		memcpy((char *)m_pLocked + nWrite, pTemp, dwDataType);
		nWrite += dwDataType;
	}

	// 20120607 ����(�̼���:Cppcheck warning ����)
	// A boolean comparison with the string literal "Create thread error." is always true.
	//_ASSERTE(_CrtCheckMemory() && "Locking: Break memory!");
	_ASSERTE(_CrtCheckMemory());
	return m_pLocked;
}

BOOL CLinkedList::Unlock()
{
	if (!m_pLocked)
		return FALSE;

	delete[] m_pLocked;
	m_pLocked = NULL;

	return TRUE;
}

BOOL CLinkedList::IsInitialize()
{
	if (m_pHead == NULL)
		return FALSE;

	return TRUE;
}

BOOL CLinkedList::IsFull()
{
	if (m_nCount >= m_nListSize && m_nListSize)
		return TRUE;	//FULL

	return FALSE;
}











////////////////////////////////////////////////////////////////////
////////////////////////////// CSimpleDataTable ////////////////////
////////////////////////////////////////////////////////////////////
/************************************************************************/
/* Creator : Kang Byung Wook                                            */
/* Creation Time: 2004.10.1		                                        */
/* Update Time: .                                                       */
/* Module Name: CSimpleDataTable										*/
/* Function: Load Table and Create Table								*/
/* Description: �ܼ��� ������������ ���̺��� �����ϰ� �����Ҷ�			*/
/*              ����մϴ�.												*/
/************************************************************************/
CSimpleDataTable::CSimpleDataTable()
{
	m_wHeaderVersion = 0;
}

CSimpleDataTable::~CSimpleDataTable()
{

}

BOOL CSimpleDataTable::Initialize(WORD wHeaderVersion, WORD wRecordSize)
{

	m_wHeaderVersion = wHeaderVersion;
	return m_cList.Initialize(0, wRecordSize);
}

BOOL CSimpleDataTable::InsertBack(LPVOID pData)
{
	return m_cList.AddList(pData);
}

BOOL CSimpleDataTable::Save(LPCSTR strFilename)
{
	HANDLE	hFile;
	DATATABLE_HEADER	header;
	DWORD	dwResult, dwWrite;
	LPVOID	pData;

	hFile = CreateFile(strFilename, GENERIC_WRITE, 0, NULL,
		OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
		return FALSE;

	header.dwRecordCount = m_cList.GetCurrentCount();
	header.wHeader = MAKEWORD('B', 'T');
	header.wHeaderSize = sizeof(DATATABLE_HEADER);
	header.wRecordSize = (WORD)m_cList.GetDataSize();
	header.wVersion = m_wHeaderVersion;
	header.tmCreation = (DWORD)time(NULL);

	if (!WriteFile(hFile, (LPVOID)&header, header.wHeaderSize, &dwResult, NULL))
	{
		CloseHandle(hFile);
		return FALSE;
	}

	if (header.wHeaderSize != dwResult)
	{
		CloseHandle(hFile);
		return FALSE;
	}

	pData = m_cList.Lock(header.wRecordSize, &dwResult);
	if (!pData)
	{
		CloseHandle(hFile);
		return FALSE;
	}

	dwWrite = dwResult;

	if (!WriteFile(hFile, pData, dwWrite, &dwResult, NULL))
	{
		m_cList.Unlock();
		CloseHandle(hFile);
		return FALSE;
	}

	m_cList.Unlock();
	CloseHandle(hFile);
	return TRUE;
}

BOOL CSimpleDataTable::Open(LPCSTR strFilename)
{
	HANDLE	hFile;

	hFile = CreateFile(strFilename, GENERIC_READ, 0, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (!Open(hFile))
	{
		CloseHandle(hFile);
		return FALSE;
	}

	CloseHandle(hFile);
	return TRUE;
}

BOOL CSimpleDataTable::Open(HANDLE hFile)
{
	DATATABLE_HEADER	header;
	DWORD	dwResult;
	LPVOID	pData;
	DWORD	num;

	Destroy();

	if (!ReadFile(hFile, (LPVOID)&header, sizeof(DATATABLE_HEADER), &dwResult, NULL))
	{
		return FALSE;
	}

	if (header.wHeader != MAKEWORD('B', 'T'))
	{
		return FALSE;
	}

	m_wHeaderVersion = header.wHeader;

	if (!Initialize(header.wVersion, header.wRecordSize))
	{
		return FALSE;
	}

	if (!OnLoad(header))
	{
		return FALSE;
	}

	for (num = 0; num < header.dwRecordCount; num++)
	{
		//pData = (LPSTR)malloc(header.wRecordSize);
		pData = new CHAR[header.wRecordSize];

		// 20060608 �߰�(�̼���:C6387 �ּ��� ������ �Լ� �Ű� ������ ����ġ ���� ���� ���޵Ǵ� ���)
		if (pData)
		{
			if (!ReadFile(hFile, pData, header.wRecordSize, &dwResult, NULL))
			{
				delete[]pData;
				//free(pData);
				break;
			}

			if (header.wRecordSize != dwResult)
			{
				delete[]pData;
				//free(pData);
				break;
			}

			if (!InsertBack(pData))
			{
				delete[]pData;
				//free(pData);
				break;
			}

			OnRead(pData);
		}
	}

	return TRUE;
}


STATE CSimpleDataTable::GetFirstItem()
{
	return m_cList.GetFirstItem();
}

LPVOID CSimpleDataTable::GetNextItem(STATE &state)
{
	return m_cList.GetNextItem(state);
}

void CSimpleDataTable::Destroy()
{
	STATE	state;
	LPSTR	pData;

	state = m_cList.GetFirstItem();
	while (pData = (LPSTR)m_cList.GetNextItem(state))
	{
		delete pData;
		//free(pData);
	}
	m_cList.Destroy();
}




//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
CNewCombineList::CNewCombineList(void)
{
}

CNewCombineList::~CNewCombineList(void)
{
}

BOOL CNewCombineList::Open(const char* _pNewCombineList)
{
	if (!m_cNewCombine.Open(_pNewCombineList))
	{
		return FALSE;
	}

	STATE	state;
	LPVOID	pData;
	SNewCombineList* pNewCombine;

	state = m_cNewCombine.GetFirstItem();

	while (pData = m_cNewCombine.GetNextItem(state))
	{
		pNewCombine = (SNewCombineList *)pData;
		//		BubbleSort(pNewCombine->nMat, MAX_MATERAL_NUM, TRUE);
		m_mapNewCombine.insert(hashTable::value_type(pNewCombine->nSuccessItem, (LPVOID)pNewCombine));
	}

	return TRUE;
}

void CNewCombineList::OnRead(LPCVOID const pData)
{
	return;
}

SNewCombineList* CNewCombineList::FindDuplication(int _nItemID, int _nInherentMat)
{
	STATE state = m_cNewCombine.GetFirstItem();
	SNewCombineList* pNewCombineList;

	while (pNewCombineList = (SNewCombineList*)m_cNewCombine.GetNextItem(state))
	{
		if (pNewCombineList->nSuccessItem != _nItemID)
		{
			continue;
		}

		if (pNewCombineList->nInherentMat != _nInherentMat)
		{
			continue;
		}
		return pNewCombineList;
	}
	return NULL;
}




///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
CPolymorph::CPolymorph()
{

}

CPolymorph::~CPolymorph()
{

}

BOOL CPolymorph::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CPolymorph::OnRead(LPCVOID const pData)
{
	POLYMORPH_BASE	*pPolymorph;

	pPolymorph = (POLYMORPH_BASE *)pData;

	m_table.insert(PolyVal(pPolymorph->wPCode, pPolymorph));
	return;
}

POLYMORPH_BASE* CPolymorph::FindPolymorph(WORD wPCode)
{
	PROFILER_SCOPE_TIMER(CPolymorph_FindPolymorph);

	PolyItor	itor;
	itor = m_table.find(wPCode);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}






//////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
CEffect::CEffect()
{

}

CEffect::~CEffect()
{

}

BOOL CEffect::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

template <class T> void BubbleSort(T a[], int b, BOOL bDescending = FALSE, int step = 1)
{
	int	i, j;
	T *pTemp;

	b /= step;
	pTemp = new T[step];
	ZeroMemory(pTemp, sizeof(T) * step);

	if (bDescending)
	{
		for (i = 0; i < b - 1; i++)
		{
			for (j = i + 1; j < b; j++)
			{
				if (a[i*step] < a[j*step])
				{
					memcpy(pTemp, &a[i*step], sizeof(T) * step);
					//temp = a[i*step];
					memcpy(&a[i*step], &a[j*step], sizeof(T) * step);
					memcpy(&a[j*step], pTemp, sizeof(T) * step);

					//a[i*step] = a[j*step];
					//a[j*step] = temp;
				}
			}
		}
	}
	else
	{
		for (i = 0; i < b - 1; i++)
		{
			for (j = i + 1; j < b; j++)
			{
				if (a[i*step] > a[j*step])
				{
					memcpy(pTemp, &a[i*step], sizeof(T) * step);
					memcpy(&a[i*step], &a[j*step], sizeof(T) * step);
					memcpy(&a[j*step], pTemp, sizeof(T) * step);

					/*temp = a[i];
					a[i] = a[j];
					a[j] = temp;*/
				}
			}
		}
	}

	// 20060808 ����(�̼���:C6283 ���� ����, delete [] �� �����ؾ���)
	delete[] pTemp;
}

void CEffect::OnRead(LPCVOID const pData)
{
	EFFECT_TABLE_BASE	*pRecord;

	pRecord = (EFFECT_TABLE_BASE*)pData;

	BubbleSort(pRecord->wParameta, 10, TRUE, 2);
	m_table.insert(MapVal(pRecord->wEffectIndex, pRecord));
	return;
}

EFFECT_TABLE_BASE* CEffect::Find(WORD wPCode)
{
	MapItor	itor;

	itor = m_table.find(wPCode);
	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}




///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
CTeleport::CTeleport()
{

}

CTeleport::~CTeleport()
{

}

BOOL CTeleport::OnLoad(CONST DATATABLE_HEADER &header)
{
	UNREFERENCED_PARAMETER(header);
	return 1;
}

void CTeleport::OnRead(LPCVOID const pData)
{
	TELEPORT_DATA *pRecord;

	pRecord = (TELEPORT_DATA*)pData;

	m_table.insert(MapTelePortVal((WORD)pRecord->nMoveIndex, pRecord));
	return;
}

TELEPORT_DATA* CTeleport::Find(int nMoveIndex)
{
	MapTelePortIter	itor;

	itor = m_table.find((WORD)nMoveIndex);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}

BOOL CTeleport::IsInTeleportList(int _nZone)
{
	MapTelePortIter	itor;

	itor = m_table.begin();
	while (m_table.end() != itor)
	{
		if (((TELEPORT_DATA*)(itor->second))->nZone == _nZone)
		{
			return TRUE;
		}
		itor++;
	}

	return FALSE;
}



////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
CRelicSetTable::CRelicSetTable()
{

}

CRelicSetTable::~CRelicSetTable()
{

}

BOOL CRelicSetTable::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CRelicSetTable::OnRead(LPCVOID const pData)
{
	RELICSET_DATA *pRecord;

	pRecord = (RELICSET_DATA*)pData;

	m_table.insert(MapRelicVal(pRecord->nItemID, pRecord));
	return;
}

RELICSET_DATA* CRelicSetTable::Find(int _nItemID)
{
	MapRelicIter	itor;

	itor = m_table.find(_nItemID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}

int CRelicSetTable::Count(int _nItemID)
{
	RELICSET_DATA	*pRecord;
	int nCount = 0;

	pRecord = Find(_nItemID);

	if (!pRecord)
	{
		return 0;
	}

	for (int num = 0; num < 6; num++)
	{
		if (pRecord->result[num].nResultID == 0)
		{
			break;
		}

		nCount++;
	}

	return nCount;
}



///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
FixedList::FixedList(void)
{
}

FixedList::~FixedList(void)
{
}

BOOL FixedList::Open(const char* _pFixedList)
{
	if (!m_cFixedList.Open(_pFixedList))
	{
		return FALSE;
	}

	STATE	state;
	//LPVOID	pData;
	SNewFixedList* pFixedList;
	state = m_cFixedList.GetFirstItem();

	//UJ 110714, hash table�� CAtlMap���� �ξ� �����Ƿ� ��ü�Ѵ�(�ӵ����) --start
	//	while(pData = m_cFixedList.GetNextItem(state))
	//	{
	//		pFixedList = (SNewFixedList *)pData;
	////		BubbleSort(pFixedList->n_cd, MAX_MATERAL_NUM, TRUE);
	//		m_mapFixedList.insert(hashTable::value_type(pFixedList->n_cd, (LPVOID)pFixedList));
	//	}
	DWORD fixedCount = 0;
	{
		while (m_cFixedList.GetNextItem(state))
			fixedCount++;
		m_atlMapFixedListItem.InitHashTable(fixedCount);
		m_atlMapFixedListIndex.InitHashTable(fixedCount);

		int index = 0;
		state = m_cFixedList.GetFirstItem();
		while (pFixedList = (SNewFixedList*)m_cFixedList.GetNextItem(state))
		{
			index++;
			__int64 key = ((__int64)pFixedList->grade << 32) | pFixedList->n_cd;
			if (m_atlMapFixedListItem.Lookup(key))
				continue;
			m_atlMapFixedListItem.SetAt(key, pFixedList);
			m_atlMapFixedListIndex.SetAt(key, index);
		}
		m_atlMapFixedListItem.AssertValid();
		m_atlMapFixedListIndex.AssertValid();
	}
	//UJ --end

	return TRUE;
}

void FixedList::OnRead(LPCVOID const pData)
{

}

SNewFixedList* FixedList::FindFixedList(int _nNPCCode, int _nNPCGrade, int* _pIndex)
{
	//UJ 110714, hash table�� CAtlMap���� �ξ� �����Ƿ� ��ü�Ѵ�(�ӵ����) --start
	ATL::CAtlMap<__int64, void*>::CPair *pAtlItem;
	ATL::CAtlMap<__int64, int>::CPair *pAtlIndex;
	__int64 key = ((__int64)_nNPCGrade << 32) | _nNPCCode;
	pAtlItem = m_atlMapFixedListItem.Lookup(key);
	if (pAtlItem)
	{
		pAtlIndex = m_atlMapFixedListIndex.Lookup(key);
		if (pAtlIndex)
			(*_pIndex) += pAtlIndex->m_value;
		return (SNewFixedList*)pAtlItem->m_value;
	}
	return NULL;
}






////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
CHonorRewardList::CHonorRewardList(void)
{
}

CHonorRewardList::~CHonorRewardList(void)
{
}


BOOL CHonorRewardList::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CHonorRewardList::OnRead(LPCVOID const pData)
{
	SHonorRewardList*pRecord;

	pRecord = (SHonorRewardList*)pData;

	m_table.insert(MapHonorRewardListVal(pRecord->nItemID, pRecord));

	return;
}

SHonorRewardList* CHonorRewardList::Find(int _nItemID)
{
	MapHonorRewardListIter	itor;

	itor = m_table.find(_nItemID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}



////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
CTitleList::CTitleList(void)
{
	m_nTitleCount = 0;

	m_pTitleList = NULL;
}


CTitleList::~CTitleList(void)
{
	delete[] m_pTitleList;
}


BOOL CTitleList::OnLoad(CONST DATATABLE_HEADER &header)
{
	if (header.dwRecordCount > 0)
	{
		m_nTitleCount = header.dwRecordCount;

		m_pTitleList = new STitleServer[m_nTitleCount];
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CTitleList::OnLoad\t%d", sizeof(STitleServer)*header.dwRecordCount);
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	return 1;
}


void CTitleList::OnRead(LPCVOID const pData)
{
	STitleServer *pRecord;
	static int nCount;

	pRecord = (STitleServer*)pData;

	if (pRecord->wTitleID == 0)
	{
		return;
	}

	m_table.insert(MapTitleListVal(pRecord->wTitleID, pRecord));

	m_pTitleList[nCount] = *pRecord;

	nCount++;

	return;
}


STitleServer* CTitleList::Find(WORD wTitleID)
{
	if (wTitleID == 0)
	{
		return NULL;
	}

	MapTitleListIter	itor;

	itor = m_table.find(wTitleID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}

STitleServer* CTitleList::Find(int nType, int nValue)
{
	for (int i = 0; i < m_nTitleCount; i++)
	{
		// 20110107 ����(�̼���:Īȣ �ý��� ���� TITLE_RECONNECTTIME Ÿ���� ��� �� ���� ���̱� ������ ������ ������ ũ�ų� ���� ���� ���� ����)
		if (m_pTitleList[i].nType == TITLE_RECONNECTTIME)
		{
			if (m_pTitleList[i].nType == nType && m_pTitleList[i].nTValue <= nValue)
			{
				return &m_pTitleList[i];
			}
		}
		else
		{
			if (m_pTitleList[i].nType == nType && m_pTitleList[i].nTValue == nValue)
			{
				return &m_pTitleList[i];
			}
		}
	}

	return NULL;
}





//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
CCollectionBookTable::CCollectionBookTable(void)
{
}

CCollectionBookTable::~CCollectionBookTable(void)
{
}


BOOL CCollectionBookTable::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CCollectionBookTable::OnRead(LPCVOID const pData)
{
	SCollectionBook *pRecord;

	pRecord = (SCollectionBook *)pData;

	m_table.insert(MapCollectionBookVal(pRecord->nBookID, pRecord));

	return;
}

SCollectionBook* CCollectionBookTable::Find(int _nBookID)
{
	MapCollectionBookIter	itor;

	itor = m_table.find(_nBookID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}



/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
CSocketPunch::CSocketPunch(void)
{
}


CSocketPunch::~CSocketPunch(void)
{
}


BOOL CSocketPunch::OnLoad(CONST DATATABLE_HEADER &header)
{
	UNREFERENCED_PARAMETER(header);
	return 1;
}


void CSocketPunch::OnRead(LPCVOID const pData)
{
	SSocketPunch *pRecord;

	pRecord = (SSocketPunch *)pData;

	m_mSocketPunch.insert(MapSocketPunchVal(pRecord->nItemID, pRecord));

	return;
}

SSocketPunch *CSocketPunch::Find(int nItemID)
{
	MapSocketPunchIter itor;

	itor = m_mSocketPunch.find(nItemID);

	if (m_mSocketPunch.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}




/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
CSocketItem::CSocketItem(void)
{
}


CSocketItem::~CSocketItem(void)
{
}


BOOL CSocketItem::OnLoad(CONST DATATABLE_HEADER &header)
{
	UNREFERENCED_PARAMETER(header);
	return 1;
}


void CSocketItem::OnRead(LPCVOID const pData)
{
	SSocketItem *pRecord;

	pRecord = (SSocketItem *)pData;

	m_mSocketItem.insert(MapSocketItemVal(pRecord->nItemID, pRecord));

	return;
}


SSocketItem *CSocketItem::Find(int nItemID)
{
	MapSocketItemIter itor;

	itor = m_mSocketItem.find(nItemID);

	if (m_mSocketItem.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}





/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
CSocketSet::CSocketSet(void)
{
	m_pSocketSet = NULL;
	m_nTotalSetCount = 0;
}


CSocketSet::~CSocketSet(void)
{
	delete[] m_pSocketSet;
}


BOOL CSocketSet::OnLoad(CONST DATATABLE_HEADER &header)
{
	if (header.dwRecordCount > 0)
	{
		m_nTotalSetCount = header.dwRecordCount;

		m_pSocketSet = new SSocketSet[m_nTotalSetCount];
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CSocketSet::OnLoad\t%d", sizeof(SSocketSet)*header.dwRecordCount);
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	return 1;
}


void CSocketSet::OnRead(LPCVOID const pData)
{
	SSocketSet *pRecord;
	static int nCount;

	pRecord = (SSocketSet*)pData;

	m_pSocketSet[nCount] = *pRecord;

	nCount++;

	return;
}

SSocketSet* CSocketSet::Find(int nInputCount, int *nSetItemID)
{
	for (int i = 0; i < m_nTotalSetCount; i++)
	{
		if (m_pSocketSet[i].nSetCount == nInputCount)
		{
			if (nSetItemID[0] == m_pSocketSet[i].nSetItemID[0] && nSetItemID[1] == m_pSocketSet[i].nSetItemID[1] && nSetItemID[2] == m_pSocketSet[i].nSetItemID[2] && nSetItemID[3] == m_pSocketSet[i].nSetItemID[3] && nSetItemID[4] == m_pSocketSet[i].nSetItemID[4])
			{
				return &m_pSocketSet[i];
			}
		}
	}

	return NULL;
}



///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
CPVPGrade::CPVPGrade(void)
{
	m_pPVPGrade = NULL;
	m_nTotalCount = 0;
}

CPVPGrade::~CPVPGrade(void)
{
	delete[] m_pPVPGrade;
}

BOOL CPVPGrade::OnLoad(CONST DATATABLE_HEADER &header)
{
	if (header.dwRecordCount > 0)
	{
		m_nTotalCount = header.dwRecordCount;

		m_pPVPGrade = new SPVPGrade[m_nTotalCount];
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CPVPGrade::OnLoad\t%d", sizeof(SPVPGrade)*header.dwRecordCount);
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	return TRUE;
}

void CPVPGrade::OnRead(LPCVOID const pData)
{
	SPVPGrade *pRecord;
	static int nCount;

	pRecord = (SPVPGrade*)pData;

	m_pPVPGrade[nCount] = *pRecord;

	nCount++;

	return;
}

int CPVPGrade::GetGrade(int _nPVPPoint)
{
	if (_nPVPPoint < 0)
	{
		return 0;
	}

	for (int i = 0; i < GetTotalRecordCount(); i++)
	{
		if (m_pPVPGrade[i].nMinPoint <= _nPVPPoint && m_pPVPGrade[i].nMaxPoint >= _nPVPPoint)
		{
			return m_pPVPGrade[i].nGrade;
		}
	}

	return 0;
}

int CPVPGrade::GetPVPMinPoint(int _nGrade)
{
	if (_nGrade < 1 || _nGrade > 10)
	{
		return 0;
	}

	for (int i = 0; i < GetTotalRecordCount(); i++)
	{
		if (m_pPVPGrade[i].nGrade == _nGrade)
		{
			return m_pPVPGrade[i].nMinPoint;
		}
	}

	return 0;
}



//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
CGuildLevel::CGuildLevel(void)
{
	m_pGuildLevel = NULL;
	m_pGuildSpecialBuff = NULL;

	m_nTotalCount = 0;
	m_nOptionCount = 0;
}

CGuildLevel::~CGuildLevel(void)
{
	delete[] m_pGuildLevel;
	delete[] m_pGuildSpecialBuff;
}

/**
@brief CSimpleDataTable.Open() �Լ��� �����ϸ� ó���ϴ� �����Լ�
@date 20120629
@author �̼���(bestdev@gameonstudio.co.kr)
@param &header (������ ���� ���� ���)
@return TRUE (�ε� ����)
*/
BOOL CGuildLevel::OnLoad(CONST DATATABLE_HEADER &header)
{
	if (header.dwRecordCount > 0)
	{
		m_nTotalCount = header.dwRecordCount;

		m_pGuildLevel = new SGuildLevel[m_nTotalCount];
		m_pGuildSpecialBuff = new SGuildSpecialBuff[m_nTotalCount*GUILD_SPECIAL_LVLBUFF_CNT];
	}

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CGuildLevel::OnLoad\t%d\t%d", sizeof(SGuildLevel)*header.dwRecordCount, sizeof(SGuildSpecialBuff)*header.dwRecordCount);
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	return TRUE;
}

/**
@brief OnLoad() �� ���̺� �� �����͵� �о���� �����Լ�
@date 20120629
@author �̼���(bestdev@gameonstudio.co.kr)
@param pData (������ ���ڵ�)
@return ����
*/
void CGuildLevel::OnRead(LPCVOID const pData)
{
	SGuildLevel *pRecord;
	static int nCount;

	pRecord = (SGuildLevel*)pData;

	m_pGuildLevel[nCount] = *pRecord;

	for (int i = 0; i < GUILD_SPECIAL_LVLBUFF_CNT; i++)
	{
		m_pGuildSpecialBuff[m_nOptionCount].sGSpecOptionIndex = m_nOptionCount;
		m_pGuildSpecialBuff[m_nOptionCount].sGSpecOptionID = pRecord->sGSpecOptionID[i];
		m_pGuildSpecialBuff[m_nOptionCount].nGSpecOptionValue = pRecord->nGSpecOptionValue[i];

		m_nOptionCount++;
	}

	nCount++;

	m_GLtable.insert(MapGuildLevelVal(pRecord->sGLevel, pRecord));

	return;
}

SGuildLevel* CGuildLevel::Findlvl(short _sGLevel)
{
	MapGuildLevelIter	itor;

	itor = m_GLtable.find(_sGLevel);

	if (m_GLtable.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}

int CGuildLevel::GetSpecialPoint(short _sGLevel)
{
	int result = 0;

	for (int i = 0; i <= _sGLevel - 1; i++)
	{
		result += m_pGuildLevel[i].btGSpecPoint;
	}

	return result;
}

BOOL CGuildLevel::CheckSpecialBuffByLevel(short _sGLevel, __int64* _nGSBuff)
{
	int j = _sGLevel * GUILD_SPECIAL_LVLBUFF_CNT;

	while (j <= (GUILD_LIMMIT_MAXLEVEL * GUILD_SPECIAL_LVLBUFF_CNT))
	{
		j++;

		if ((_nGSBuff[j / GUILD_ATTRIBUTE_NUM] >> (j - ((j / GUILD_ATTRIBUTE_NUM)*GUILD_ATTRIBUTE_NUM))) & 1)
		{
			return FALSE;
		}
	}

	return TRUE;
}

SGuildSpecialBuff* CGuildLevel::FindSbuff(short	_sOptIndex)
{

	for (int i = 0; i < m_nOptionCount; i++)
	{
		if (m_pGuildSpecialBuff[i].sGSpecOptionIndex == _sOptIndex)
		{
			return &m_pGuildSpecialBuff[i];
		}
	}

	return NULL;
}



/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
CNewItemShopList::CNewItemShopList(void)
{
}

CNewItemShopList::~CNewItemShopList(void)
{
}


BOOL CNewItemShopList::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CNewItemShopList::OnRead(LPCVOID const pData)
{
	SNewItemShopList *pRecord;

	pRecord = (SNewItemShopList*)pData;

	m_table.insert(MapNewItemShopListVal(pRecord->nItemID, pRecord));

	return;
}

SNewItemShopList* CNewItemShopList::Find(int _nItemID)
{
	MapNewItemShopListIter	itor;

	itor = m_table.find(_nItemID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}




//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
CNewGrowthTable::CNewGrowthTable(void)
{
}

CNewGrowthTable::~CNewGrowthTable(void)
{
}


BOOL CNewGrowthTable::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CNewGrowthTable::OnRead(LPCVOID const pData)
{
	SNewGrowth *pRecord;

	pRecord = (SNewGrowth*)pData;

	m_table.insert(MapNewGrowthVal(pRecord->nItemID, pRecord));

	return;
}

SNewGrowth* CNewGrowthTable::Find(int _nItemID)
{
	MapNewGrowthIter	itor;

	itor = m_table.find(_nItemID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}



/////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
CPetTable::CPetTable(void)
{
}

CPetTable::~CPetTable(void)
{
}


BOOL CPetTable::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}

void CPetTable::OnRead(LPCVOID const pData)
{
	SPetItem *pRecord;

	pRecord = (SPetItem*)pData;

	m_table.insert(MapPetVal(pRecord->nItemID, pRecord));

	return;
}

SPetItem* CPetTable::Find(int _nItemID)
{
	MapPetIter	itor;

	itor = m_table.find(_nItemID);

	if (m_table.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}



/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
CMultiScroll::CMultiScroll()
{
}

CMultiScroll::~CMultiScroll()
{
}

RECORD_MULTISCROLL* CMultiScroll::Find(WORD wIndex)
{
	TABLE::MapItor	itor;

	itor = m_table.find(wIndex);

	if (m_table.end() == itor)
	{
		return NULL;
	}
	return NULL;
}


BOOL CMultiScroll::OnLoad(CONST DATATABLE_HEADER &header)
{
	return 1;
}


void CMultiScroll::OnRead(LPCVOID const pData)
{
	RECORD_MULTISCROLL	*pRecord;

	pRecord = (RECORD_MULTISCROLL*)pData;

	BubbleSort(pRecord->wEffect, 5, TRUE);
	m_table.insert( TABLE::MapVal(pRecord->wIndex, pRecord) );
	return;
}



//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
CQueue3::CQueue3()
{
	Clean();
}

CQueue3::~CQueue3()
{
}

BOOL CQueue3::Push(LPCSTR pData, DWORD dwSize)
{
	//_ASSERTE(m_dwSize);
	if (m_dwSize == 0)
		return FALSE;

	if (GetEmptySize() < dwSize)
		return FALSE;

	if (((m_dwTail + dwSize + 1)) > m_dwSize)
	{
		DWORD	dwWrite;
		DWORD	dwSecond;
		dwWrite = m_dwSize - m_dwTail - 1;
		memcpy(&m_pData[m_dwTail], pData, dwWrite);

		dwSecond = (dwSize > dwWrite) ? dwSize - dwWrite : dwWrite - dwSize;
		memcpy(&m_pData[0], (LPVOID)&pData[dwWrite], dwSecond);
		m_dwTail += dwSize;
	}
	else
	{
		memcpy(&m_pData[m_dwTail], pData, dwSize);
		m_dwTail += dwSize;
	}
	m_dwTail = m_dwTail % (m_dwSize - 1);
	m_dwCurrentSize += dwSize;
	return TRUE;
}

int CQueue3::Pull(LPSTR pData, DWORD dwSize, BOOL bDelete)
{
	_ASSERTE(m_dwSize);
	if (m_dwSize == 0)
		return FALSE;

	if (GetCurrentSize() < dwSize)
		return FALSE;

	if ((m_dwHead + dwSize + 1) > m_dwSize)
	{
		if (pData)
		{
			DWORD	dwRead;
			DWORD	dwSecond;
			dwRead = m_dwSize - m_dwHead - 1;
			memcpy(pData, &m_pData[m_dwHead], dwRead);
			dwSecond = (dwSize > dwRead) ? dwSize - dwRead : dwRead - dwSize;

			memcpy(&pData[dwRead], &m_pData[0], dwSecond);

			if (!bDelete)
				return TRUE;
		}
		m_dwHead += dwSize;
	}
	else
	{
		if (pData)
		{
			memcpy(pData, &m_pData[m_dwHead], dwSize);

			if (!bDelete)
				return TRUE;
		}
		m_dwHead += dwSize;
	}

	m_dwHead = m_dwHead % (m_dwSize - 1);
	m_dwCurrentSize -= dwSize;
	return TRUE;
}

//dwSize��ŭ�� �����͸� �ڷ� �ٽ� ���Խ�Ų��.
void CQueue3::PullBack(DWORD dwSize)
{
	m_dwHead += dwSize;
	m_dwHead = m_dwHead % (m_dwSize - 1);
	m_dwTail += dwSize;
	m_dwTail = m_dwTail % (m_dwSize - 1);
}

void CQueue3::Clean()
{
	m_pData = NULL;
	m_dwHead = 0;
	m_dwTail = 0;
	m_dwSize = 0;
	m_dwCurrentSize = 0;
}

void CQueue3::Destroy()
{
	if (m_pData)
	{
		delete[] m_pData;
	}
	Clean();
}

BOOL CQueue3::Initialize(DWORD dwSize)		//���� �迭 ť
{
	Destroy();

	m_pData = new char[dwSize];

#ifdef _MEMALOC_FUNC_LOG
	char szTemp[256];
	sprintf(szTemp, "FC-CQueue3::Initialize\t%d", dwSize);
	g_older.WriteMemalocFuncLog(szTemp);
#endif // _MEMALOC_FUNC_LOG

	if (m_pData == NULL)
		return FALSE;

	m_dwSize = dwSize;
	memset(m_pData, 0, dwSize);
	return TRUE;
}


DWORD CQueue3::GetMaxSize()
{
	return m_dwSize;
}

DWORD CQueue3::GetCurrentSize()
{
	return m_dwCurrentSize;
}

DWORD CQueue3::GetEmptySize()
{
	return m_dwSize - m_dwCurrentSize - 1;
}

void CQueue3::ClearAll()
{
	m_dwHead = 0;
	m_dwTail = 0;
	m_dwCurrentSize = 0;
}

BOOL CQueue3::Copy(CQueue3 &dest)
{
	if (GetMaxSize() != dest.GetMaxSize())
		return FALSE;

	dest.ClearAll();

	dest.m_dwHead = m_dwHead;
	dest.m_dwTail = m_dwTail;
	dest.m_dwCurrentSize = m_dwCurrentSize;

	// 20120607 ����(�̼���:Cppcheck warning ����)
	// A boolean comparison with the string literal "Create thread error." is always true.
	//_ASSERTE((dest.m_pData && m_pData) && "CQueue3::Copy_ pData is Null");
	_ASSERTE(dest.m_pData && m_pData);
	memcpy(dest.m_pData, m_pData, m_dwCurrentSize);
	return TRUE;
}

int QuestVariable::CompareValue(char *QData, char *data)
{
	switch (CompareKind)
	{
	case COMPARE_BYTE:
		return (*(BYTE*)(QData + Offset) - *(BYTE*)data);
	case COMPARE_SHORT:
		return (*(short*)(QData + Offset) - *(short*)data);
	case COMPARE_INT:
		return (*(int*)(QData + Offset) - *(int*)data);
	case COMPARE_STRING_CRO:
		return strncmp(QData + Offset, data, Length);
	case COMPARE_FLOAT:
		float ft;
		ft = *(float*)(QData + Offset) - *(float*)data;
		return (ft > 0 ? 1 : (ft < 0 ? -1 : 0));
	case COMPARE_DOUBLE:
		double dt;
		dt = *(double*)(QData + Offset) - *(double*)data;
		return (dt > 0 ? 1 : (dt < 0 ? -1 : 0));
	default:
		return -1;
	}

}

int QuestVariable::GetValue(char *QData)
{
	int ret;
	switch (CompareKind)
	{
	case COMPARE_BYTE:
		ret = *(BYTE*)(QData + Offset);
		break;
	case COMPARE_SHORT:
		ret = *(short*)(QData + Offset);
		break;
	case COMPARE_INT:
		ret = *(int*)(QData + Offset);
		break;
	case COMPARE_STRING_CRO:
	case COMPARE_FLOAT:
	case COMPARE_DOUBLE:
	default:
		return -1;
		break;
	}
	return ret;
}

bool QuestVariable::SetValue(char *Dest, char *Src)
{
	memcpy(Dest + Offset, Src, Length);
	return true;
}

bool QuestVariable::AddValue(char *Dest, char *Src)
{
	switch (CompareKind)
	{
	case COMPARE_BYTE:
		*(BYTE*)(Dest + Offset) = (BYTE)(*(BYTE*)(Dest + Offset) + *(BYTE*)Src);
		return true;
	case COMPARE_SHORT:
		*(short*)(Dest + Offset) = (short)(*(short*)(Dest + Offset) + *(short*)Src);
		return true;
	case COMPARE_INT:
		*(int*)(Dest + Offset) += *(int*)Src;
		return true;
	case COMPARE_FLOAT:
		*(float*)(Dest + Offset) += *(float*)Src;
		return true;
	case COMPARE_DOUBLE:
		*(double*)(Dest + Offset) += *(double*)Src;
		return true;
	default:
		return false;
	}
}

bool QuestVariable::MultiplyValue(char *Dest, char *Src)
{
	switch (CompareKind)
	{
	case COMPARE_BYTE:
		*(BYTE*)(Dest + Offset) = (BYTE)(*(BYTE*)(Dest + Offset) * *(BYTE*)Src);
		return true;
	case COMPARE_SHORT:
		*(short*)(Dest + Offset) = (short)(*(short*)(Dest + Offset) * *(short*)Src);
		return true;
	case COMPARE_INT:
		*(int*)(Dest + Offset) *= *(int*)Src;
		return true;
	case COMPARE_FLOAT:
		*(float*)(Dest + Offset) *= *(float*)Src;
		return true;
	case COMPARE_DOUBLE:
		*(double*)(Dest + Offset) *= *(double*)Src;
		return true;
	default:
		return false;
	}
}

bool QuestVariable::OrValue(char *Dest, char *Src)
{
	char *p = Dest + Offset;

	for (int i = 0; i < Length; i++, p++, Src++)
		*p |= *Src;

	return true;
}

bool QuestVariable::AndValue(char *Dest, char *Src)
{
	char *p = Dest + Offset;

	for (int i = 0; i < Length; i++, p++, Src++)
		*p &= *Src;

	return true;
}

bool QuestVariable::XorValue(char *Dest, char *Src)
{
	char *p = Dest + Offset;

	for (int i = 0; i < Length; i++, p++, Src++)
		*p ^= *Src;

	return true;
}

bool QuestVariable::ReadData(HANDLE hFile)
{
	DWORD dwTemp;

	if (ReadFile(hFile, this, sizeof(QuestVariable), &dwTemp, NULL) == 0)
		return true;
	if (dwTemp != sizeof(QuestVariable))
		return false;

	return true;

}


bool Condition::ReadData(HANDLE hFile)
{
	DWORD dwTemp;

	if (ReadFile(hFile, this, sizeof(Condition), &dwTemp, NULL) == 0)
		return false;
	if (dwTemp != sizeof(Condition))
		return false;

	return true;
}

bool Condition::CompareIntWithValue(int value)
{
	switch (m_Operation)
	{
	case 0: // ����
		return (value < *(int*)m_Value);
	case 1: // �۰ų� ����
		return (value <= *(int*)m_Value);
	case 2: // ����
		return (value == *(int*)m_Value);
	case 3: // ũ�ų� ����
		return (value >= *(int*)m_Value);
	case 4: // ŭ
		return (value > *(int*)m_Value);
	default:
		return false;
	}

}

bool Condition::CompareOperation(int value)
{
	switch (m_Operation)
	{
	case 0: // ����
		return (value < 0);
	case 1: // �۰ų� ����
		return (value <= 0);
	case 2: // ����
		return (value == 0);
	case 3: // ũ�ų� ����
		return (value >= 0);
	case 4: // ŭ
		return (value > 0);
	default:
		return false;
	}

}

bool Condition::CompareBigIntWithValue(__int64 _nValue)
{
	switch (m_Operation)
	{
	case 0: // ����
		return (_nValue < *(__int64*)m_Value);
	case 1: // �۰ų� ����
		return (_nValue <= *(__int64*)m_Value);
	case 2: // ����
		return (_nValue == *(__int64*)m_Value);
	case 3: // ũ�ų� ����
		return (_nValue >= *(__int64*)m_Value);
	case 4: // ŭ
		return (_nValue > *(__int64*)m_Value);
	default:
		return false;
	}

}

void Condition::SetVariable(QuestVariable *qvar)
{
	if (m_VariableID)
		m_Variable = &qvar[m_VariableID];
}


bool Action::ReadData(HANDLE hFile)
{
	DWORD dwTemp;

	if (ReadFile(hFile, this, sizeof(Action), &dwTemp, NULL) == 0)
		return true;
	if (dwTemp != sizeof(Action))
		return false;

	return true;

}

void Action::SetVariable(QuestVariable *qvar)
{
	if (m_VariableID)
		m_Variable = &qvar[m_VariableID];
}


bool Answer::ReadData(HANDLE hFile)
{
	DWORD dwTemp;

	if (ReadFile(hFile, &m_Kind, sizeof(Answer), &dwTemp, NULL) == 0)
		return false;

	if (dwTemp != sizeof(Answer))
		return false;

	return true;
}

bool Quest::ReadData(HANDLE hFile)
{
	DWORD dwTemp;

	// 20060608 ����(�̼���:C6031 �Լ��� ��ȯ���� üũ���ϴ� ����)
	if (!ReadFile(hFile, &QuestID, sizeof(QuestID), &dwTemp, NULL))
	{
		return false;
	}

	if (!cond.ReadData(hFile))
		return false;

	if (!SAction[0].ReadData(hFile))
		return false;
	if (!SAction[1].ReadData(hFile))
		return false;
	if (!FAction[0].ReadData(hFile))
		return false;
	if (!FAction[1].ReadData(hFile))
		return false;

	if (!SAnswer.ReadData(hFile))
		return false;
	if (!FAnswer.ReadData(hFile))
		return false;

	return true;
}

void Quest::SetVariable(QuestVariable *qvar)
{
	cond.SetVariable(qvar);
	for (int i = 0; i < 2; i++)
	{
		SAction[i].SetVariable(qvar);
		FAction[i].SetVariable(qvar);
	}
}
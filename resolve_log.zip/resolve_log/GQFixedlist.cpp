#include "GQFixedlist.h"
using namespace std;


GQFixedlist::GQFixedlist()
{
}


GQFixedlist::~GQFixedlist()
{
}

void GQFixedlist::GQOpen() {
	
	printf("Begin Load fixed.dat\n");
	if (m_cFixed.Open("data\\fixed.dat")) {
		printf("End Load fixed.dat\n");
	}
	else {
		printf("Error Load fixed.dat\n");
	}
	return;
}

void GQFixedlist::GQWrite() {
	printf("Begin Write fixed.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/fixed.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("fixed.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	SNewFixedList	*pFixed = NULL;
	oFile << "n_cd " << "," 
		<< "grade " << "," << "bitemid1 " << "," 
		<< "dropprob1 " << "," << "bitemid2 " << "," << "dropprob2 " << "," 
		<< "bitemid3 " << "," << "dropprob3 " << "," << "bitemid4 " << "," 
		<< "dropprob4 " << "," << "bitemid5 " << "," << "dropprob5" << "\n";
	state = m_cFixed.m_cFixedList.GetFirstItem();
	while (pData = m_cFixed.m_cFixedList.GetNextItem(state)) {
		pFixed = (SNewFixedList *)pData;
		if (pFixed->n_cd <= -1)
			continue;
		if (pFixed == NULL) {
			continue;
		}
		oFile << pFixed->n_cd << ",";
		oFile << pFixed->grade << ",";
		oFile << pFixed->bitemid[0] << ",";
		oFile << pFixed->dropprob[0] << ",";
		oFile << pFixed->bitemid[1] << ",";
		oFile << pFixed->dropprob[1] << ",";
		oFile << pFixed->bitemid[2] << ",";
		oFile << pFixed->dropprob[2] << ",";
		oFile << pFixed->bitemid[3] << ",";
		oFile << pFixed->dropprob[3] << ",";
		oFile << pFixed->bitemid[4] << ",";
		oFile << pFixed->dropprob[4] << "\n";
	}

	oFile.close();
	printf("End Write fixed.CSV\n");
}
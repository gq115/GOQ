#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQLottery
{
public:
	GQLottery();
	~GQLottery();


	CSimpleDataTable	m_tblLottery;
	CSimpleDataTable	m_tblLotteryRate;
	bool LoadLotteryData();
	void GQWrite();
};


#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQColor
{
public:
	GQColor();
	~GQColor();

	ATL::CAtlMap<int, void*>			m_atlMapClass;
	ATL::CAtlMap<unsigned short, void*>	m_atlMapOption;
	ATL::CAtlMap<unsigned short, void*>	m_atlMapSet;
	std::multimap<WORD, LPVOID> m_mapCombine;

	CSimpleDataTable	m_cCombine;
	CSimpleDataTable	m_cOption;
	CSimpleDataTable	m_cClass;
	CSimpleDataTable	m_cSet;

	bool LoadColorTables();
	void GQWrite();
};


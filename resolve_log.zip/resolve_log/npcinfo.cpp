#include "npcinfo.h"

npcinfo::npcinfo()
{
	m_bRelease = FALSE;
	memset((LPVOID)&m_info, 0, sizeof(m_info));
	memset((LPVOID)&m_proto, 0, sizeof(m_proto));
	m_npcindex = 0;
	memset((LPVOID)&m_startingPoint, 0, sizeof(Point));
	memset((LPVOID)&m_currentPoint, 0, sizeof(Point));
	memset((LPVOID)&m_destination, 0, sizeof(Point));
	memset((LPVOID)&m_mdestination, 0, sizeof(Point));
	m_lpThread = NULL;
	m_dwLastTime = 0;
	m_dwDelayTime = 0;
	m_dwAIStateTime = 0;
	m_dwActionTime = 0;
	memset((LPVOID)&m_csItem, 0, sizeof(m_csItem));
	memset(m_itemlist, 0, sizeof(m_itemlist));
	memset(m_ActionList, 0, sizeof(m_ActionList));
	m_pointcounter = 0;
	m_pointnum = 0;
	m_state = 0;
	m_aistate = 0;
	memset(m_grouplist, 0, sizeof(m_grouplist));
	m_groupnum = 0;
	m_groupleader = 0;
	memset(m_attackerlist, 0, sizeof(m_attackerlist));
	m_attackernum = 0;
	memset(m_targetlist, 0, sizeof(m_targetlist));
	m_targetnum = 0;
	memset(m_groupattackerlist, 0, sizeof(m_groupattackerlist));
	m_groupattackernum = 0;
	memset(m_grouptargetlist, 0, sizeof(m_grouptargetlist));
	m_grouptargetnum = 0;
	m_maintarget = 0;
	m_isnpcarounddead = 0;
	m_isinfirstrange = 0;
	m_isinsecondrange = 0;
	m_isnpcaroundmetarget = 0;
	m_istherepkaroundme = 0;
	m_ismaintargetdisappeared = 0;
	m_ismaintargetoutofrange = 0;
	m_isuserattackedme = 0;
	m_isaistatetimespend = 0;
	m_isfirstattackerdisappeared = 0;
	m_curlastuserattackme = 0;
	m_curfirstuserattackme = 0;
	m_near_userindex = 0;
	m_maintargetdistance = 0;
	m_grade = 0;
	m_grade_attrate = 0;
	m_grade_hp = 0;
	m_grade_def = 0;
	m_grade_defrate = 0;
	m_grade_attd_min = 0;
	m_grade_attd_max = 0;
	m_grade_exp = 0;
	m_grade_lvl = 0;
	m_grade_resi = 0;
	m_grade_critic_prob = 0;
	m_grade_critic = 0;
	m_roomindex = 0;
	memset((LPVOID)&m_option, 0, sizeof(m_option));
	m_killer = 0;
	m_moid = 0;
	m_hp_cur = 0;
	ZeroMemory(m_abStateCode, sizeof(m_abStateCode));
	memset(m_durationstarttime, 0, sizeof(m_durationstarttime));
	memset(m_duration, 0, sizeof(m_duration));
	memset(m_durationFlags, 0, sizeof(m_durationFlags));
	memset(m_durationsid, 0, sizeof(m_durationsid));
	memset(m_durationslvl, 0, sizeof(m_durationslvl));
	memset((LPVOID)&m_useraroundme, 0, sizeof(m_useraroundme));
	memset((LPVOID)&m_buseraroundme, 0, sizeof(m_buseraroundme));
	memset((LPVOID)&m_npcaroundme, 0, sizeof(m_npcaroundme));
	m_firstattacker = 0;
	memset(m_attacked, 0, sizeof(m_attacked));
	m_attackedlistindex = 0;
	m_iBeforeDecision = 0;
	//m_iCountBack = 0;
	m_iDonotMoveDirection = 0;
	memset((LPVOID)&m_protocolIn, 0, sizeof(m_protocolIn));
	memset((LPVOID)&m_protocolBaseIn, 0, sizeof(m_protocolBaseIn));
	memset(m_sbattribute, 0, sizeof(m_sbattribute));
	m_movespeed = 0;
	m_attackspeed = 0;
	m_level = 0;
	m_defense = 0;
	m_defenseRate = 0;
	m_attrate = 0;
	m_attd_max = 0;
	m_attd_min = 0;
	m_fire_resi = 0;
	m_water_resi = 0;
	m_light_resi = 0;
	m_poison_resi = 0;
	m_mag_resi = 0;
	m_critic = 0;
	m_critic_prob = 0;
	m_attacktime = 0;
	m_thornsdam = 0;
	memset((LPVOID)&m_dskill, 0, sizeof(m_dskill));
	m_movedist = 0;
	m_reaction_range2 = 0;
	m_body_size2 = 0;
	m_attack_range2 = 0;
	memset((LPVOID)&m_possible, 0, sizeof(m_possible));
	m_gradeProbSum = 0;
	m_protochanged = 0;
	m_unionCode = 0;
	memset((LPVOID)m_userlist, 0, sizeof(m_userlist));
	memset((LPVOID)m_npclist, 0, sizeof(m_npclist));
	m_usercount = 0;
	m_npccount = 0;
	m_skillCastingTime = 0;
	m_skillDelayTime = 0;
	m_bAutoRelease = 0;
	memset(m_nDeadIndex, 0, sizeof(m_nDeadIndex));
	memset((LPVOID)&m_ptDeadPlace, 0, sizeof(Point));
	m_nOwner = 0;
	m_bResurrection = 0;
	memset(m_stLearningSkill, 0, sizeof(m_stLearningSkill));
	memset((LPVOID)&m_stActSkill, 0, sizeof(m_stActSkill));
	m_nSummoner = 0;
	m_skillstarttime = 0;
	m_skilldelaytime = 0;
	m_dskillarea = 0;
	m_extracode = 0;
	m_bActive = 0;
	m_bDamaged = 0;
	m_askill_attrate = 0;
	m_askill_attdphy = 0;
	m_askill_sthp = 0;
	m_askill_stmp = 0;
	m_askill_attrange = 0;
	m_askill_breakprob = 0;
	m_sScriptRateHP = 0;
	m_sScriptRateDef = 0;
}

npcinfo::~npcinfo()
{
	if (!m_bRelease)
	{
		DeleteCriticalSection(&m_csItem);
	}
}

int	g_NpcIndexInZone[MAX_ZONE][MAX_NPCINZONE_NUM] = { 0, };
void npcinfo::SetBaseNPCInfo(BaseNPCInfo *bninfo, NPCProto *proto, int index, int nGrade)
{
	//npc proto table���� �ڽ��� ������ ������ basenpcinfo�� ������ �κ��� ����
	int	num;
	memcpy(&m_info, bninfo, sizeof(m_info));
	memcpy(&m_proto, proto, sizeof(m_proto));
	memset(m_stLearningSkill, 0, sizeof(m_stLearningSkill));

	for (num = 0; num < MAX_NPCINZONE_NUM; num++)
	{
		if (g_NpcIndexInZone[m_info.m_zone][num] != 0)
		{
			continue;
		}

		g_NpcIndexInZone[m_info.m_zone][num] = -index;
		break;
	}

	m_startingPoint = m_info.m_point;

	m_dwLastTime = GetTickCount();
	m_dwActionTime = m_dwLastTime;	//m_dwItemMadeTime = 

	m_dwDelayTime = 500;

	//m_area = 0;

	m_lpThread = NULL;

	if (!IsLoad())
	{
		m_hp_cur = 1;
		m_npcindex = -index;
		m_bActive = TRUE;
		//_RPT3(0, "CreateNpc - ID: %d, index: %d, time: %d\n", m_proto.m_cd, GetNpcIndex(), m_dwLastTime);
		// 20110721 ����(���ٿ�:InitData() ���� �߰�. nGrade)
		//InitData(nGrade);
	}
	makeprotocol(&m_protocolIn);
	makeProtocolBaseIn();

	m_bResurrection = FALSE;
	memset(m_nDeadIndex, EMPTY_INDEX, sizeof(m_nDeadIndex));
	//memset(m_ResList, 0, sizeof(m_ResList));

	for (num = 0; num < MAX_NPC_SKILL; num++)
	{
		m_stLearningSkill[num].nSkID = m_proto.m_sid[num];
		m_stLearningSkill[num].nSkLevel = m_proto.m_slvl[num];
	}

};

void npcinfo::makeprotocol(pIn* pi) {		//���� �ٲ��� ���� �������� ���� �����д�.
	pi->header = fin;
	pi->characterclass = (short)(m_info.m_cd);
	pi->anItems[0] = m_proto.m_hostile;
	pi->x = (short)m_currentPoint.x;
	pi->y = (short)m_currentPoint.y;
	pi->z = (short)m_currentPoint.z;
	pi->userindex = m_npcindex;
	pi->direction = (BYTE)(m_info.m_direction / 2);

	ZeroMemory(pi->abActoinCode, sizeof(pi->abActoinCode));

	//memcpy(pi->charactername, m_proto.m_namek,CNAME_LENGTH);
	pi->attackspeed = (char)m_attackspeed;
	pi->movingspeed = (char)m_movespeed;
	// �̸� ��� �ε��� ��ȣ ���� ���� �Լ�
	//sprintf(pi->charactername,"%d %d", m_info.m_id, m_npcindex);
}

void npcinfo::makeProtocolBaseIn()
{
	m_protocolBaseIn.header = fbasein;
	m_protocolBaseIn.userindex = m_npcindex;
	memcpy(m_protocolBaseIn.charactername, m_proto.m_namek, CNAME_LENGTH);
	//	m_protocolBaseIn.characterclass = (short)(m_info.m_cd);
}


void snpcinfo::SetBaseSummonInfo(BaseNPCInfo *bninfo, int index)
{
	memcpy(&m_info, bninfo, sizeof(m_info));

	//m_info.m_exp += m_info.m_exp;

	if (m_info.m_dangerhp < 0)
		m_info.m_dangerhp = (short)(-m_proto.m_hp * m_info.m_dangerhp / 100);

	m_body_size2 = m_proto.m_body_size * m_proto.m_body_size;
	m_attack_range2 = m_proto.m_attack_range * m_proto.m_attack_range;
	//m_info.m_reaction_range *= m_info.m_reaction_range;
	reaction_range2 = m_proto.m_reaction_range * m_proto.m_reaction_range;


	// m_startingPoint = m_info.m_point;  // ���� ��ġ üũ �ϱ�. 

	m_dwLastTime = GetTickCount();

	m_dwDelayTime = 500;

	m_area = 0;

	m_lpThread = NULL;

	if (!IsLoad()) {
		calGradeProb();
	}

	//	makeprotocol(&protocolIn);
}

snpcinfo::snpcinfo()
{
	m_masterindex = -1;
	m_state = summonstand;
	m_summon_npcindex = -1;
	start_time = -1;
	alonetime_start = -1;
	m_masterattack = -1;
	m_masterattack_pcindex = -1;
	attackTime = 0;
	skillstarttime = 0;
	skilldelaytime = 0;
	skillDelayTime = 0;
	skillCastingTime = 0;
	gdt = 0;
	gddt = 0;
	ZeroMemory(&m_info, sizeof(m_info));
	ZeroMemory(&m_proto, sizeof(m_proto));
	cur_skillid = 0;
	cur_skilllevel = 0;
	dskillcode = 0;
	dskillarea = 0;
	dskilllevel = 0;
	dskillpk = 0;
	exist_time = 0;
	m_attackerindex = 0;
	m_mindex = 0;
	m_area = 0;
	m_blockindex = 0;
	m_lpThread = NULL;
	m_dwLastTime = 0;
	m_dwDelayTime = 0;
	m_dwAIStateTime = 0;
	m_dwActionTime = 0;
	m_skilldelaytime = 0;
	m_dwLastSkillTime = 0;
	skill_count = 0;
	ZeroMemory(&m_ActionList, sizeof(m_ActionList));
	m_pointcounter = 0;
	m_pointnum = 0;
	m_aistate = 0;
	m_maintarget = 0;
	m_statedurationtime = 0;
	m_isleaderdead = false;
	m_isgroupmemberdead = false;
	m_isnpcarounddead = false;
	m_maintargetdecisionpattern = 0;
	m_decisionmakingpattern = 0;
	m_movingpattern = 0;
	m_isinfirstrange = false;
	m_isinsecondrange = false;
	m_isnpcaroundmetarget = false;
	m_istherepkaroundme = false;
	m_ismaintargetdisappeared = false;
	m_ismaintargetoutofrange = false;
	m_isuserattackedme = false;
	m_isaistatetimespend = false;
	m_isfirstattackerdisappeared = false;
	m_curlastuserattackme = 0;
	m_curfirstuserattackme = 0;
	m_near_npcindex = 0;
	m_behavior = 0;
	m_maintargetdistance = 0;
	roomindex = 0;
	ZeroMemory(&option, sizeof(option));
	killer = 0;
	moid = 0;
	m_hp_cur = 0;
	ZeroMemory(abStateCode, sizeof(abStateCode));
	ZeroMemory(durationstarttime, sizeof(durationstarttime));
	ZeroMemory(duration, sizeof(duration));
	ZeroMemory(durationFlags, sizeof(durationFlags));
	ZeroMemory(&m_useraroundme, sizeof(m_useraroundme));
	ZeroMemory(&m_npcaroundme, sizeof(m_npcaroundme));
	ZeroMemory(&m_bnpcaroundme, sizeof(m_bnpcaroundme));
	m_firstattacker = 0;
	ZeroMemory(m_attacked, sizeof(m_attacked));
	m_attackedlistindex = 0;
	m_iBeforeDecision = 0;
	m_iCountBack = 0;
	m_iDonotMoveDirection = 0;
	ZeroMemory(&protocolIn, sizeof(protocolIn));
	ZeroMemory(&protocolBaseIn, sizeof(protocolBaseIn));
	ZeroMemory(sbattribute, sizeof(sbattribute));
	movespeed = 0;
	attackspeed = 0;
	level = 0;
	defense = 0;
	defenseRate = 0;
	attd_max = 0;
	attd_min = 0;
	fire_resi = 0;
	water_resi = 0;
	light_resi = 0;
	poison_resi = 0;
	critic = 0;
	critic_prob = 0;
	attacktime = 0;
	ZeroMemory(&dskill, sizeof(dskill));
	movedist = 0;
	reaction_range2 = 0;
	m_body_size2 = 0;
	m_attack_range2 = 0;
	ZeroMemory(possible, sizeof(possible));
	gradeProbSum = 0;
	skill_num = 0;
	isAlone = FALSE;
	isBackToTheMaster = FALSE;
	max_slvl = 0;
	ZeroMemory(skill_id, sizeof(skill_id));
	ZeroMemory(skill_level, sizeof(skill_level));
	ZeroMemory(skill_vid, sizeof(skill_vid));
	ZeroMemory(skill_value, sizeof(skill_value));
	gdtarget = 0;
	gddam = 0;
	gdprop = 0;
	gdcritic = 0;
	tcounter = 0;
	ZeroMemory(m_userlist, sizeof(m_userlist));
	ZeroMemory(m_npclist, sizeof(m_npclist));
	usercount = 0;
	npccount = 0;
	thornsdam = 0;
	SuperZone = 0;
	movezoneset = false;
	movezonetime = 0;
	real_skill_level = 0;
	askill_attrate = 0;
	askill_attdphy = 0;
	askill_sthp = 0;
	askill_stmp = 0;
	askill_attrange = 0;
	askill_breakprob = 0;
	critic_dam = 0;
	attratephy = 0;
	w_range = 0;
	m_first_range = 0;
	m_second_range = 0;
	m_isCataAttack = false;
}

snpcinfo::~snpcinfo(){}
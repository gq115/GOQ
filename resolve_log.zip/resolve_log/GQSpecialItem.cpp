#include "GQSpecialItem.h"
using namespace std;



GQSpecialItem::GQSpecialItem()
{
}


GQSpecialItem::~GQSpecialItem()
{
}

//����Special.dat
void GQSpecialItem::makesindex()		//index�� �����ϴ� option list������ ��ġ�� ����صδ� list�� �����Ѵ�.
{
	for (int i = 0; i < maxsp; i++)
	{
		if (splist[i].bitemid >= 0 && splist[i].bitemid < MAX_BASE_ITEM_CODE)  // <djelee> : 2011.04.08 : üũ ���� ���� 
			sindex[splist[i].bitemid] = i;
	}
}
void GQSpecialItem::LoadSpecial() {
	long rc = -1;

	HANDLE hRFile = CreateFile("data/Special.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		DWORD dwTemp;
		ZeroMemory(splist, sizeof(splist));
		ZeroMemory(divineindex, sizeof(divineindex));
		memset(sindex, -1, sizeof(sindex));
		ReadFile(hRFile, &rc, sizeof(rc), &dwTemp, NULL);
		ReadFile(hRFile, splist, sizeof(splist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		maxsp = rc;
		if (maxsp > MAX_SPECIAL_NUM) maxsp = MAX_SPECIAL_NUM;

		maxextreme = 0;
		maxdivine = 0;
		maxupgradeable = 0;
		for (short i = 0; i < maxsp; i++) {
			int firstnum = (int)(splist[i].bitemid*0.001);
			if (firstnum == 3) {
				divineindex[maxdivine++] = i;
			}
		}
		makesindex();
	}
}
void GQSpecialItem::WriteSpecial() {
	printf("Begin Write Special.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/Special.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("Special.CSV open error!!!\n");
		return;
	}
	oFile << "sitemid " << "," << "namek " << "," << "namee " << "," << "totalnumber " << "," << "percentage " << "," << "bitemid " << "," << "soption1 " << "," << "soption2 " << "," << "soption3 " << "," << "soption4 " << "," << "soption5 " << "," << "soption6 " << "," << "soption7 " << "," << "soption8 " << "," << "grade" << "\n";
	for (int i = 0; i < MAX_SPECIAL_NUM; i++) {
		if (splist[i].sitemid <= -1) {
			continue;
		}

		oFile << splist[i].sitemid << ",";
		while (void * pi = memchr(splist[i].namek, ',', 50)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(splist[i].namek, '\n', 50)) {
			*((char *)pi) = '_';
		}
		oFile << splist[i].namek << ",";
		while (void * pi = memchr(splist[i].namee, ',', 50)) {
			*((char *)pi) = '0';
		}
		while (void * pi = memchr(splist[i].namee, '\n', 50)) {
			*((char *)pi) = '_';
		}
		oFile << splist[i].namee << ",";
		oFile << splist[i].totalnumber << ",";
		oFile << splist[i].percent << ",";
		oFile << splist[i].bitemid << ",";
		oFile << splist[i].optionid[0] << ",";
		oFile << splist[i].optionid[1] << ",";
		oFile << splist[i].optionid[2] << ",";
		oFile << splist[i].optionid[3] << ",";
		oFile << splist[i].optionid[4] << ",";
		oFile << splist[i].optionid[5] << ",";
		oFile << splist[i].optionid[6] << ",";
		oFile << splist[i].optionid[7] << ",";
		oFile << (int)splist[i].grade << "\n";
	}

	oFile.close();
	printf("End Write Special.CSV\n\n");
}

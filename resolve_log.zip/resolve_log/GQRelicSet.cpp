#include "GQRelicSet.h"
using namespace std;


GQRelicSet::GQRelicSet()
{
}


GQRelicSet::~GQRelicSet()
{
}

void GQRelicSet::GQOpen() {
	printf("Begin Load RelicSet.dat\n");
	if (m_cRelicSet.Open("data\\RelicSet.dat")) {
		printf("End Load RelicSet.dat\n");
	}
	else {
		printf("Error NewGrowth RelicSet.dat\n");
	}
	return;
}

void GQRelicSet::GQWrite() {
	printf("Begin Write RelicSet.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/RelicSet.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("RelicSet.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	struct RELICSET_DATA	*pRelic = NULL;
	oFile << "ItemID " << "," << "ResultID1 " << "," << "Amount1 " << "," << "ResultID2 " << "," << "Amount2 " << "," << "ResultID3 " << "," << "Amount3 " << "," << "ResultID4 " << "," << "Amount4 " << "," << "ResultID5 " << "," << "Amount5 " << "," << "ResultID6 " << "," << "Amount6" << "\n";
	state = m_cRelicSet.GetFirstItem();
	while (pData = m_cRelicSet.GetNextItem(state)) {
		pRelic = (struct RELICSET_DATA *)pData;
		if (pRelic->nItemID <= -1)
			continue;
		if (pRelic == NULL) {
			continue;
		}
		oFile << pRelic->nItemID << ",";
		oFile << pRelic->result[0].nAmount << ",";
		oFile << pRelic->result[0].nResultID << ",";
		oFile << pRelic->result[1].nAmount << ",";
		oFile << pRelic->result[1].nResultID << ",";
		oFile << pRelic->result[2].nAmount << ",";
		oFile << pRelic->result[2].nResultID << ",";
		oFile << pRelic->result[3].nAmount << ",";
		oFile << pRelic->result[3].nResultID << ",";
		oFile << pRelic->result[4].nAmount << ",";
		oFile << pRelic->result[4].nResultID << ",";
		oFile << pRelic->result[5].nAmount << ",";
		oFile << pRelic->result[5].nResultID << "\n";
	}

	oFile.close();
	printf("End Write RelicSet.CSV\n");
}
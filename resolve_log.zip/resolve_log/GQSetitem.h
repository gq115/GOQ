#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQSetitem
{
public:
	GQSetitem();
	~GQSetitem();

	int 	numset;
	int 	setindex[MAX_BASE_ITEM_CODE];
	SSet	setlist[MAX_SET];
	void makesetindex();
	bool LoadSetItem();
	void GQWrite();
};


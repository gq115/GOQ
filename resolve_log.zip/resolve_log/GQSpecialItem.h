#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQSpecialItem
{
public:
	GQSpecialItem();
	~GQSpecialItem();

	special splist[MAX_SPECIAL_NUM];
	int 	sindex[MAX_BASE_ITEM_CODE];
	int 	maxsp;
	short 	divineindex[MAX_SPECIAL_NUM];
	short 	maxextreme;
	short 	maxdivine;
	short 	maxupgradeable;
	void makesindex();
	void LoadSpecial();
	void WriteSpecial();
};


#include "DatFunc.h"
using namespace std;


DatFunc::DatFunc()
{
}


DatFunc::~DatFunc()
{
}


void DatFunc::LoadTaxFile(){
	DWORD dwTemp;
	HANDLE hRFile = CreateFile("dat/tax.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "no tax file\n");
	}
	else
	{
		ReadFile(hRFile, &m_Smio, sizeof(m_Smio), &dwTemp, NULL);
		for (int i = 0; i < MAX_ZONE; i++)
		{
			//m_Castlelist[i].setTax(m_Smio[i].gold);
		}
	}
}


bool DatFunc::GetLottoList(){
	HANDLE hFile = CreateFile("data\\Lotto.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "Can't Open Lotto.dat\n");
		return false;
	}

	DWORD dwTemp;

	ReadFile(hFile, &m_iLottoCount, sizeof(int), &dwTemp, NULL);
	// �ϴ� �ӽ÷� ������ ������ 10,000,000���� ����.
	if (m_iLottoCount < 0 || m_iLottoCount > 10000000)
	{
		CloseHandle(hFile);
		_RPTF1(_CRT_WARN, "Invalid Lotto Number : %d\n", m_iLottoCount);
		m_iLottoCount = 0;
		return false;

	}

	m_TimeTable = new LottoTime[m_iLottoCount];

	if (m_TimeTable == NULL)
	{
		CloseHandle(hFile);
		_RPTF0(_CRT_WARN, "Can't Alloc Memory\n");
		m_iLottoCount = 0;
		return false;
	}

	ReadFile(hFile, m_TimeTable, sizeof(LottoTime)*m_iLottoCount, &dwTemp, NULL);

	char tale[200];
	//char LOG[200];
	ZeroMemory(tale, 200);
	ReadFile(hFile, tale, 200, &dwTemp, NULL);

	CloseHandle(hFile);
	return true;
}


void DatFunc::CreateModuleMap() {
	m_cTeleport.Open("data\\TeleportBook.dat");
	m_cMultiScroll.Open("data\\MultiScroll.dat");
	m_cHonorRewardList.Open("data\\HonorRewardList.dat");
	m_cTitleList.Open("data\\TItleList.dat");
	m_cCollectionBook.Open("data\\CollectionBook.dat");
	m_cPVPGrade.Open("data\\PVPGrade.dat");
	m_cGuildLevel.Open("data\\GuildLevel.dat");
}

bool DatFunc::LoadAIStateData(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aistate.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, m_aistate, sizeof(short)*MAX_STATECHPATTERN*MAX_STATE*MAX_CIRCUMSTANCE * 2, &dwTemp, NULL);
		char tale[200];
		ZeroMemory(tale, 200);
		DWORD size;
		ReadFile(hFile, tale, 200, &size, NULL);
		if (sizeof(short)*MAX_STATECHPATTERN*MAX_STATE*MAX_CIRCUMSTANCE * 2 != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}

bool DatFunc::LoadAIDecisionData(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aidecision.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, m_aidecision, sizeof(decision)*MAX_DECISION_CODE*MAX_STATE*MAX_VALUE_NUM, &dwTemp, NULL);
		char tale[200];
		ZeroMemory(tale, 200);
		DWORD size;
		ReadFile(hFile, tale, 200, &size, NULL);

		if (sizeof(decision)*MAX_DECISION_CODE*MAX_STATE*MAX_VALUE_NUM != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}

bool DatFunc::LoadAIPatternData(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aipattern.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, m_aipattern, sizeof(short)*MAX_AI_CODE * 3, &dwTemp, NULL);
		DWORD size;
		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hFile, tale, 200, &size, NULL);

		if (sizeof(short)*MAX_AI_CODE * 3 != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}

void DatFunc::LoadExpGoal(){
	HANDLE hRFile = CreateFile("data/expgoal.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - expgoal.dat  \n");
		memset(m_Levellist, 0, sizeof(m_Levellist));
		DWORD dwTemp;
		ReadFile(hRFile, m_Levellist, sizeof(m_Levellist), &dwTemp, NULL);

		// 20100928 �߰�(�̼���:����ġ ���̺� ���� ��ǥ ����ġ �����Ⱚ������ ���� ���� �� ���ѷ��� ���� ������ ���� ���� ��ǥ ����ġ �߰�)
		// ��� ���� ��ǥ ����ġ �ڵ忡 �����ϸ� ������������ ó�� ������ �ε� �� �����Ⱚ ��� �� �־���
		m_Levellist[125].expgoal = m_Levellist[124].expgoal * 2;
		m_Levellist[125].dbMasterExpGoal = m_Levellist[124].dbMasterExpGoal * 2;

		// 20131106 ����(���ٿ�:2�� ������ Ŭ���� �߰��� 2�� �Ϲ� Ŭ���� ���� Ȯ�� ���� ó��)
		m_Levellist[MAX_LEVEL_2ND_MASTER - 1].dbExpGoal2 = m_Levellist[MAX_LEVEL_2ND_MASTER - 2].dbExpGoal2 * 2;
		m_Levellist[MAX_LEVEL_2ND_MASTER - 1].dbInfiniteExpGoal = m_Levellist[MAX_LEVEL_2ND_MASTER - 2].dbInfiniteExpGoal * 2;

		char tale[200];

		ZeroMemory(tale, 200);

		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		m_Levellist[0].dbMasterExpGoal = 0;
		m_Levellist[0].expgoal = 0;
		m_Levellist[0].dbExpGoal2 = 0;
		m_Levellist[0].wexpweit = 0;
		m_Levellist[0].dbInfiniteExpGoal = 0;	// ������ ����ġ

		_RPTF0(_CRT_WARN, "Load Data - expgoal.dat END \n");
	}
}

void DatFunc::LoadCharacterClass(){
	HANDLE hRFile = CreateFile("data/cclass.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - cclass.dat  \n");
		ZeroMemory(m_ChrClass, sizeof(m_ChrClass));

		DWORD dwTemp;
		ReadFile(hRFile, m_ChrClass, sizeof(m_ChrClass), &dwTemp, NULL);

		char tale[200];

		ZeroMemory(tale, 200);

		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - cclass.dat END \n");
	}
}

void DatFunc::LoadGrade(){
	HANDLE hRFile = CreateFile("data/grade.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - grade.dat  \n");
		ZeroMemory(m_gradelist, sizeof(m_gradelist));
		DWORD dwTemp;
		ReadFile(hRFile, m_gradelist, sizeof(m_gradelist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - grade.dat END \n");
	}
}

void DatFunc::LoadMOption(){
	HANDLE hRFile = CreateFile("data/moption.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - moption.dat  \n");

		DWORD dwTemp;
		ReadFile(hRFile, &m_nMopnum, 4, &dwTemp, NULL);
		ReadFile(hRFile, m_Moplist, sizeof(m_Moplist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - moption.dat END \n");
	}
}

void DatFunc::LoadVirtue(){
	HANDLE hRFile = CreateFile("data/virtue.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hRFile == INVALID_HANDLE_VALUE)
	{
		_RPTF0(_CRT_WARN, "file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - virtue.dat  \n");

		DWORD dwTemp;
		ZeroMemory(m_Virlist, sizeof(m_Virlist));
		ReadFile(hRFile, m_Virlist, sizeof(m_Virlist), &dwTemp, NULL);

		char tale[200];
		ZeroMemory(tale, 200);
		ReadFile(hRFile, tale, 200, &dwTemp, NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - virtue.dat END \n");
	}

	m_nMaxvirnum = 0;
	for (int i = 0; i < MAX_VIRTUE; i++)
	{
		if (m_Virlist[i].id > 0)
		{
			m_nMaxvirnum++;
		}
	}
}

bool DatFunc::LoadMode(){
	if (!m_cTable.Open("data\\Mode.dat"))
		return FALSE;
	return TRUE;
}


bool DatFunc::LoadAIState(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aistate.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, aistate, sizeof(short)*MAX_STATECHPATTERN*MAX_STATE*MAX_CIRCUMSTANCE * 2, &dwTemp, NULL);
		if (sizeof(short)*MAX_STATECHPATTERN*MAX_STATE*MAX_CIRCUMSTANCE * 2 != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}

bool DatFunc::LoadAIDecision(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aidecision.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, aidecision, sizeof(decision) * MAX_DECISION_CODE * MAX_STATE * MAX_VALUE_NUM, &dwTemp, NULL);
		if (sizeof(decision) * MAX_DECISION_CODE * MAX_STATE * MAX_VALUE_NUM != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}

bool DatFunc::LoadAIPattern(){
	HANDLE hFile;
	DWORD dwTemp;

	hFile = CreateFile("data/aipattern.dat", GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		ReadFile(hFile, aipattern, sizeof(short) * MAX_AI_CODE * 3, &dwTemp, NULL);
		if (sizeof(short)*MAX_AI_CODE * 3 != dwTemp)
		{
			CloseHandle(hFile);
			return false;
		}
		CloseHandle(hFile);
		return true;
	}
	return false;
}
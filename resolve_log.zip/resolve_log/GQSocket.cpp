#include "GQSocket.h"
using namespace std;


GQSocket::GQSocket()
{
}


GQSocket::~GQSocket()
{
}

void GQSocket::GQOpen() {
	printf("Begin Load SocketPunch.dat\n");
	if (m_cSocketPunch.Open("data\\SocketPunch.dat")) {
		printf("End Load SocketPunch.dat\n");
	}
	else {
		printf("Error NewGrowth SocketPunch.dat\n");
	}

	printf("Begin Load SocketItem.dat\n");
	if (m_cSocketItem.Open("data\\SocketItem.dat")) {
		printf("End Load SocketItem.dat\n");
	}
	else {
		printf("Error NewGrowth SocketItem.dat\n");
	}

	printf("Begin Load SocketSet.dat\n");
	if (m_cSocketSet.Open("data\\SocketSet.dat")) {
		printf("End Load SocketSet.dat\n");
	}
	else {
		printf("Error NewGrowth SocketSet.dat\n");
	}
	return;
}

void GQSocket::GQWrite() {
	printf("Begin Write SocketPunch.CSV\n");
	ofstream oFile;
	oFile.open("dataCSV/SocketPunch.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("SocketPunch.CSV open error!!!\n");
		return;
	}

	STATE	state;
	LPVOID	pData;
	SSocketPunch	*pSPunch = NULL;
	state = m_cSocketPunch.GetFirstItem();
	oFile << "ItemID " << "," << "PunchFailed " << "," << "Punch1 " << "," << "Punch2 " << "," << "Punch3 " << "," << "Punch4 " << "," << "Punch5" << "\n";
	while (pData = m_cSocketPunch.GetNextItem(state)) {
		pSPunch = (SSocketPunch *)pData;
		if (pSPunch->nItemID <= -1)
			continue;
		if (pSPunch == NULL) {
			continue;
		}
		oFile << pSPunch->nItemID << ",";
		oFile << pSPunch->wPunch[0] << ",";
		oFile << pSPunch->wPunch[1] << ",";
		oFile << pSPunch->wPunch[2] << ",";
		oFile << pSPunch->wPunch[3] << ",";
		oFile << pSPunch->wPunch[4] << ",";
		oFile << pSPunch->wPunch[5] << "\n";
	}
	oFile.close();
	printf("End Write SocketPunch.CSV\n");


	printf("Begin Write SocketItem.CSV\n");
	oFile.open("dataCSV/SocketItem.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("SocketItem.CSV open error!!!\n");
		return;
	}
	SSocketItem	*pSItem = NULL;
	state = m_cSocketItem.GetFirstItem();
	oFile << "ItemID " << "," << "Opt1 " << "," << "Value1 " << "," << "Position " << "," << "wclass " << "," << "Ratio" << "\n";
	while (pData = m_cSocketItem.GetNextItem(state)) {
		pSItem = (SSocketItem *)pData;
		if (pSItem->nItemID <= -1)
			continue;
		if (pSItem == NULL) {
			continue;
		}
		oFile << pSItem->nItemID << ",";
		oFile << pSItem->wOption << ",";
		oFile << pSItem->wValue << ",";
		oFile << pSItem->wPosition << ",";
		oFile << pSItem->wWeaponClass << ",";
		oFile << pSItem->wRatio << "\n";
	}

	oFile.close();
	printf("End Write SocketItem.CSV\n");



	printf("Begin Write SocketSet.CSV\n");
	oFile.open("dataCSV/SocketSet.CSV", ios::out);
	if (!oFile.is_open()) {
		printf("SocketSet.CSV open error!!!\n");
		return;
	}
	SSocketSet	*pSSet = NULL;
	state = m_cSocketSet.GetFirstItem();
	oFile << "SetCount " << "," << "Set1 " << "," << "Set2 " << "," << "Set3 " << "," << "Set4 " << "," << "Set5 " << "," << "Opt1 " << "," << "Value1 " << "," << "Opt2 " << "," << "Value2 " << "," << "Opt3 " << "," << "Value3 " << "," << "Opt4 " << "," << "Value4 " << "," << "Opt5 " << "," << "Value5 " << "," << "Opt6 " << "," << "Value6 " << "," << "Opt7 " << "," << "Value7 " << "," << "Opt8 " << "," << "Value8 " << "," << "Opt9 " << "," << "Value9 " << "," << "Opt10 " << "," << "Value10" << "\n";
	while (pData = m_cSocketSet.GetNextItem(state)) {
		pSSet = (SSocketSet *)pData;
		if (pSSet == NULL) {
			continue;
		}
		oFile << pSSet->nSetCount << ",";
		oFile << pSSet->nSetItemID[0] << ",";
		oFile << pSSet->nSetItemID[1] << ",";
		oFile << pSSet->nSetItemID[2] << ",";
		oFile << pSSet->nSetItemID[3] << ",";
		oFile << pSSet->nSetItemID[4] << ",";

		oFile << pSSet->wOption[0] << ",";
		oFile << pSSet->wValue[0] << ",";
		oFile << pSSet->wOption[1] << ",";
		oFile << pSSet->wValue[1] << ",";
		oFile << pSSet->wOption[2] << ",";
		oFile << pSSet->wValue[2] << ",";
		oFile << pSSet->wOption[3] << ",";
		oFile << pSSet->wValue[3] << ",";
		oFile << pSSet->wOption[4] << ",";
		oFile << pSSet->wValue[4] << ",";
		oFile << pSSet->wOption[5] << ",";
		oFile << pSSet->wValue[5] << ",";
		oFile << pSSet->wOption[6] << ",";
		oFile << pSSet->wValue[6] << ",";
		oFile << pSSet->wOption[7] << ",";
		oFile << pSSet->wValue[7] << ",";
		oFile << pSSet->wOption[8] << ",";
		oFile << pSSet->wValue[8] << ",";
		oFile << pSSet->wOption[9] << ",";
		oFile << pSSet->wValue[9] << "\n";
	}

	oFile.close();
	printf("End Write SocketSet.CSV\n");
}
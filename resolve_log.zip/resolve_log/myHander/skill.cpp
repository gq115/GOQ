#define _WINSOCKAPI_
#ifdef _WIN64
	#pragma pack(8) // <djelee> : <struct member alignment> : <alignment���� 1�� ���, ListView_InsertColumn(commctrl32.dll)���� Access Violation �߻�>
	#include <atlcoll.h>
	#pragma pack()
#else
	#include <atlcoll.h>
#endif
#undef _WINSOCKAPI_
#include <crtdbg.h>
#include "global.h"
//#include "userlist.h"
#include "NPCThreadManager.h"
#include "Ground.h"
#include "SUMM_NPCThreadManager.h"
#include "scenario.h"
#include "scenariocommand.h"
#include "Profiler.h"

extern UserList* g_UserList;
extern CNPCThreadManager*	 g_pNPCThreadManager;
extern CGround* g_Ground;

CSkill g_Skill;

CSkill::CSkill()
{
	LoadSkill();
	LoadOSkill();

	//UJ 110712, ��ų�����Ϳ��� MaxLevel���� �̸� ����ؼ� �ӵ��� ����Ų��(�� 58�� ����)
	for(int n=0; n<MAX_SKILL_CODE; ++n)
	{
		m_SkillMaxLevel[n] = MAX_SLVL-1;
		for(int nMaxLevel = 0; nMaxLevel < MAX_SLVL; ++nMaxLevel)
		{
			if (m_Skilllist[n].m_Slvl[nMaxLevel].m_sReqlvl == -1)
			{
				m_SkillMaxLevel[n] = nMaxLevel - 1;
				break;
			}
		}

		//UJ 110726, �ɼǽ�ų ����1�ΰ��� ��ȸ �����ϹǷ� �ӵ��� ����Ų��(�� 14~32�� ����)
		m_pOptionSkillLv1[n] = FindOptionSkillInfo(n, 1);
	}
}

bool CSkill::skilluse(int skillcode,int slvl,Point target,int userindex)
{
	PROFILER_SCOPE_TIMER(CSkill_skilluse)
	bool succeed = true;
	if(skillcode >= 0 && skillcode < MAX_SKILL_CODE)
	{
		switch(m_Skilllist[skillcode].m_chTarget)
		{
		case stonetarget:
			useskillonetarget();
			break;
		case stself:
			useskillself();
			break;
		case starea:
			if(useskillarea(skillcode,target,slvl,userindex))
			{
				succeed = true;
			}
			else
			{
				succeed= false;
			}
			break;
		case stparty:
			useskillparty();
			break;
		case stpassive:
		default:
			break;
		}
	}
	else
	{
		succeed = false;
	}

	return succeed;
}

// 0109 kmj insert
/**
@brief ��ų ȿ�� ����
@date 20120627
@author �̼���(bestdev@gameonstudio.co.kr)
@param skillcode(��ų ID)
@param slvl(����� ��ų ����)
@param targetindex(��ų �´� ��� ���� �ε���)
@param userindex(��ų ��� ���� �ε���)
@param pk(PK����)
@param pkmode(PK ���, ������)
@param pt(��ų �����ġ)
@return ����
*/
void CSkill::skilleffect(int skillcode, int slvl, int targetindex,int userindex,int pk,int pkmode,Point pt)
{
	PROFILER_SCOPE_TIMER(CSkill_skilleffect)
	if(skillcode < 0 || skillcode >=MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	int att = m_Skilllist[skillcode].m_nAtt;


	if(!(att & saanytarget))
	{
		if(targetindex<=-MAX_NPC || targetindex>=MAX_USER+MAX_SUMMON_NPC)
		{
			RPTFONE("targetindex",targetindex);
			return;
		}

		//�������� ��ų�϶�
		if(att & sahostile)
		{				
			if( userindex == targetindex)
			{
				return;
			}

			int user_master_index = MAX_USER;
			bool oisdead;

			snpcinfo * si;
			// ��ų ����ڰ� ��ȯ�� 
			if( userindex >= MAX_USER && userindex <  MAX_USER+MAX_SUMMON_NPC )
			{
				si = g_pSummonNPCThreadManager->GetSummon(userindex);
				if(si)
				{
					user_master_index = si->GetMasterIndex();
					oisdead = si->isdead();
				}
				else
				{
					return;
				}
 			}
			else if(userindex>=0 && userindex<MAX_USER)
			{	//��ų����ڰ� ����
				user_master_index = userindex;
				userinfo* ui = g_UserList->GetUser(userindex);
				if(ui)
				{
					oisdead = ui->isdead();
				}
			}
			else
			{
				user_master_index = userindex;
			}

			if(userindex>=0)
			{
				//Ÿ���� pc
				if(targetindex >= 0)
				{
					//pk ���ΰ� ������
					if(pk)
					{
						int target_master_index = MAX_USER; // 0210 kmj 

						// ��ų�� Ÿ���� ��ȯ��
						if( targetindex >= MAX_USER && targetindex <MAX_USER+MAX_SUMMON_NPC )
						{
							si = g_pSummonNPCThreadManager->GetSummon(targetindex); // 0207 kmj 
							if(si)
							{
								target_master_index = si->GetMasterIndex();
							}
							else
							{
								return;
							}
						}
						else
						{
							target_master_index = targetindex;
						}

						if( (target_master_index >= MAX_USER) || (user_master_index >= MAX_USER))
						{
							return;
						}

						if(user_master_index>=0)
						{
							userinfo* ui = g_UserList->GetUser(target_master_index);
							userinfo* uinfo = g_UserList->GetUser(user_master_index);
							if(uinfo && ui)
							{
								SBonusAttribute attb = uinfo->GetBonusAttribute();

								if(attb.invincibility)
								{
									return;
								}
								
								// 0214 kmj
								if(!uinfo->pkcheck(ui->getpkmode(),ui->getLev(),oisdead, target_master_index))//targetindex))  
								{		//����� ���� 15�̸��̸� ����
									return;
								}

								// 0211 kmj ///////////////////////////////////////
								int sindex = uinfo->GetSummonindex();
								if(sindex == targetindex)
								{
									return;
								}

								snpcinfo * sin = g_pSummonNPCThreadManager->GetSummon(sindex);
								if(sin)
								{
									int k = sin->GetEnemyOfMaster();
									if( k < 0 )
									{
										sin->SetEnemyOfMaster(targetindex);
									}
								}
								////////////////////////////////////////////////////

#ifdef _GMSIEGE
								// 20110318 �߰�(�̼���:GM���� �̺�Ʈ ���� ������ ��ų�� �߸��� ��� �� �߸����� ���� �ȵǰ� ��)
								Castle	*pCastle;
								DWORD dwDefenderUnion = 0;

								// 20120110 ����(���ٿ�:������ �ϵ��ڵ� ����)
								//pCastle = g_clist.GetCastle(115);
								pCastle = g_clist.GetCastle(SIEGE_ZONE_ID);

								dwDefenderUnion = pCastle->GetUnionCode(eST_Defender);

								// �����ڿ� Ÿ���� �Ѵ� ������ �ƴ� ��� ���� �ȵǰ� ��
								if(dwDefenderUnion != ui->getUnionCode() && uinfo->getUnionCode() != dwDefenderUnion)
								{
									return;
								}

								// �����ڿ� Ÿ���� �Ѵ� ������ ��� ���� �ȵǰ� ��
								if(dwDefenderUnion == ui->getUnionCode() && uinfo->getUnionCode() == dwDefenderUnion)
								{
									return;
								}
#endif
							}
						}
					}
					// �����̰� �ƴ� ��� 
					else 
					{
						return;			//������ ����
					}
				}
				// Ÿ���� ���ǽ�
				else
				{
					if(user_master_index>=0)
					{
						userinfo* uinfo = g_UserList->GetUser(user_master_index);
						if(!uinfo->npkcheck(targetindex))
						{
							return;
						}
					}
				}
			}
			else
			{
				if(targetindex<0)
				{
					return;
				}
			}
		}
		//���������� ���� ��ų�϶�
		else
		{					
			if(userindex >=0)
			{
				if( targetindex != userindex )
				{
					// 20180220 �߰�(���ٿ�:���������� ������, �ڱ� �ڽſ��� ����ϴ� ��ų�� Target�� �߸� ���� ������ �����Ѵ�)
					if(m_Skilllist[skillcode].m_chTarget == stself )
					{
						// 20180321 �߰�(���ٿ�:��Ƽ ������ �������� ���ͼ� ��Ƽ ������ �ƴ� ���ɼ��� �ִ� ��쿡�� Ÿ���� �����Ѵ�.)
						if ( m_Skilllist[skillcode].m_nAreatype == 1 )
						{
							userinfo* uinfo = g_UserList->GetUser(userindex);
							if ( uinfo )
							{
								if ( 0 > uinfo->GetPartyIndex() )
								{
									targetindex = userindex;
								}
							}
						}
						else
						{
							targetindex = userindex;
						}
					}

					// 0210 kmj 
					int user_master_index = MAX_USER, target_master_index = MAX_USER; // 0210 kmj 
					snpcinfo * si;

					// ��ų���� �̰� ��ȯ��
                    if(userindex >= MAX_USER && userindex <MAX_USER+MAX_SUMMON_NPC)
					{
						si = g_pSummonNPCThreadManager->GetSummon(userindex);
						if(si)
						{
							user_master_index = si->GetMasterIndex();
						}
						else
						{
							return;
						}
					}
					else
					{
						user_master_index = userindex;
					}

					// ��ų ����Ǵ� �̰� ��ȯ�� 
                    if(targetindex >= MAX_USER && targetindex <MAX_USER+MAX_SUMMON_NPC)
					{
						si = g_pSummonNPCThreadManager->GetSummon(targetindex); // 0210 kmj 
						if(si)
						{
							target_master_index = si->GetMasterIndex();
						}
						else
						{
							return;
						}
					}
					else
					{
						target_master_index = targetindex;
					}

					if( target_master_index >= MAX_USER || target_master_index < 0 ||
						user_master_index   >= MAX_USER || user_master_index < 0)
					{
						return;
					}
				}
			}
			else
			{
				// ��ȣ���ε� NPC�� PC���� ��ų�� ���� ����
				if(targetindex>=0)
				{
					return;
				}
			}
		}
	}

	//������
	int nValue;
	if(GetValueByVid(skillcode, slvl, 0, svhitrate, &nValue, NULL))
	{ 
		// 20070523 �߰�(�̼���:������ ������ų ��� �� ��ųȮ�� ���� ���� �����Ǿ����� ��� PK�ÿ��� ��ųȮ�� �����Ѵ�)
		// svhitrate : ��ų�ߵ�Ȯ��
		// svdirectdamage : ������ų ���
		// pk : pk����
		BOOL bDirectDamage = FALSE;

		// 20091214 ����(�̼���:�����Լ� ����)
		// ���н�
		//if((((DWORD)brandlottery()) % 100) + 1 >= nValue)
		// 20101013 ����(�̼���:���� �Լ� if�� �ȿ��� ������ ��ġ ����)
		// if�� �ȿ� ������ ������� �ȵ�
		int nRnd = random(100) + 1;
		if(nRnd >= nValue)
		{
			for(int nCnt = 0; nCnt < VIDNUM; nCnt++)
			{
				if(m_Skilllist[skillcode].m_nVid[nCnt] == svdirectdamage)
				{
					bDirectDamage = TRUE;
					break;
				}
			}

			if(bDirectDamage)
			{
				if(targetindex >= 0 && pk == 1)
				{
					return;
				}
			}
			else
			{
				return;
			}
		}
	}

	bool attsuccess = false;
	for(int i = 0 ;i<VIDNUM;i++)
	{
		switch(m_Skilllist[skillcode].m_nVid[i])
		{
		case svdirectdamage:
			directdamageeffect(skillcode, slvl, targetindex, i, userindex);
			break;
		case svadditionaldamage:
			attsuccess = additionaldamageeffect(skillcode, slvl, targetindex, i, userindex);
			break;
		case svsetstate:
#ifdef _INFINITE
			{
				// 20170217 ����(���ٿ�:���� 1�� ���� ������ 100% ���, 1���� ū ���� ��� Ȯ���� ���)
				if ( att & sahostile )
				{
					userinfo *pUser = g_UserList->GetUser(targetindex);
					if ( pUser )
					{
						SBonusAttribute attb = pUser->GetBonusAttribute();
						if(attb.magicshield == 1 )
						{
							return;
						}
						else if(attb.magicshield > 1 )
						{
							if( attb.magicshield > (random(10000)+1) )
							{
								return;
							}

						}
					}
				}
				durationeffect(skillcode,slvl,targetindex,i,attsuccess,userindex);
			}
#else	//	#ifdef _INFINITE
			{
				userinfo *pUser;
				pUser = g_UserList->GetUser(userindex);

				if(pUser && (att & sahostile))
				{
					SBonusAttribute attb = pUser->GetBonusAttribute();

					if(attb.magicshield > 0)
					{
						return;
					}
				}
			}
			durationeffect(skillcode,slvl,targetindex,i,attsuccess,userindex);
#endif	//	#ifdef _INFINITE
			break;
		case svextra:
			extraeffect(skillcode,slvl,targetindex,i,userindex,pt);
			break;
		case svkill:
			killingeffect(skillcode,slvl,targetindex,i,userindex);
			break;
		case svsummon:
			summonningeffect(skillcode,slvl,i,userindex,pt);
			break;
		case svpolymorph:
			polymorphingeffect(skillcode,slvl,targetindex,i,userindex);
			break;
		case svchange:
			changeeffect(skillcode, slvl, userindex, i);
			break;

		case svlinkskill:
			{
#ifdef _ADD_SKILL_OPTIONS
				// 20140702 �߰�(���ٿ�:svlimitedtime�� �����Ǹ� ���⼭ �ߵ� ��Ű�� �ʴ´�)
				if ( GetValueByVid(skillcode, slvl, 0, svlimitedtime, &nValue, NULL) )
				{
					break;
				}
#endif
				if(pt.y == -1 && pt.x < 0)
				{
					userinfo *pUser = g_UserList->GetUser(userindex);
					pt.z = pUser->getCurrentPoint().z;
				}

				if(GetValueByVid(skillcode, slvl, i, svlinkrand, &nValue, NULL))
				{
					// 20091214 ����(�̼���:�����Լ� ����)
					//if((((DWORD)brandlottery()) % 100) + 1 >= nValue)
					if(random(100) + 1 >= nValue)
					{//���н�
						break;
					}
#ifdef _ADD_SKILL_OPTIONS
					linkskill(skillcode, slvl, i, userindex, pt, pk,targetindex);
#else // _ADD_SKILL_OPTIONS
					linkskill(skillcode, slvl, i, userindex, pt, pk);
#endif // _ADD_SKILL_OPTIONS
				}
				else
				{
#ifdef _ADD_SKILL_OPTIONS
					linkskill(skillcode, slvl, i, userindex, pt, pk,targetindex);
#else // _ADD_SKILL_OPTIONS
					linkskill(skillcode, slvl, i, userindex, pt, pk);
#endif // _ADD_SKILL_OPTIONS
				}
			}
			break;

		case svsummonnpc:
			{
				if(targetindex > 0)
				{
					userinfo *pUser;
					Point	ptDest;

					pUser = g_UserList->GetUser(targetindex);
					if(pUser)
					{
						ptDest = pUser->getCurrentPoint();
						GetRadianPoint(ptDest.x, ptDest.y, 50);
						summonnpceffect(skillcode, slvl, userindex, i, ptDest);
					}
				}
				else
				{
					npcinfo *pNPC;

					pNPC = g_pNPCThreadManager->GetNPC(targetindex);
					if(pNPC)
					{
						summonnpceffect(skillcode, slvl, userindex, i, pNPC->getCurrentPoint());
					}
				}
			}
			break; 
		// 20090518 �߰�(�迵��:skill svalue ���� �߰�)
		case svselfdestruction:
			{
				selfdistructioneffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
#ifdef _ADD_SKILL_OPTIONS
		// 20140530 �߰�(���ٿ�:�������� �ɷ��ִ� ������ N�� �����Ѵ�.)
		case svreleasebuff:
			{
				ReleaseBuffEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
		// 20140609 �߰�(���ٿ�:���� ������ �� 1���� �������� 0���� �����.)
		case svbreakequipped:
			{
				BreakEquippedOneItemEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
		// 20180117 �߰�(���ٿ�:Ÿ���� HP�� MAX HP�� N% ��ŭ ���� ��Ų��.)
		case svreducehp:
			{
				ReduceHPEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
		// 20140612 �߰�(���ٿ�:Ÿ���� MP�� MAX MP�� N% ��ŭ ���� ��Ų��.)
		case svreducemp:
			{
				ReduceMPEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
		// 20140617 �߰�(���ٿ�:���� 1���� ���ڸ� ��Ȱ ��Ų��.)
		case svrestoreuser:
			{
				RestoreUserEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
		// 20140624 �߰�(���ٿ�:�ڽ��� ����Ͽ� ���� ��� �Ϳ� �������� �ش�.)
		case svbomb:
			{
				BombEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
			// 20140701 �߰�(���ٿ�:���� �����۸� ���� �����Ѵ�.)
		case svuneuippeditem:
			{
				UnequippedOneItemEffect(skillcode, slvl, targetindex, i, userindex);
			}
			break;
#endif	//_ADD_SKILL_OPTIONS
		default:
			break;
		}
	}

	if(m_Skilllist[skillcode].m_nAreatype > 0)
	{
		if(userindex != targetindex)
		{
			//userinfo *pUser = NULL;
			//pUser = g_UserList->GetUser(userindex);
			//if(pUser)
			//{
			//	// 20110222 �߰�(�̼���:��ų ��� �α� �߰�)
			//	char szTemp[256] = {0,};
			//	sprintf(szTemp, "%s, %d", pUser->getName(), skillcode);
			//	WRITE_SERVERLOG(LogServer_ServerLog, LogServerClass_ServerLog, fuseskill, szTemp)	
			//}

			pResponseUseSkill prus;
			prus.header = fuseskill;
			prus.subheader = 1;
			prus.skillcode = skillcode;
			prus.slvl = (short)slvl;
			prus.userindex = MAX_USER;
			prus.x = targetindex;
			prus.y = -1;
			prus.z = pt.z;
			char data[SIZE_ONE_DATA];
			GSetDataBlock(data,fuseskill,userindex,(char*)&prus,sizeof(pResponseUseSkill));
			g_Ground->Notice(data);		//����
		}
	}
}

// 20090518 �߰�(�迵��:������ų �Լ� �߰�)
void CSkill::selfdistructioneffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	userinfo *pUser = g_UserList->GetUser(targetindex);
	int nMaxHP = 0;
	int nPercentDamage = 0;

	// 20120115 ����(�Ź�ȣ: �ۼ�Ƽ�� ������ Ȥ�� ���밪 ������ ����)
	// �������� �ۼ�Ʈ �������� ���� �Ϲ� ���� ���밪���� �������� ����.
	if(pUser)
	{
		// 20120207 ����(���ٿ�:������ ��ȣ �ϵ��ڵ� ����)
		//if(115 == pUser->GetZone() || 170 == pUser->GetZone())
#ifdef _DUAL_SIEGE
		if(SIEGE_ZONE_ID == pUser->GetZone() || 170 == pUser->GetZone() || SIEGE_ZONE_ID2 == pUser->GetZone())
#else
		if(SIEGE_ZONE_ID == pUser->GetZone() || 170 == pUser->GetZone())
#endif // _DUAL_SIEGE
		{
			nMaxHP = pUser->getMaxHP();
			nPercentDamage = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];
			if(targetindex != userindex)
			{
				//UJ 111116, int������ nDamage�� �鸸�� ���� �� overflow �߻���-> double�� ĳ�����ؼ� �ذ�
				nMaxHP = (int)(nMaxHP * (double)nPercentDamage/10000.0);
			}
		}
		else
		{
			nMaxHP = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];
		}

		// 20110307 ����(�̼���:���� ��ų ��� �� �������� ��ųvalue ���ڰ� �Ѱ���)
		// ���� �� ��ũ��Ʈ���� ���� ���� ����ϸ� ���� �ʴ� ���� �ذ� ����
		pUser->setdamage(nMaxHP,userindex, svselfdestruction);

		// 20101012 �߰�(������:���� ��ų ��� �α� �߰�)
		BEGIN_USERLOG(pUser->getAccountName(), pUser->getName(), LogUseDestruction)
			ADD_INTFIELD(fldSkill, skillcode)
			ADD_INTFIELD(fldStats, pUser->getCurHP())
		END_LOG()
	}

}

#ifdef _ADD_SKILL_OPTIONS
// 20140530 �߰�(���ٿ�:�������� �ɷ��ִ� ������ N�� �����Ѵ�.)
void CSkill::ReleaseBuffEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vIndex",vIndex);
		return;
	}

	int nValue = g_Skill.GetValuebyParam(skillcode, slvl, svreleasebuff);
	if ( 0 >= nValue )
	{
		return;
	}

	if( IsUser(targetindex) )
	{
		userinfo* ui = g_UserList->GetUser(targetindex);
		if(ui)
		{
			ui->ReleaseBuff(nValue);
		}
	}
	else if( IsNpc(targetindex) )
	{
		npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
		if(ninfo)
		{
			ninfo->ReleaseBuff(nValue);
		}
	}
	else
	{
	}
}

// 20140610 �߰�(���ٿ�:���� ������ �� 1���� �������� 0���� �����.)
void CSkill::BreakEquippedOneItemEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	// ��ų ����� PC�� ��쿡�� ����ȴ�.
	if ( !IsUser(targetindex) )
	{
		return;
	}

	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svbreakequipped != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	userinfo * pTarget = g_UserList->GetUser(targetindex);
	if ( NULL == pTarget )
	{
		return;
	}

	int nItemType = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

	// pTarget�� ���� NULL üũ�� ������ �̹� ����.
	pTarget->BreakEquippedOneItemByItemType( nItemType );
}

/**
@brief: Ÿ���� HP�� MAX HP�� N% ��ŭ ����.
@author:���ٿ�(kyyou@neowiz.com)
@date:  2018/01/17
@param int skillcode
@param int slvl
@param int targetindex
@param int vIndex		: �ش� �Ӽ��� ������ �ɼ� ��ġ
@param int userindex
@return:void
*/
void CSkill::ReduceHPEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	//// ��ų ����� PC�� ��쿡�� ����ȴ�.
	//if ( !IsUser(targetindex) )
	//{
	//	return;
	//}

	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svreducehp != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	int nReduce = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

	if ( IsUser(targetindex) )
	{
		userinfo * pTarget = g_UserList->GetUser(targetindex);
		if ( NULL == pTarget )
		{
			return;
		}

		pTarget->ReduceHPPercent( nReduce );
	}
	else if ( IsNpc(targetindex) )
	{
		npcinfo * pTarget = g_pNPCThreadManager->GetNPC(targetindex);
		if ( NULL == pTarget )
		{
			return;
		}

		pTarget->ReduceHPPercent( nReduce );
	}
	else if ( IsSummon(targetindex) )
	{
		snpcinfo * pTarget = g_pSummonNPCThreadManager->GetSummon(targetindex);
		if ( NULL == pTarget )
		{
			return;
		}

		pTarget->ReduceHPPercent( nReduce );
	}
}

// 20140612 �߰�(���ٿ�:���� MP�� MAX MP�� N% ��ŭ ���� ��Ų��.)
void CSkill::ReduceMPEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	// ��ų ����� PC�� ��쿡�� ����ȴ�.
	if ( !IsUser(targetindex) )
	{
		return;
	}

	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svreducemp != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	userinfo * pTarget = g_UserList->GetUser(targetindex);
	if ( NULL == pTarget )
	{
		return;
	}

	int nReduce = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

	// pTarget�� ���� NULL üũ�� ������ �̹� ����.
	pTarget->ReduceMPPercent( nReduce );

}

// 20140701 �߰�(���ٿ�:���� ������ �� 1���� ���� �����Ѵ�.)
void CSkill::UnequippedOneItemEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	// ��ų ����� PC�� ��쿡�� ����ȴ�.
	if ( !IsUser(targetindex) )
	{
		return;
	}

	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svuneuippeditem != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	userinfo * pTarget = g_UserList->GetUser(targetindex);
	if ( NULL == pTarget )
	{
		return;
	}

	int nItemType = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

	// pTarget�� ���� NULL üũ�� ������ �̹� ����.
	pTarget->UnequippedOneItemByItemType(nItemType);
}

// 20140617 �߰�(���ٿ�:���� 1���� ���ڸ� ��Ȱ ��Ų��.)
void CSkill::RestoreUserEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	// ��ų ����� PC�� ��쿡�� ����ȴ�.
	if ( !IsUser(targetindex) )
	{
		return;
	}

	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svrestoreuser != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	userinfo * pTarget = g_UserList->GetUser(targetindex);
	if ( NULL == pTarget )
	{
		return;
	}

	// ��Ȱ �� ȸ�� �� MP/HP %
	int nMHPRate = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

	// pTarget�� ���� NULL üũ�� ������ �̹� ����.
	pTarget->RestoreSkill(nMHPRate);
}

// 20140624 �߰�(���ٿ�:�ڽ��� ����Ͽ� ���� ��� �Ϳ� �������� �ش�.)
void CSkill::BombEffect(int skillcode, int slvl, int targetindex, int vIndex, int userindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vIndex< 0 || vIndex >= VIDNUM)
	{
		RPTFONE("vindex",vIndex);
		return;
	}

	if ( svbomb != m_Skilllist[skillcode].m_nVid[vIndex] )
	{
		return;
	}

	int nMaxHP = 0;
	int nPercentDamage = 0;

	if ( IsUser(targetindex) )
	{
		userinfo *pUser = g_UserList->GetUser(targetindex);
		// �������� �ۼ�Ʈ �������� ���� �Ϲ� ���� ���밪���� �������� ����.
		if(pUser)
		{
	#ifdef _DUAL_SIEGE
			if(SIEGE_ZONE_ID == pUser->GetZone() || 170 == pUser->GetZone() || SIEGE_ZONE_ID2 == pUser->GetZone())
	#else
			if(SIEGE_ZONE_ID == pUser->GetZone() || 170 == pUser->GetZone())
	#endif // _DUAL_SIEGE
			{
				nMaxHP = pUser->getMaxHP();
				nPercentDamage = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];
				if(targetindex != userindex)
				{
					//UJ 111116, int������ nDamage�� �鸸�� ���� �� overflow �߻���-> double�� ĳ�����ؼ� �ذ�
					nMaxHP = (int)(nMaxHP * (double)nPercentDamage/10000.0);
				}
			}
			else
			{
				nMaxHP = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];
			}

			pUser->setdamage(nMaxHP,userindex, svbomb);
		}
	}
	else if ( IsNpc(targetindex) )
	{
		npcinfo * pTarget = g_pNPCThreadManager->GetNPC(targetindex);
		if ( pTarget )
		{
			nMaxHP = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vIndex];

			pTarget->setdamage(nMaxHP, userindex, 0);
		}
	}

}
#endif	// _ADD_SKILL_OPTIONS

// 0109 kmj insert
//���� �������� ������ ��ų
void CSkill::directdamageeffect(int skillcode, int slvl, int targetindex, int vindex, int userindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vindex< 0 || vindex >= VIDNUM)
	{
		RPTFONE("vindex",vindex);
		return;
	}

	int ddamageprop = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	int ddamagemax = 0;				//���ܵ��������
	int ddamagemin = 0;				//���ܵ���С����
	int nAntiDefensePercent = 0;	// ���� ���� %��

	for(int j = vindex; j < VIDNUM; j++)
	{
		if(m_Skilllist[skillcode].m_nVid[j] == svdamagemax)
		{
			if ( skillcode == 1043) {		//gqTest: ������Թ���ܵ��˺�    1043ֱ���˺�  2000-5000			1047�����˺� 596-801
				ddamagemax = 5582;
			}
			else if (skillcode == 1047) { //1047 ��Թ���ܵ�����Ч��
				ddamagemax = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j] / 2;
			}
			else {
				ddamagemax = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j];
			}
		}

		if(m_Skilllist[skillcode].m_nVid[j] == svdamagemin)
		{
			if ( skillcode == 1043) {
				ddamagemin = 2252;
			}
			else if (skillcode == 1047) {
				ddamagemin = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j] / 2;
			}
			else {
				ddamagemin = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j];
			}
		}

		if(m_Skilllist[skillcode].m_nVid[j] == svdisregarddefense)
		{
			nAntiDefensePercent = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j];
		}
	}

	int ddamage = -1;							//���� �������� ���Ѵ�. 
	if(ddamagemin ==0)
	{
		ddamage = ddamagemax;
	}
	else
	{
		int range = ddamagemax - ddamagemin;
		int result =0;
		if(range!=0)
		{
			result = rand()%range;
		}
		result = (range>=0) ? result : -result;
		ddamage = ddamagemin + result;
	}

	userinfo *pUser = g_UserList->GetUser(userindex);
	if(pUser)
	{
		if(pUser->m_nViewMode > 0)
		{
			char buf[100];
			sprintf(buf,"Skill Direct Damage : Min(%d) Max(%d) ", pUser->getCalDamage(ddamagemin, targetindex), pUser->getCalDamage(ddamagemax, targetindex) );
			pUser->sendmsg(buf);
		}
	}

	if(userindex >= 0 && userindex < MAX_USER)
	{
		if ( pUser )
		{
			// 20170317 �߰�(���ٿ�:��ų ������ ��� �ɼ� ����)
			short sOpt = pUser->GetBonus2ndSkillDamage( skillcode );
			if ( sOpt != 0 )
			{
				ddamage = ddamage + ( ddamage * sOpt * 0.01f ); 
			}
		}
		directdamageeffect_user(ddamage, targetindex, ddamageprop, userindex, nAntiDefensePercent);
	}
	else if(userindex >= MAX_USER && userindex < MAX_USER+MAX_SUMMON_NPC)
	{
		directdamageeffect_summon(ddamage, targetindex, ddamageprop, userindex, nAntiDefensePercent);
	}
	else if(userindex<0 && userindex>-MAX_NPC)
	{
		directdamageeffect_npc(ddamage, targetindex, ddamageprop, userindex, nAntiDefensePercent);	
	}
	else if(userindex == -MAX_NPC)
	{
		directdamageeffect_object(ddamage,targetindex,ddamageprop, nAntiDefensePercent);
	}
}

void CSkill::directdamageeffect_npc(int ddamage, int targetindex, int ddamageprop, int userindex, int _nDisregardDef/* = 0*/)
{
	int nDisregardDef = _nDisregardDef;

	npcinfo* ninfo = g_pNPCThreadManager->GetNPC(userindex);

	if(ninfo)
	{
		ddamage = ninfo->getCalDamage(ddamage);
		nDisregardDef = nDisregardDef + ninfo->GetDisregardDefense();
	}

	float finalDamage = 0;

	// Ÿ���� ���ǽ� 
	if(targetindex < 0)
	{
		npcinfo* ni = g_pNPCThreadManager->GetNPC(targetindex);
		int critic = 1;
		if(ni)
		{
			if(ddamage>0)
			{
				ni->setDirectDamage(ddamage,ddamageprop,userindex,-1,nDisregardDef);
			}
			else
			{
				ni->setdamage(ddamage,userindex,0);
			}
		}
	}
	// Ÿ���� ����
	else if(targetindex >=0 && targetindex < MAX_USER)
	{
		userinfo* ui = g_UserList->GetUser(targetindex);
		if(ui)
		{
			if(ddamage>0)
			{
				ui->setDirectDamage(ddamage,ddamageprop,userindex,0.2f,nDisregardDef);
			}
			else
			{
				ui->setdamage(ddamage,0);
			}
		}
	}
	// Ÿ���� ��ȯ�� 
	else
	{
		snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
		if(si)
		{
			if(ddamage>0)
			{
				si->setDirectDamage(ddamage,ddamageprop,0,nDisregardDef);
			}
			else
			{
				si->setdamage(ddamage,0);
			}
		}
	}
}

void CSkill::directdamageeffect_user(int ddamage, int targetindex, int ddamageprop, int userindex, int _nDisregardDef/* = 0*/)
{
	userinfo* uinfo = g_UserList->GetUser(userindex);
	int critical_weight = 0;
	//���ӹ�����Ч���㷽ʽ
	if(uinfo)
	{
		int nDisregardDef = _nDisregardDef + uinfo->GetDisregardDefense();

		__int64 nDamage = uinfo->getCalDamage(ddamage, targetindex);
		// Target�� NPC�� �ƴϸ�, INT_MAX ���� �Ѿ�� damage�� INT_MAX ������ �����Ѵ�.
		if(targetindex >= 0)
		{
			if ( nDamage > INT_MAX )
			{
				ddamage = INT_MAX;
			}
			else
			{
				ddamage = (int)nDamage;
			}
		}

		if(targetindex < 0)
		{
			npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
			if(ninfo)
			{
				nDamage = (__int64)uinfo->getMasterWeight((float)nDamage, ninfo->getGrade());
				ninfo->setDirectDamage(nDamage,ddamageprop,userindex, -1, nDisregardDef);
				uinfo->noticeattack((__int64)ddamage, critical_weight, targetindex);
			}
		}
		else if(targetindex >=0 && targetindex < MAX_USER)
		{
			userinfo* ui = g_UserList->GetUser(targetindex);

			//gqCode: ���Ӽ��ܵĹ�����Ч
			float targetdodge = 0;
			float att_prob = 0;
			BOOL bMultiDamage = FALSE;
			int tcritic = (int)uinfo->getCritic();
			float attrate = (float)ui->getAttRatePhy() * ((float)1 + ui->getSkillAttRate() * 0.01f);
			if (!ui){
				return;	
			}

			float targetdefrate = (float)ui->getDefRate();
			targetdodge = ui->getDodge();
			if (targetdefrate){
				float attrate2 = attrate * attrate;
				att_prob = attrate2 / (attrate2 + targetdefrate * targetdefrate) * 100;
			}
			if (tcritic > 20) tcritic = 20;
				

			float minus_mhp = 0;
			if (att_prob < 10) att_prob = 10;
			if (att_prob > 95) att_prob = 95;

			int randNum = rand() % 100;
			if (ddamage > 0) {
				if (randNum > targetdodge) {
					randNum = rand() % 100;
					if (randNum < (int)att_prob)
					{
						ui->setDirectDamage(ddamage, ddamageprop, userindex, uinfo->getpvpr(2), nDisregardDef);
						critical_weight = 1;
					}
					else {
						ddamage = 0;
						critical_weight = 0;
					}
				}
				else {
					ddamage = 0;
					critical_weight = 0;
				}
				uinfo->noticeattack((__int64)ddamage, critical_weight, targetindex);
			}
			else {
				ui->setdamage(ddamage, 0);
			}
		}
		else
		{
			snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
			if(si)
			{
				if(ddamage>0)
				{
					si->setDirectDamage(ddamage,ddamageprop,userindex, nDisregardDef);
				}
				else
				{
					si->setdamage(ddamage,0);
				}
			}
		}
	}
}

void CSkill::directdamageeffect_summon(int ddamage, int targetindex, int ddamageprop, int userindex, int _nDisregardDef/* = 0*/)
{
	snpcinfo* sinfo = g_pSummonNPCThreadManager->GetSummon(userindex);

	int nDisregardDef = _nDisregardDef;

	// 0203 ����
	int master_index = -1;
	if(sinfo)
	{
		ddamage = sinfo->getCalDamage(ddamage);
		master_index = sinfo->GetMasterIndex();

		nDisregardDef = nDisregardDef + sinfo->GetDisregardDefense();
	}

	float finalDamage = 0;
	if(targetindex < 0)
	{
		npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
		if(ninfo)
		{
			ninfo->setDirectDamage(ddamage,ddamageprop,userindex,master_index, nDisregardDef);
		}
	}
	else if(targetindex >= 0 && targetindex < MAX_USER)
	{
		userinfo* ui = g_UserList->GetUser(targetindex);
		if( sinfo && targetindex != sinfo->GetMasterIndex())
		{
			if(ui)
			{
				ddamage = 0;  // 0124 insert 
				if(ddamage>0)
				{
					ui->setDirectDamage(ddamage,ddamageprop,userindex,0.2f, nDisregardDef);
				}
				else
				{
					ui->setdamage(ddamage,0);
				}
			}
		}
	}
	else
	{
		snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
		if(si)
		{
			if(ddamage>0)
			{
				si->setDirectDamage(ddamage,ddamageprop,userindex, nDisregardDef);
			}
			else
			{
				si->setdamage(ddamage,0);
			}
		}
	}
}


void CSkill::directdamageeffect_object(int ddamage, int targetindex, int ddamageprop, int _nDisregardDef/* = 0*/)
{

	float finalDamage = 0;
	if(targetindex < 0)
	{
		npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
		if(ninfo)
		{
			ninfo->setDirectDamage(ddamage,ddamageprop,-MAX_NPC);
		}
	}
	else if(targetindex >= 0 && targetindex < MAX_USER)
	{
		userinfo* ui = g_UserList->GetUser(targetindex);
		if(ui)
		{
			if(ddamage > 0)
			{
				ui->setDirectDamage(ddamage,ddamageprop,-MAX_NPC,0.2f);
			}
			else
			{
				ui->setdamage(ddamage,0);
			}
		}
	}
	else
	{
		snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
		if(si)
		{
			if(ddamage > 0)
			{
				si->setDirectDamage(ddamage,ddamageprop,-MAX_NPC);
			}
			else
			{
				si->setdamage(ddamage,0);
			}
		}
	}
}


// 0116 kmj insert
//�Ϲ� ���ݿ� �߰����� �ۿ��� �ؼ� ������ �ϴ� ��ų
bool CSkill::additionaldamageeffect(int skillcode, int slvl, int targetindex, int vindex, int userindex)
{
	bool attsuccess = false;
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return false;
	}

	if(slvl < 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return false;
	}

	if(vindex < 0 || vindex >= VIDNUM)
	{
		RPTFONE("vindex",vindex);
		return false;
	}

	int ddamageprop = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	__int64 ddamage = -1;
	// ���� ���� %��
	int nAntiDefensePercent = 0;

	for(int j = vindex; j < VIDNUM; j++)
	{
		if(m_Skilllist[skillcode].m_nVid[j] == svdisregarddefense)
		{
			nAntiDefensePercent = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j];
			break;
		}
	}

	userinfo* uinfo = NULL;
	snpcinfo * si = NULL;
	if(userindex >= 0 && userindex < MAX_USER)
	{
		uinfo = g_UserList->GetUser(userindex);

		if(uinfo)
		{
			int critic;
			ddamage = uinfo->skillAttack(skillcode,slvl,targetindex,&critic);

			nAntiDefensePercent = nAntiDefensePercent + uinfo->GetDisregardDefense();

			// 20170317 �߰�(���ٿ�:��ų ������ ��� �ɼ� ����)
			short sOpt = uinfo->GetBonus2ndSkillDamage( skillcode );
			if ( sOpt != 0 )
			{
				ddamage = ddamage + ( ddamage * sOpt * 0.01f ); 
			}

			attsuccess = (ddamage > 0 );
			int k = 1;
			if(targetindex < 0)
			{
				npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
				if(ninfo)
				{
					if(attsuccess)
					{
						ddamage = (__int64)ninfo->setAdditionalDamage(ddamage,ddamageprop,userindex, nAntiDefensePercent);
					}
					else
					{
						ddamage = 0;
						ninfo->setdamage(0,userindex,0);
					}
				}
			}
			else
			{
				if(attsuccess)
				{
					userinfo* ui = g_UserList->GetUser(targetindex);
					if(ui)
					{
						ddamage = (int)ui->setAdditionalDamage(ddamage,ddamageprop,userindex,uinfo->getpvpr(1), nAntiDefensePercent);
					}
				}
			}
			uinfo->stealhpnmp((float)ddamage);
			uinfo->clearAttackSkill();
		}
		else
		{
			_RPTF1(_CRT_WARN,"userindex - %d\n",userindex);
		}
	}
	else if(userindex < MAX_USER+MAX_SUMMON_NPC && userindex>=MAX_USER)
	{
		si = g_pSummonNPCThreadManager->GetSummon(userindex);

		if(si)
		{
			int critic;

			ddamage = si->skillAttack(skillcode,slvl,targetindex,&critic);

			attsuccess = (ddamage > 0 );

			nAntiDefensePercent = nAntiDefensePercent + si->GetDisregardDefense();

			int k = 1;
			if(targetindex < 0)
			{
				npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
				if(ninfo)
				{
					if(attsuccess)
					{
						ninfo->setAdditionalDamage(ddamage,ddamageprop,userindex, nAntiDefensePercent);
					}
					else
					{
						ninfo->setdamage(0,userindex,0);
					}
				}
			}
			else
			{
				if(attsuccess)
				{
					if(targetindex < MAX_USER)
					{
						userinfo* ui = g_UserList->GetUser(targetindex);
						if(ui)
						{
							ui->setAdditionalDamage(ddamage,ddamageprop,userindex,0.5f, nAntiDefensePercent);
						}
					}
					else if(targetindex < MAX_USER+MAX_SUMMON_NPC)
					{
						snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
						if(si)
						{
							si->setAdditionalDamage(ddamage,ddamageprop,userindex, nAntiDefensePercent);
						}
					}
				}
			}
		}
		else
		{
			_RPTF1(_CRT_WARN,"sindex - %d\n", userindex);
		}
	}
	else if(userindex < 0 && userindex > -MAX_NPC)
	{
		npcinfo* ni;
		ni = g_pNPCThreadManager->GetNPC( userindex );
		if(ni)
		{
			int critic;

			ddamage = ni->skillAttack(skillcode,slvl,targetindex,&critic);

			attsuccess = (ddamage > 0 );

			nAntiDefensePercent = nAntiDefensePercent + ni->GetDisregardDefense();

			int k = 1;

			// �´� ����� ����..
			if( targetindex >= 0 && targetindex < MAX_USER )
			{
				uinfo = g_UserList->GetUser( targetindex );
				if(uinfo)
				{
					if(attsuccess)
					{
						uinfo->setAdditionalDamage(ddamage,ddamageprop,userindex,0.5f, nAntiDefensePercent);
					}
				}
			}
			else
			{
				if(attsuccess)
				{
					if(targetindex >= MAX_USER && targetindex < MAX_USER+MAX_SUMMON_NPC)
					{
						si = g_pSummonNPCThreadManager->GetSummon(userindex);
						if(si)
						{
							si->setAdditionalDamage(ddamage,ddamageprop,userindex, nAntiDefensePercent);
						}
					}
					// NPC
					else if(targetindex < 0)
					{
						ni = g_pNPCThreadManager->GetNPC( targetindex );
						if(ni)
						{
							ni->setAdditionalDamage(ddamage,ddamageprop,userindex, nAntiDefensePercent);
						}
					}
				}
			}
		}
		else
		{
			_RPTF1(_CRT_WARN,"index - %d\n", userindex);
		}

	}
	return attsuccess;
}


//���¸� ��ȭ��Ű�� ��ų.
void CSkill::durationeffect(int skillcode, int slvl, int targetindex, int vindex,bool attsuccess,int uindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl < 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vindex < 0 || vindex >= VIDNUM)
	{
		RPTFONE("vindex",vindex);
		return;
	}	

	//���� ���ۿ�Ʈ��ĸ�� �ϵ��ڵ�
	if(skillcode == 36 && uindex != targetindex)
	{	//�����ǵ��϶� �ڽŸ� ��������
		return;
	}

	int duration = 0;

	for(int j = 0; j < VIDNUM; j++)
	{
		switch(m_Skilllist[skillcode].m_nVid[j])
		{
		case svduration:
			duration = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[j];
			break;
		case svadditionaldamage:
			if(!attsuccess)
			{
				return;
			}
			break;
		default:
			break;
		}

	}
	
	int att = m_Skilllist[skillcode].m_nAtt;
	if(att & sahostile)
	{
		if(targetindex >= 0)
		{
			// 20100702 ����(�̼���:svduration ���ӽð� ���� ��, ������ ��ų�̰� �������� ��� �� ��� DB�� ������ ���� 4/10��ŭ �ð��� �����)
			// ������ ��ų �������� ��� �� DB�� ������ ������ �۰� ������
			duration = (int)(duration * 0.4);
		}
	}

	if(duration > 0)
	{
		int state =m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
		//// 20140611 ����(���ٿ�:state ���� MAX ������ Ŭ ��, MAX ��ġ ���� ���� �����Ѵ�. MAX �� �ϵ��ڵ�, define ������ ����)
		//if(state >= MAX_ATTRIBUTE_NUM)
		//{
		//	state = MAX_ATTRIBUTE_NUM - 2;
		//}
		//if(state >= 64)
		//{
		//	state = 62;
		//}
		if(state >= MAX_ATTRIBUTE_NUM)
		{
			return;
		}

		if(targetindex >= 0 && targetindex < MAX_USER)
		{
			userinfo* uinfo = g_UserList->GetUser(targetindex);
			if(uinfo)
			{
				uinfo->setDurationSkill(skillcode,slvl,duration,state,vindex,uindex);
			}
		}
		else if(targetindex < 0)
		{
			npcinfo* ninfo = g_pNPCThreadManager->GetNPC(targetindex);
			if(ninfo)
			{
				ninfo->setDurationSkill(skillcode,slvl,duration,state,vindex);
			}
		}
	}
}

//�׿� ��ų��..
void CSkill::extraeffect(int skillcode, int slvl, int targetindex, int vindex, int userindex,Point pt)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vindex< 0 || vindex >= VIDNUM)
	{
		RPTFONE("vindex",vindex);
		return;
	}

	int code = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	switch(code)
	{
	case 1:			//teleport
		if(pt.y == -1)
		{
			if(userindex >= 0)
			{
				userinfo* uinfo = g_UserList->GetUser(userindex);
				if(uinfo)
				{
					if(targetindex >= 0 && targetindex < MAX_USER)
					{
						int zone = g_UserList->getZone(targetindex);
						if(zone == g_UserList->getZone(userindex))
						{
							Point cpt = g_UserList->getCurrentPoint(targetindex);
							cpt.z = uinfo->getCurrentPoint().z;
							uinfo->setCurrentPoint(cpt);

							g_Ground->Teleport(userindex,cpt,(short)zone,isteleport);
						}
						
						else
						{
							// 20061129 �߰�(�̼���:��ų ����Ʈ ��� �� ��� ������ �ٸ������� �̵����� �� ĳ���� ������� �� ����)
							
							// ��  �� : 2007-08-21 
							// ������ : ����ȣ
							// Ư�� ���� ��ų�� TARGET ����ڿ��� ���� �̵� �Ͽ� ���� �ҽ�.
							// TARGET ����ڰ� �ٸ� ������ �̵� �Ѵٸ�, �����ڴ� TARGET ������� �� ������ ���� ����.
							// ��ų�� ���� �� �ȿ��� ���� �Ǿ�� �ϹǷ� TARGET ������� �� ID �� ���� �ȴ� �ϴ���.
							// ������ ���Դ� ������ ���� �ʾƾ� �Ѵ�.

							// ���� ZONE ������ �������� ZONE ������ ���� ��Ų��.

							zone = g_UserList->getZone(userindex);
							Point cpt = g_UserList->getCurrentPoint(userindex);

							//cpt.z = uinfo->getCurrentPoint().z;
							//uinfo->setCurrentPoint(cpt);

							g_Ground->Teleport(userindex,cpt,(short)zone,isteleport);
						}
					}
					else if(targetindex<0)
					{
						Point cpt = g_pNPCThreadManager->getCurrentPoint(targetindex);
						cpt.z = uinfo->getCurrentPoint().z;
						uinfo->setCurrentPoint(cpt);
						int zone = g_pNPCThreadManager->getZone(targetindex);
						if(zone == g_UserList->getZone(userindex))
							g_Ground->Teleport(userindex,cpt,(short)zone,isteleport);
					}
					else
					{
						snpcinfo* si = g_pSummonNPCThreadManager->GetSummon(targetindex);
						if(si)
						{
							Point cpt = si->getCurrentPoint();
							cpt.z = uinfo->getCurrentPoint().z;
							uinfo->setCurrentPoint(cpt);
							int zone = si->getZone();
							if(zone == g_UserList->getZone(userindex))
							{
								g_Ground->Teleport(userindex,cpt,(short)zone,isteleport);
							}
						}
					}
				}
			}
		}
		else
		{
			if(userindex>=0)
			{
				userinfo* uinfo = g_UserList->GetUser(userindex);
				if(uinfo)
				{
					uinfo->setCurrentPoint(pt);
					g_Ground->Teleport(userindex,pt,(short)g_UserList->getZone(userindex),isteleport);
				}
			}
		}
		break;
	case 2:
	/**********************************************************************/
	//winpro insert
	{
		npcinfo	*pOrder;
		npcinfo *pTarget;
		int		distance;

		pOrder = g_pNPCThreadManager->GetNPC(userindex);
		pTarget = g_pNPCThreadManager->GetNPC(targetindex);
		
		if(pOrder && pTarget)
		{
			if(!pTarget->isdead())
			{
				break;
			}

			distance = getdistance2(pOrder->getCurrentPoint(), pTarget->getCurrentPoint());

			if ( distance < DEFAULT_BODY_RANGE2 )
			{
				break;
			}

			pTarget->SetNpcRegen();
		}
	}
	/**********************************************************************/
		break;
	case 3:	//cure
		if(targetindex>=0 && targetindex<MAX_USER)
		{
			userinfo* ui = g_UserList->GetUser(targetindex);
			if(ui)
			{
				ui->Cure();
			}
		}
		break;
#ifdef _ADD_SKILL_OPTIONS
	// 20140617 �߰�(���ٿ�:����� �ڽ��� ��ġ�� �ٲ۴�.)
	case 4:
		{
			SwapPosition(userindex, targetindex);
		}
		break;
	// 20140702 �߰�(���ٿ�:����. ���� PC/NPC�� �� ���� ������)
	case 5:
		{
			Inhale( userindex, targetindex, pt );
		}
		break;
#endif	//_ADD_SKILL_OPTIONS
	default:
		break;
	}
}

void CSkill::killingeffect(int skillcode, int slvl, int targetindex, int vindex, int userindex)
{
	if(skillcode < 0 || skillcode >= MAX_SKILL_CODE)
	{
		RPTFONE("skillcode",skillcode);
		return;
	}

	if(slvl< 0 || slvl >= MAX_SLVL)
	{
		RPTFONE("slvl",slvl);
		return;
	}

	if(vindex< 0 || vindex >= VIDNUM)
	{
		RPTFONE("vindex",vindex);
		return;
	}

	int prob = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	
	int step1 = brand() % 100;
	if(step1 < prob)
	{
		if(targetindex >= 0)
		{
		}
		else
		{
			npcinfo* ni = g_pNPCThreadManager->GetNPC(targetindex);
			if(ni)
			{
				if(ni->getGrade()<8 && ni->getGrade() != 5)
				{
					int hp = ni->getHpCur();
					ni->setdamage(hp+1,userindex,0);
				}
			}
		}
	}
}

void CSkill::summonningeffect(int skillcode, int slvl,int vindex, int userindex, Point pt)
{
	int s_cd = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];

	int maxslvl=0,duration=0, summondelay = 0;
	for(int i = 0;i<VIDNUM;i++)
	{
		if(m_Skilllist[skillcode].m_nVid[i] == svduration)
		{
			duration = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[i];
		}

		if(m_Skilllist[skillcode].m_nVid[i] == svsummonmaxslvl)
		{
			maxslvl = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[i];
		}

		if(m_Skilllist[skillcode].m_nVid[i] == svsummondelay)
		{
			summondelay = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[i];
		}
	}

	int nValue = 1;
	g_pSummonNPCThreadManager->CheckEqualSummoner(userindex, s_cd);

	if(GetValueByVid(skillcode, slvl, 0 , svsummoncount, &nValue, NULL))
	{
		while(nValue--)
		{
			pt.x = pt.x + random( 15 );
			pt.y = pt.y + random( 15 );
			g_pSummonNPCThreadManager->AddSummonNPC(userindex,s_cd,m_Skilllist[skillcode].m_nVid,m_Skilllist[skillcode].m_Slvl[slvl].m_nValue,maxslvl,duration, summondelay, pt);
		}
	}
	else
	{
		g_pSummonNPCThreadManager->AddSummonNPC(userindex,s_cd,m_Skilllist[skillcode].m_nVid,m_Skilllist[skillcode].m_Slvl[slvl].m_nValue,maxslvl,duration, summondelay, pt);
	}
}

void CSkill::polymorphingeffect(int skillcode,int slvl,int targetindex,int vindex, int userindex)
{
	int ncode = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	NPCProto* np = g_pNPCThreadManager->getPrototype(ncode);
	if(np)
	{
		int duration = 0;
		for(int i = 0;i<VIDNUM;i++)
		{
			if(m_Skilllist[skillcode].m_nVid[i] == svduration)
			{
				duration = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[i];
			}
		}

		if(targetindex>=0 && targetindex <MAX_USER)
		{
			userinfo* ui = g_UserList->GetUser(targetindex);
			if(ui)
			{
				ui->PolyMorph2NPC(np,duration);
			}
		}
	}
}

void CSkill::changeeffect(int skillcode,int slvl,int userindex,int vindex)
{
	int ncode = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[vindex];
	NPCProto* np = g_pNPCThreadManager->getPrototype(ncode);
	if(np)
	{
		int duration = 0;
		for(int i = 0;i<VIDNUM;i++)
		{
			if(m_Skilllist[skillcode].m_nVid[i] == svduration)
			{
				duration = m_Skilllist[skillcode].m_Slvl[slvl].m_nValue[i];
			}
		}

		if(userindex>=0 && userindex <MAX_USER)
		{
			userinfo* ui = g_UserList->GetUser(userindex);
			if(ui)
			{
				ui->change(ncode, duration);
			}
		}
	}
}

void CSkill::useskillonetarget()
{

}

void CSkill::useskillself()
{

}

bool CSkill::useskillarea(int skillcode, Point target, int slvl,int userindex)
{
	if(skillcode>=0 && skillcode <MAX_SKILL_CODE)
	{
		PROFILER_SCOPE_TIMER(CSkill_useskillarea)
		int arearange = g_Skill.m_Skilllist[skillcode].m_Slvl[slvl].m_sArearange;
		if(arearange < 0)
		{				//�ݰ� ���� ��ġ�� ã�� ����.. ����..
			return false;
		}
		else if(arearange == 0)
		{			//�ݰ��� 0�϶��� ���� ��ǥ�� �ش�
			if(target.y < 0)
			{		//assertion check..
				skilleffect(skillcode, slvl, target.x,userindex,0,0,Point(0,0));
			}
			else
			{
				return false;
			}
		}
		else
		{
			Point t;					//�ݰ��� �߽��� �� ���� ���Ѵ�.
			if(target.y < 0)
			{			//character�� ��� ��ų�� ����� ���
				if(target.x < 0)
				{			//npc�� ��� ��ų�� ����� ���
					npcinfo* ninfo = g_pNPCThreadManager->GetNPC(target.x);
					if(ninfo)
					{
						t = ninfo->getCurrentPoint();
					}
					else
					{
						return false;
					}
				}
				else
				{						//pc�� ��� ��ų�� ����� ���
					userinfo* ui = g_UserList->GetUser(target.x);
					if(ui)
					{
						t = ui->getCurrentPoint();
					}
					else
					{
						return false;
					}
				}
			}
			else
			{						//�ٴڿ� ��� ��ų�� ����� ���
				t = target;
			}
			//ground�� �Ѱ��־���Ұʹ�.. - �����߽�, �ݰ�, zone,skillcode, slvl
		}
		return true;
	}
	return false;
}

void CSkill::useskillparty()
{

}

#ifdef _ADD_SKILL_OPTIONS
void CSkill::linkskill(int skillcode, int slvl,int vindex, int userindex, Point pt, char pk, int _nTargetIndex )
#else // _ADD_SKILL_OPTIONS
void CSkill::linkskill(int skillcode, int slvl,int vindex, int userindex, Point pt, char pk)
#endif // _ADD_SKILL_OPTIONS
{
	char area = 0;
	bool done = false;
	int	nValue = 0;
	short linkSkillID = 0;
	short linkSkillLevel = 0;
	Point linkTarget = Point();
#ifdef _INFINITE
	char chType = 0;
#endif

	if(!GetValueByVid(skillcode, slvl, vindex, svlinkskill, &nValue, NULL))
	{
		return;
	}

	linkSkillID = (short)nValue;
	area = g_Skill.m_Skilllist[linkSkillID].m_nAreatype;

	if(!GetValueByVid(skillcode, slvl, vindex + 1, svlinkslevel, &nValue, NULL))
	{
		return;
	}

	linkSkillLevel = (short)nValue;

#ifdef _ADD_SKILL_OPTIONS
	int nTargetIndex = _nTargetIndex;
	char chTagetType = g_Skill.m_Skilllist[linkSkillID].m_chTarget;
#endif

	if(pt.y == -1)	//Index �ϰ�� 
	{
		if(pt.x >= 0)	//User
		{
			userinfo *pUser = NULL;
			pUser = g_UserList->GetUser(pt.x);
			if(pUser)
			{
				linkTarget = pUser->getCurrentPoint();

#ifdef _ADD_SKILL_OPTIONS
				nTargetIndex = pt.x;
#endif
			}
		}
		else
		{
			npcinfo *pNpc;
			pNpc = g_pNPCThreadManager->GetNPC(pt.x);
			
			if(pNpc)
			{
				linkTarget = pNpc->getCurrentPoint();

#ifdef _ADD_SKILL_OPTIONS
				nTargetIndex = pt.x;
#endif
			}

			linkTarget.z = pt.z;
		}
	}
	else
	{
#ifdef _ADD_SKILL_OPTIONS
		if ( chTagetType == stonetarget )
		{
			nTargetIndex = _nTargetIndex;
		}
		else if ( chTagetType == stself )
		{
			nTargetIndex = userindex;
		}
#endif
		linkTarget = pt;
	}

	XPOINT ppt;

	ppt.x = linkTarget.x;
	ppt.y = linkTarget.y;
	ppt.z = linkTarget.z;

#ifdef _INFINITE
	chType = g_Skill.m_Skilllist[linkSkillID].m_chType;
	if ( IsUser(userindex) && chType == 13 )
	{
		userinfo *pUser = NULL;
		pUser = g_UserList->GetUser(userindex);
		if( pUser )
		{
			pUser->skillaction( linkSkillID, linkTarget, pk, linkSkillLevel );
			return;
		}
	}
#endif	// #ifdef _INFINITE

	switch(area)
	{			//area range�� 0 �̸� single target
	case 0:
	case 1:	
		{
			ShowEffectUser(linkSkillID, linkSkillLevel, userindex, ppt);
#ifdef _ADD_SKILL_OPTIONS
			g_Skill.skilleffect(linkSkillID, linkSkillLevel, nTargetIndex,userindex,pk,0, Point(0,0));
#else
			g_Skill.skilleffect(linkSkillID, linkSkillLevel, pt.x,userindex,pk,0, Point(0,0));
#endif
		}
		break;

	default:
		ShowEffectUser(linkSkillID, linkSkillLevel, userindex, ppt);
		g_Ground->UseSkill(linkSkillID,linkTarget, area, linkSkillLevel,userindex,(char)pk);
		break;
	}
}

bool CSkill::saveskill(char *fname)		
{
	char Header[25] = "Lizard Skill v1.00";
	DWORD dwTemp;
	bool chk;

	if ( !m_Skilllist )
	{
		return false;
	}

	Header[24] = 26;
	HANDLE hFile = CreateFile(fname, GENERIC_WRITE,NULL,NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if ( hFile )
	{
		WriteFile(hFile, Header, 25, &dwTemp, NULL);
		WriteFile(hFile, &m_nMaxskill, sizeof(int), &dwTemp,NULL);
		if( m_nMaxskill > 0 )
		{
			if ( m_Skilllist )
			{
				WriteFile(hFile, m_Skilllist, sizeof(CSSkill)*m_nMaxskill, &dwTemp, NULL);
				if ( dwTemp == sizeof(CSSkill)*m_nMaxskill )
				{
					chk = true;
				}
				else
				{
					chk = false;
				}
			}
			else
			{
				chk = false;
			}
		}
		else
		{
			chk = false;
		}

		CloseHandle(hFile);
		return chk;
	}
	else
	{
		return false;
	}
}

void CSkill::LoadSkill()
{
	HANDLE hRFile = CreateFile("data/Skill.dat", GENERIC_READ, NULL,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if ( hRFile == INVALID_HANDLE_VALUE )
	{
		_RPTF0(_CRT_WARN,"file loading error!!\n");
	}
	else
	{
		_RPTF0(_CRT_WARN, "Load Data - Skill.dat  \n");
		ZeroMemory(m_Skilllist, sizeof(m_Skilllist));

		DWORD dwTemp;
		ReadFile(hRFile, &m_nMaxskill, sizeof(m_nMaxskill), &dwTemp, NULL);
		ReadFile(hRFile, m_Skilllist, sizeof(m_Skilllist), &dwTemp,NULL);

		char tale[200];
		ZeroMemory(tale,200);
		ReadFile(hRFile,tale,200,&dwTemp,NULL);

		CloseHandle(hRFile);

		_RPTF0(_CRT_WARN, "Load Data - Skill.dat END \n");
	}
}

void CSkill::LoadOSkill()
{
	if(!m_tblOptionSkill.Open("data\\oskill.dat"))
	{
		return;
	}

	//UJ 110712, �ӵ��� ���� CSimpleDataList�� ����ϴ°ͺ��� CAtlMap�� ����ϴ� ���� 240�谡�� ������
	ATL::CAtlMap<DWORD, SOptionLevel*>::CPair *pAtlItem;
	int optionSkillCount = 0;
	{
		STATE state;
		SOptionLevel *pOption;
		state = m_tblOptionSkill.GetFirstItem();
		while(pOption = (SOptionLevel *)m_tblOptionSkill.GetNextItem(state))
			optionSkillCount++;
	}
	m_atlMapOptionSkill.InitHashTable(optionSkillCount);

	DWORD optionSkillIndex = 0;
	{
		STATE state;
		SOptionLevel *pOption;
		state = m_tblOptionSkill.GetFirstItem();
		while(pOption = (SOptionLevel *)m_tblOptionSkill.GetNextItem(state))
		{
			//UJ 110712, �ӵ��� ���� �ε����� DWORD������ ��ģ��
			optionSkillIndex = ((unsigned char)pOption->slvl) << 16 | (pOption->skillid & 65535);

			//UJ 110712, �ߺ��� �ɼǵ����Ͱ� �־ �����ϰ� �Ѿ��
			pAtlItem = m_atlMapOptionSkill.Lookup(optionSkillIndex);
			if (pAtlItem)
				continue;
			m_atlMapOptionSkill.SetAt(optionSkillIndex, pOption);
		}
	}
	m_atlMapOptionSkill.AssertValid();
}

SOptionLevel* CSkill::FindOptionSkillInfo(short sid, short slvl)
{
	PROFILER_SCOPE_TIMER(CSkill_FindOptionSkillInfo)
	//UJ 110712, �ӵ��� ���� CSimpleDataList�� ����ϴ°ͺ��� CAtlMap�� ����ϴ� ���� 240�谡�� ������ --start
	/*
	STATE	state;
	SOptionLevel	*pOption;
	state = m_tblOptionSkill.GetFirstItem();	

	while(pOption = (SOptionLevel *)m_tblOptionSkill.GetNextItem(state))
	{
		if(pOption->skillid != sid)
		{
			continue;
		}

		if(pOption->slvl != slvl)
		{
			continue;
		}

		return pOption;
	}

	return NULL;
	*/
	DWORD optionSkillIndex = (slvl << 16) | (sid & 65535); // 65535 MAX_UNSIGNED_SHORT FFFF
	ATL::CAtlMap<DWORD, SOptionLevel*>::CPair *pAtlItem;
	pAtlItem = m_atlMapOptionSkill.Lookup(optionSkillIndex);
	if (pAtlItem)
		return pAtlItem->m_value;
	return NULL;
	//UJ --end
}

/*****************************************************************************************
��ų ������ �����Լ� �߰�.
��ų ������ ���� �����ϰ� �����ϱ� ���� �����Ͽ���.
GetValuebyParam : �ش� ��ųState�� �˻��Ͽ� Value���� ���Ѵ�.
GetClassAtSkill : ��ų�� ���� ������ ���Ѵ�. (������ �����)
IsHostility : �ش� ��ų�� ���������� �˻��Ѵ�.
*****************************************************************************************/
int CSkill::GetValuebyParam(int nSkill, int nLevel, int nState)
{
	BOOL	bFind;
	int		num;

	bFind = FALSE;	//�ش� ��ų�� ����Ǿ��ִ��� Ȯ���Ѵ�.
	for(num = 0; num < VIDNUM; num++)
	{
		if(m_Skilllist[nSkill].m_nVid[num] == nState)
		{
			bFind = TRUE;
			break;
		}
	}

	if(!bFind)
	{
		return 0;
	}

	return m_Skilllist[nSkill].m_Slvl[nLevel].m_nValue[num];
}

CSSkillLevel CSkill::GetSkillLevelData(int nSkill, int nLevel)
{
	return m_Skilllist[nSkill].m_Slvl[nLevel];
}

int CSkill::GetClassAtSkill(int nSkill)
{
	int	nValue;

	if(m_Skilllist[nSkill].m_nAtt & sahostile)
	{
		return nsForce;
	}

	nValue = GetValuebyParam(nSkill, 1, svdirectdamage);

	if(nValue > 0)
	{
		nValue = GetValuebyParam(nSkill, 1, svdamagemax);
		if(nValue > 0)
		{
			return nsForce;
		}
		else if(nValue < 0)
		{
			return nsHealing;
		}
	}

	nValue = GetValuebyParam(nSkill, 1, svadditionaldamage);
	
	if(nValue > 0)
	{
		return nsForce;
	}
	else if(nValue < 0)
	{
		return nsHealing;
	}

	nValue = GetValuebyParam(nSkill, 1, svsetstate);

	if(nValue > 0)
	{
		return nsSupport;
	}
	else if(nValue < 0)
	{
		return nsForce;
	}

	nValue = g_Skill.GetValuebyParam(nSkill, 1, svextra);
	switch(nValue)
	{
	case 2:
		return nsResurrection;
	}
	return 0;
}

BOOL CSkill::IsHostility(int nSkill)
{
	switch(GetClassAtSkill(nSkill))
	{
	case nsForce:
		return TRUE;
	}

	return FALSE;
}


BOOL CSkill::GetValueByVid(short sid, short slvl,
							int vindex, int vid, int *pValue, int *pVindex)
{
	int	num;
	int	nValue;

	for(num = vindex; num<VIDNUM; num++)
	{
		if(m_Skilllist[sid].m_nVid[num] != vid)
		{
			continue;
		}

		nValue = m_Skilllist[sid].m_Slvl[slvl].m_nValue[num];
		if(pValue)
		{
			*pValue = nValue;
		}

		if(pVindex)	
		{
			*pVindex = num;
		}

		return TRUE;
	}
	
	return FALSE;
}


//***************************************************************************************


void CSkill::summonnpceffect(int skillcode, int slvl, int userindex, int i, Point pt)
{
	bool done = false;
	int	nValue;
	int	nMax, nMin;
	Point	ptTarget;
	userinfo	*pUser;
	npcinfo		*pNPC;
	int		range;

	if(!GetValueByVid(skillcode, slvl, 0, svsummonnpc, &nValue, NULL))
	{
		return;
	}

	if(nValue == 0)
	{
		return;
	}

	BaseNPCInfo	npc;

	memset((LPVOID)&npc, 0, sizeof(npc));

	npc.m_ai = 1001;
	npc.m_aipattern = AI_FIRSTATTACKNEAR;
	npc.m_dangerhp = 10;
	npc.m_cd = nValue;
	npc.m_zone = 0;
	npc.m_npcreaction = 0;

	if(pt.y == -1)
	{
		if(pt.x > 0)
		{
			pUser = g_UserList->GetUser(pt.x);
			if(!pUser)
			{
				return;
			}
			ptTarget = pUser->getCurrentPoint();
			npc.m_zone = pUser->getZone();
		}
		else
		{
			pNPC = g_pNPCThreadManager->GetNPC(pt.x);
			if(!pNPC)
			{
				return;
			}
			ptTarget = pNPC->getCurrentPoint();
			npc.m_zone = pNPC->getZone();
		}
	}
	else
	{
		if(userindex > 0)
		{
			pUser = g_UserList->GetUser(userindex);
			if(!pUser)
			{
				return;
			}
			npc.m_zone= pUser->getZone();
		}
		else
		{
			pNPC = g_pNPCThreadManager->GetNPC(userindex);
			if(!pNPC)
			{
				return;
			}
			npc.m_zone = pNPC->getZone();
		}
		ptTarget = pt;
	}

	npc.m_point = ptTarget;
	npc.m_point.z = -2000;

	if(!GetValueByVid(skillcode, slvl, i, svcount, &nMin, NULL))
	{
		nMin = 1;	
	}

	if(!GetValueByVid(skillcode, slvl, i, svcount2, &nMax, NULL))
	{
		nMax = 1;	
	}

	range = m_Skilllist[skillcode].m_Slvl[slvl].m_sArearange;

	if(nMin < nMax)
	{
		DWORD num;
		num = (DWORD)brandlottery();
		nValue = ((DWORD)num % (nMax+1)) + nMin;
	}
	
	while(nValue--)
	{
		g_pNPCThreadManager->CreateNPC(&npc, TRUE, userindex); // <djelee> : <?> �� - ���� ����. 
	}
}

// 20061117 �߰�(�̼���:������ ��ų���� �ش� ��ų �ְ����� �������� �Լ�)
int CSkill::GetMaxSkillLevel(int nSkillID)
{
	//UJ 110712, ��ų�ִ� ������ �̸� ���簪�� ������ �Ѵ�(�ӵ����) --start
	return m_SkillMaxLevel[nSkillID];
	//PROFILER_SCOPE_TIMER(CSkill_GetMaxSkillLevel)
	//int nMaxLevel = 0;
	//for(nMaxLevel = 0; nMaxLevel < MAX_SLVL; nMaxLevel++)
	//{
	//	if(m_Skilllist[nSkillID].m_Slvl[nMaxLevel].m_chReqlvl == -1)
	//	{
	//		return nMaxLevel - 1;
	//	}
	//}
	//return nMaxLevel - 1;
	//UJ --end
}

#ifdef _ADD_SKILL_OPTIONS
// 20140618 �߰�(���ٿ�:Ÿ�ٰ� �ڽ��� ��ġ�� �¹ٲ۴�.)
void CSkill::SwapPosition( int _nUserIndex, int _nTargetIndex )
{
	// �ϴ� ������...
	if ( !IsUser(_nUserIndex) )
	{
		return;
	}

	userinfo * pUser = g_UserList->GetUser(_nUserIndex);
	if ( !pUser )
	{
		return;
	}

	if ( pUser->isdead() )
	{
		return;
	}

	short	sZone = pUser->getZone();
	char	cState = isteleport;

	Point	ptUserPos = pUser->getCurrentPoint();

	if ( IsUser(_nTargetIndex) )
	{
		userinfo * pTarget = g_UserList->GetUser(_nTargetIndex);
		if ( !pTarget )
		{
			return;
		}

		if ( pTarget->isdead() )
		{
			return;
		}

		if ( sZone != pTarget->getZone() )
		{
			return;
		}

		Point ptTargetPos = pTarget->getCurrentPoint();

		Point ptTemp = ptUserPos;

		ptUserPos = ptTargetPos;
		ptUserPos.z = ptTemp.z;
		ptTemp.z = ptTargetPos.z;
		ptTargetPos = ptTemp;

		pUser->setCurrentPoint(ptUserPos);

		pTarget->setCurrentPoint(ptTargetPos);

		g_Ground->OutInDirect( _nUserIndex, ptUserPos, sZone, cState );
		g_Ground->OutInDirect( _nTargetIndex, ptTargetPos, sZone, cState );
	}
	else if ( IsNpc(_nTargetIndex) )
	{
		npcinfo * pTarget = g_pNPCThreadManager->GetNPC(_nTargetIndex);
		if ( !pTarget )
		{
			return;
		}

		if ( pTarget->isdead() )
		{
			return;
		}

		if ( sZone != pTarget->getZone() )
		{
			return;
		}

		Point ptTargetPos = pTarget->getCurrentPoint();

		Point ptTemp = ptUserPos;

		ptUserPos = ptTargetPos;
		ptUserPos.z = ptTemp.z;
		ptTemp.z = ptTargetPos.z;
		ptTargetPos = ptTemp;

		pUser->setCurrentPoint(ptUserPos);

		pTarget->setCurrentPoint(ptTargetPos);

		g_Ground->OutInDirect( _nUserIndex, ptUserPos, sZone, cState );
		g_Ground->OutInDirect( _nTargetIndex, ptTargetPos, sZone, cState );
	}
}

// 20140702 �߰�(���ٿ�:����. ���� PC/NPC�� �� ���� ������)
void CSkill::Inhale( int _nUserindex, int _nTargetindex, Point _ptPos )
{
	if ( _nUserindex == _nTargetindex )
	{
		return;
	}

	char	cState = isteleport;
	Point	ptResult = _ptPos;		// Ÿ���� ���� ��ġ

	if ( -1 == _ptPos.y )
	{
	}
	else
	{	
		if ( IsUser(_nTargetindex) )
		{
			userinfo * pTargetUser = g_UserList->GetUser(_nTargetindex);
			if ( pTargetUser )
			{
				ptResult = pTargetUser->getCurrentPoint();

				ptResult.x = _ptPos.x;
				ptResult.y = _ptPos.y;

				GetRadianPoint( ptResult.x, ptResult.y, 10 + USER_BODY_RANGE );

				pTargetUser->setCurrentPoint( ptResult );
				g_Ground->Teleport( _nTargetindex, ptResult, (short)pTargetUser->getZone(), cState );
			}
		}
		else if ( IsNpc(_nTargetindex) )
		{
			npcinfo * pTargetNPC = g_pNPCThreadManager->GetNPC(_nTargetindex);
			if ( pTargetNPC )
			{
				// �Ϲ� NPC, OBJECT NPC�� ����
				int nSeeLv = pTargetNPC->GetNPCLevel();
				if ( 1001 == nSeeLv || 1002 == nSeeLv )
				{
					return;
				}

				// ���� ��� NPC ����
				int nGrade = pTargetNPC->getGrade();
				if ( nGrade == BOSS_MON_GRADE_ID )
				{
					return;
				}

				// �̼� 0�� NPC ����
				short sMoveSpeed = pTargetNPC->GetBaseMoveSpeed();
				if ( 0 >= sMoveSpeed )
				{
					return;
				}

				int nSize = pTargetNPC->GetBodySize();

				ptResult = _ptPos;

				ptResult.z = -2000;

				GetRadianPoint( ptResult.x, ptResult.y, 10 + nSize );

				pTargetNPC->setCurrentPoint( ptResult );
				g_Ground->Teleport( _nTargetindex, ptResult, (short)pTargetNPC->getZone(), cState );
			}
		}
	}

}
#endif //_ADD_SKILL_OPTIONS

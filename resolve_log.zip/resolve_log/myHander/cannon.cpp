#include "skill.h"
#include "cannon.h"
#include "Ground.h"
#include <crtdbg.h>

extern CGround* g_Ground;
extern CSkill g_Skill;

CCannon::CCannon()
{
	//SetAtt(Rect(0,500,500,0),44,103,1,4);
	m_bIsload = false;
	m_nTerm = 0;
	m_nCounter = 0;
	m_sZone = 0;
	m_sSkillcode = 0;
	m_sSkilllvl = 0;
	m_sDskillcode = 0;
	m_dwstarttime = 0;
}

void CCannon::SetAtt(Rect rect,short z,short scode,short slvl,int t)
{
	m_Area = rect;
	m_sZone = z;
	m_sSkillcode = scode;
	m_sSkilllvl = slvl;
	m_nTerm = t;
	m_nCounter = GetTickCount() % m_nTerm;
	m_bIsload = true;
}

void CCannon::CheckTime()
{
	m_nCounter++;
	if(m_nCounter>= m_nTerm)
	{
		//�������� ��� �õ�
		int tm_nCounter = 0;
		bool done = false;
		while(!done)
		{
			if(tm_nCounter++ > 3)
			{
				break;
			}

			int vx = m_Area.x2 - m_Area.x1;
			int vy = m_Area.y1 - m_Area.y2;
			Point d;

			// 20060222 �߰�(�̼���:�����Լ� ����ð���� �����߻��� �ʱ�ȭ)
			//srand((unsigned)time(NULL));

			d.x = m_Area.x1 + rand() % vx;
			d.y = m_Area.y2 + rand() % vy;	//����߸� ��ǥ ����
			d.z = 0;

			if(!g_Ground->checkbitmap(d, m_sZone))
			{
				//�������� ���
				pResponseUseSkill prus;
				prus.header = fuseskill;
				prus.subheader = 0;
				prus.skillcode = m_sSkillcode;
				prus.slvl = m_sSkilllvl;
				prus.userindex = -MAX_NPC;
				prus.x = d.x;
				prus.y = d.y;
				prus.z = d.z;
				//char data[SIZE_ONE_DATA];
				//GSetDataBlock(data,fuseskill,-MAX_NPC,(char*)&prus,sizeof(pResponseUseSkill));
				g_Ground->Notice((char*)&prus, d, m_sZone);

				m_dpoint = d;
				m_dwstarttime = GetTickCount();
				m_sDskillcode = m_sSkillcode;

				done = true;
				//_RPTF3(_CRT_WARN,"cannon - %d,%d,%d\n",d.x,d.y,d.z);
			}
		}

		m_nCounter = 0;
	}
}

void CCannon::CheckDelay()
{
	if(m_sDskillcode)
	{
		DWORD t = GetTickCount();
		if((__int64)t - m_dwstarttime > g_Skill.m_Skilllist[m_sSkillcode].m_nCasttime)
		{
			g_Ground->UseObjectSkill(m_sDskillcode, m_dpoint, m_sZone, m_sSkilllvl);
			m_sDskillcode = 0;
		}
	}
}



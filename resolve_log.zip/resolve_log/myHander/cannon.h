#ifndef _CANNON_H
#define _CANNON_H

#include "global.h"

class CCannon
{
public:
	CCannon();
	void 	CheckTime();
	void 	SetAtt(Rect rect,short z,short scode,short slvl,int t);
	bool 	IsLoad(){return m_bIsload;};
	void 	CheckDelay();

private:
	Rect	m_Area;
	int		m_nTerm;
	int		m_nCounter;
	short 	m_sZone;
	short 	m_sSkillcode;
	short 	m_sSkilllvl;
	bool	m_bIsload;
	short 	m_sDskillcode;
	Point 	m_dpoint;
	DWORD 	m_dwstarttime;
};

#endif

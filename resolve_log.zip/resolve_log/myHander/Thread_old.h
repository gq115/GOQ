#pragma once
#include <process.h>

#ifndef THREAD_OLD_H
#define THREAD_OLD_H

#define THREAD_STATE_STOP		0
#define THREAD_STATE_RUNNING	1
#define THREAD_STATE_SLEEP		2

// ������ ������ ���� Ŭ����
class CThread_Old
{
public:
	CThread_Old();
	~CThread_Old();

	int		GetThreadState();
	int		GetThreadStateString(char* buf);
	DWORD	GetThreadId(){return m_Thread_ID;};
	void Stop();

protected:
	
	int		tResume(){m_Thread_State=THREAD_STATE_RUNNING; return 1;/*return ResumeThread(m_HThread);*/};
	int		tSleep(){m_Thread_State=THREAD_STATE_SLEEP; return SuspendThread(m_HThread);};		
	void	tSleep(DWORD ms){m_Thread_State=THREAD_STATE_SLEEP;Sleep(ms);};		// ����� ����
	
	HANDLE	m_HThread;
	unsigned int	m_Thread_ID;
	
	int		m_Thread_State;
	bool	m_Thread_Terminate;
};

#endif
#include "userlist.h"
#include "guild.h"
#include "union.h"
#include <crtdbg.h>
#include <time.h>
#include "CMSModule.h"

#include "fileclass.h"
extern CFileManager g_fm;

extern UserList*	 g_UserList;
extern CUnionList g_ulist;
// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
//extern CCMSModule g_GCMSM;

Guild::Guild()
{
#ifdef _SPINLOCK
	InitializeCriticalSectionAndSpinCount(&m_cs, MAX_SPIN_COUNT);
#else
	InitializeCriticalSection(&m_cs);
#endif
	m_nGldIndex = -1;
}

Guild::~Guild()
{
	DeleteCriticalSection(&m_cs);
}

void Guild::init()
{
	ZeroMemory(&m_guilddata, sizeof(m_guilddata));
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		m_nMembermap[i] = -1;
		m_nJoinmap[i] = -1;
		m_nDelaylist[i] = -1;
	}

	m_nLeaderindex = -1;
	m_nJoincount = 0;
	m_nMembercount = 0;
	m_nNoticecount = 0;
	m_nIsdataloaded = 0;
	m_nDelaycount = 0;
	m_nMcount = 0;
	ZeroMemory(&m_tgn,sizeof(m_tgn));
	ZeroMemory(&m_tgm,sizeof(m_tgm));

#ifdef _RENEWAL_GUILD
	ZeroMemory(&m_tga,sizeof(m_tga));
	ZeroMemory(&m_tgb,sizeof(m_tgb));
	ZeroMemory(&m_tgal,sizeof(m_tgal));
	ZeroMemory(&m_tgbl,sizeof(m_tgbl));

	ZeroMemory(strAdmissionName,sizeof(strAdmissionName));	
#endif
}

char Guild::guildJoin(char* cname,int userindex)		//user�� ���ӿ� �������� ȣ��
{
#ifndef _SINGLETHREAD
	XLOG("s-Guild::guildJoin");
	EnterCriticalSection(&m_cs);
#endif
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition >= 1 && strncmp(m_guilddata.GuildChr[i].strName,cname,CNAME_LENGTH) == 0)
		{
			if(i == 0)
			{
				m_nLeaderindex = userindex;
			}
			m_nMembermap[i] = 	userindex;
			m_nMembercount++;
			bool find = false;
			if(m_nJoincount < MAX_POSITION_NUM)
			{
				for(int j = 0; j < m_nJoincount; j++)
				{
					int uindex = m_nJoinmap[j];
					if(uindex == userindex)
					{
						_RPTF1(_CRT_WARN,"duplicated userindex - %d\n",userindex);
						if(find == true)
						{
							m_nJoinmap[j] = -1;
						}
						else
						{
							find = true;
						}
					}
					
					if(uindex >= 0)
					{
						userinfo* ui = g_UserList->GetUser(uindex);
						if(ui)
						{
							ui->sendguild(gufmemberjoin, i, m_nMembermap[i]);
						}
					}
					else if(!find)
					{					//m_nJoinmap �߰� ��°��� ���� ����
						m_nJoinmap[j] = userindex;
						find = true;
					}
				}

				if(!find)
				{
					m_nJoinmap[m_nJoincount] = userindex;
					m_nJoincount++;
				}
			}
			else
			{
				_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
			}
#ifndef _SINGLETHREAD
			LeaveCriticalSection(&m_cs);
			XLOG("e-Guild::guildJoin");
#endif
			return 2;			//ã�� �����͵� load��
		}
	}
#ifndef _SINGLETHREAD
	LeaveCriticalSection(&m_cs);
	XLOG("e-Guild::guildJoin");
#endif
	return 1;	//�� ã��
}

bool Guild::guildLeave(int userindex)
{
	userinfo* ui;
#ifndef _SINGLETHREAD
	XLOG("s-Guild::guildLeave");
	EnterCriticalSection(&m_cs);
#endif
	for(int i = 0;i<MAX_POSITION_NUM;i++)
	{
		if(m_nJoinmap[i]==userindex)
		{
			m_nJoinmap[i] = -1;
			if(i == m_nJoincount-1)
			{//m_nJoinmap�� ������ ����� �����ٸ� m_nJoinmap�� �ϳ� ����
				m_nJoincount--;
			}
		}
		
		if(m_nLeaderindex ==userindex)
		{
			m_nLeaderindex = -1;
		}

		if(m_nMembermap[i] == userindex)
		{
			m_nMembermap[i] = -1;
			if(m_nJoincount<MAX_POSITION_NUM)
			{
				for(int j = 0;j<m_nJoincount;j++)
				{
					int uindex = m_nJoinmap[j];
					if(uindex>=0)
					{
						//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
						ui = g_UserList->GetUser(uindex);
						if(ui && ui->isLogIn())
						{
							ui->sendguild(gufmemberjoin, i, m_nMembermap[i]);
						}
					}
				}
			}
			else
			{
				_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
			}

			m_nMembercount--;
			//break;
		}
	}
	
#ifndef _SINGLETHREAD
	LeaveCriticalSection(&m_cs);
	XLOG("e-Guild::guildLeave");
#endif
	if(m_nMembercount ==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

MEMBER* Guild::getMember(int mindex)
{
	if(mindex >= 0 && mindex < MAX_POSITION_NUM)
	{
		//if(membermap[mindex]>=0){	
		return &m_guilddata.GuildChr[mindex];
		//}
	}
	return NULL;
}

MEMBER* Guild::getMember()
{
	return m_guilddata.GuildChr;
}

NOTICE* Guild::getNotice(int nindex)
{
	if(nindex >= 0 && nindex < MAX_NOTICE_COUNT)
	{
		if(*m_guilddata.NoticeData[nindex].strNotice)
		{
			return &m_guilddata.NoticeData[nindex];
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"nindex - %d\n",nindex);
	}
	return NULL;
}

#ifdef _RENEWAL_GUILD
BANKINGLOG* Guild::getBankingLog(int nindex) //����
{
	if(nindex >= 0 && nindex < MAX_BANKINGLOG_COUNT)
	{
		if(*m_guilddata.BankingData[nindex].strWriter)
		{
			return &m_guilddata.BankingData[nindex];
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"nindex - %d\n",nindex);
	}
	return NULL;
}

ADMISSION* Guild::getAdmission(int nindex)	//����
{
	if(nindex >= 0 && nindex < MAX_ADMISSIONLIST_COUNT)
	{
		if(*m_guilddata.AdmissionList[nindex].strWriter)
		{
			return &m_guilddata.AdmissionList[nindex];
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"nindex - %d\n",nindex);
	}
	return NULL;
}
#endif //_RENEWAL_GUILD

__int64* Guild::getSpecialBuff()
{
	return m_guilddata.nGuildSpecilalBuff;
}

void Guild::setSpecialPoint(short _sGSpecialPoint, __int64* _nGSpecialBuff, BYTE _nType)
{
	m_guilddata.sGuildSpecialPoint = _sGSpecialPoint;
	memcpy(m_guilddata.nGuildSpecilalBuff, _nGSpecialBuff, sizeof(m_guilddata.nGuildSpecilalBuff));

	if (EN_GUILD_SPECIAL_SAVE == _nType)
	{
/*
		__int64 tmpSBuff[GUILD_SPECIAL_FLAG_CNT];

		for(int i = (MAX_ATTRIBUTE_NUM - 1); i >= 0;i--)
		{
			for (int j = 0; j < GUILD_SPECIAL_FLAG_CNT; j++)
			{
				tmpSBuff[j] = _nGSpecialBuff[j] >> i;
				m_nSpecilaBuff[i+(MAX_ATTRIBUTE_NUM*j)] = tmpSBuff[j] & 1;
			}
		}
*/
	} 
	else if (EN_GUILD_SPECIAL_INIT == _nType)
	{
	}

	userinfo* ui;

	for(int j = 0;j<m_nJoincount;j++)
	{
		int uindex = m_nJoinmap[j];
		if(uindex>=0)
		{
			//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
			ui = g_UserList->GetUser(uindex);
			if(ui && ui->isLogIn())
			{
				ui->initiating();
			}
		}
	}

	sendRefreshData();
}

void Guild::setLevelUpPoint(int _nGLevelupPoint, BYTE _nPointType)
{
	if (EN_GUILD_TIME_POINT == _nPointType)
	{
		m_guilddata.nGuildTPoint += _nGLevelupPoint;
	} 
	else if (EN_GUILD_BATTLE_POINT == _nPointType)
	{
		m_guilddata.nGuildBPoint += _nGLevelupPoint;
	}
	else if (EN_GUILD_LVLPOINT_INIT == _nPointType)
	{
		m_guilddata.nGuildTPoint = 0;
		m_guilddata.nGuildBPoint = 0;
		m_guilddata.nGuildLevel = 1;
		m_guilddata.sGuildMemMax = DEFAULT_POSITION_NUM;
		m_guilddata.sGuildSpecialPoint = 0;
		ZeroMemory(m_guilddata.nGuildSpecilalBuff,sizeof(m_guilddata.nGuildSpecilalBuff));
	}

	sendRefreshData();
}

BOOL Guild::setGuildLevleUp(GUILD_LEVELUP_PROCESS* _pglp)
{
	if (_pglp)
	{
		m_guilddata.nGuildLevel += 1;
		m_guilddata.sGuildMemMax +=	_pglp->sAddMemCnt;
		m_guilddata.sGuildSpecialPoint +=_pglp->sAddSPoint;
		m_guilddata.dwLevelUpTime = _pglp->dwLevelUpTime;

		sendRefreshData();
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}
void Guild::sendRefreshData()
{
	userinfo* ui;

	for(int j = 0;j<m_nJoincount;j++)
	{
		int uindex = m_nJoinmap[j];
		if(uindex>=0)
		{
			//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
			ui = g_UserList->GetUser(uindex);
			if(ui && ui->isLogIn())
			{
				ui->sendguilddataRenewal(&m_guilddata);
			}
		}
	}
}

void Guild::guildInit(char svn)			//data�� load�Ǹ� �̰��� ȣ��.
{
	int i = 0;
	// 20120120 ����(�̼���:��� ������ ĳ���� �α��ν� ���� �ε� �ϵ��� ����, m_nIsdataloaded = 1 -> m_nIsdataloaded = 0)
	// 20120206 ����(�̼���:��� ������ ĳ���� ���� �α��� �ÿ��� �ε� �ϵ��� ����, m_nIsdataloaded = 0 -> m_nIsdataloaded = 1, ��� ���� ���� �߻� ����)
	// ���� / ���� ��� ���� ����, ���� ���Ͽ� ���� �Ȼ������ ���� �� ������ ���� Ȯ���� �Ұ��� ������ �ش� ���� �߻� ������ ������ �κ��� �̰��ۿ� ����
	m_nIsdataloaded = 1;

//#ifdef _DBSYSTEM
//	// 20120109 �߰�(�̼���:��� �����ʹ� ��� �ε� �ؾ� �ϱ� ������ �����͸� �ε� �ص� m_nIsDataLoaded�� 0���� ����)
//	// �Ź� ������ ���� �� �� ���� ��� �ε��ϰ� ��� �������� ��� ĳ���Ϳ� ��� ������ �����ϱ� ������ ���� �߻� ����
//	// �۷ι��� ĳ�� ���� �� ��� ������ �ε� �ϵ��� ����
//	// 20120119 ����(�̼���:��� ���� ���� ��� ������ �ε� �ϵ��� ����)
//	//#ifdef _GLOBAL
//		m_nIsdataloaded = 1;
//	//#endif // _GLOBAL
//#endif // _DBSYSTEM

	for(i = 0; i < MAX_NOTICE_COUNT; i++)
	{
		if(*m_guilddata.NoticeData[i].strNotice)
		{
			m_nNoticecount++;
		}
	}
	
	m_nMcount = 0;
	bool first = true;

#ifdef _RENEWAL_GUILD
///< 20130320 �߰�(����ȣ:��� ������ - ���� �ε��� ��� �ɹ� ī��Ʈ ���ϴ� ��ġ ����)
	for(i = 0; i < m_guilddata.sGuildMemMax; i++)
	{
		if(*m_guilddata.GuildChr[i].strName)
		{
			m_nMcount++;
		}
		else
		{
			m_guilddata.GuildChr[i].btPosition = 0;
		}
	}

	for(i = 0; i < m_guilddata.sGuildMemMax; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition >= 1)
		{
			if(m_guilddata.GuildChr[i].btPosition != i + 1)
			{
				_RPTF3(_CRT_WARN, "wrong position - %s, %d, %d\n", m_guilddata.GuildChr[i].strName, i + 1, m_guilddata.GuildChr[i].btPosition);
				m_guilddata.GuildChr[i].btPosition = i + 1;
			}
#else //_RENEWAL_GUILD
	for(i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition >= 1)
		{
			if(m_guilddata.GuildChr[i].btPosition != i + 1)
			{
				_RPTF3(_CRT_WARN, "wrong position - %s, %d, %d\n", m_guilddata.GuildChr[i].strName, i + 1, m_guilddata.GuildChr[i].btPosition);
				m_guilddata.GuildChr[i].btPosition = i + 1;
			}

			if(*m_guilddata.GuildChr[i].strName)
			{
				m_nMcount++;
			}
			else
			{
				m_guilddata.GuildChr[i].btPosition = 0;
			}

//			g_GCMSM.SendGuildList(m_nGldIndex,guilddata.strName,NULL,guilddata.GuildChr[i].strName);
#endif //_RENEWAL_GUILD
		}

		if(m_nDelaylist[i] >= 0)
		{
			//guild data�� ������ ���� user�鿡�� data�� ������
			userinfo* ui = g_UserList->GetUser(m_nDelaylist[i]);
			if(ui)
			{
				ui->guildjoinjob();
			}
			m_nDelaylist[i] = -1;
		}
	}
	m_nDelaycount = 0;
}

char Guild::checkDataLoad(int userindex)
{
	if(m_nIsdataloaded)
	{
		return 1;
	}
	else
	{
		m_nDelaylist[m_nDelaycount++] = userindex; 			//�����Ͱ� load���� �ʾ���
		return 2;
	}
}

int Guild::getMaster()
{
	return m_nLeaderindex;
}

char* Guild::getViceMaster()
{
	return m_guilddata.GuildChr[1].strName;
}

#ifdef _RENEWAL_GUILD
// 20130320 �߰�(����ȣ:��� ������ - ��� �ɹ� ���� �߰��� �ε����� �޾ƿ� ���� ȹ��)
int Guild::newMember(int uindex)
{
	userinfo* ui = g_UserList->GetUser(uindex);

	if(ui)
	{
		if(m_nMcount < m_guilddata.sGuildMemMax)
		{
			ZeroMemory(&m_guilddata.GuildChr[m_nMcount],sizeof(MEMBER));
			m_guilddata.GuildChr[m_nMcount].btClass = ui->GetCharClass();
			m_guilddata.GuildChr[m_nMcount].sLevel = ui->getLev();
			m_guilddata.GuildChr[m_nMcount].btPosition = m_nMcount + 1;
			memcpy(m_guilddata.GuildChr[m_nMcount].strName,ui->getName(),CNAME_LENGTH);
			m_guilddata.GuildChr[m_nMcount].bIsMaster = ui->IsMaster();
			m_guilddata.GuildChr[m_nMcount].btChangeClass = ui->GetChangeClass();
			m_guilddata.GuildChr[m_nMcount].fexp = ui->GetCurrentExp();
#ifdef _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nPVPPoint = ui->GetPVPPoint();
#else // _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nPVPPoint = 0;
#endif // _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nBPoint = 0;		
			m_guilddata.GuildChr[m_nMcount].nTPoint = 0;

			m_nMcount++;

			return m_nMcount - 1;
		}
	}

	return -1;
}

// 20130320 �߰�(����ȣ:��� ������ - ��� ����Ʈ�� ���� ���� ��û�� ��Ŷ ������)
int Guild::newMemberAdmission(pGuildAdmission* pga)
{
	userinfo* ui = g_UserList->GetUser(g_UserList->Find(pga->writer));

	if(ui)
	{
		if(m_nMcount < m_guilddata.sGuildMemMax)
		{
			ZeroMemory(&m_guilddata.GuildChr[m_nMcount],sizeof(MEMBER));
			m_guilddata.GuildChr[m_nMcount].btClass = ui->GetCharClass();
			m_guilddata.GuildChr[m_nMcount].sLevel = ui->getLev();
			m_guilddata.GuildChr[m_nMcount].btPosition = m_nMcount + 1;
			memcpy(m_guilddata.GuildChr[m_nMcount].strName,ui->getName(),CNAME_LENGTH);
			m_guilddata.GuildChr[m_nMcount].bIsMaster = ui->IsMaster();
			m_guilddata.GuildChr[m_nMcount].btChangeClass = ui->GetChangeClass();
			m_guilddata.GuildChr[m_nMcount].fexp = ui->GetCurrentExp();
#ifdef _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nPVPPoint = ui->GetPVPPoint();
#else // _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nPVPPoint = 0;
#endif // _PVPSYSTEM
			m_guilddata.GuildChr[m_nMcount].nBPoint = 0;		
			m_guilddata.GuildChr[m_nMcount].nTPoint = 0;

			m_nMcount++;

			return m_nMcount - 1;
		}
	}
	else
	{
		if(m_nMcount < m_guilddata.sGuildMemMax)
		{
			ZeroMemory(&m_guilddata.GuildChr[m_nMcount],sizeof(MEMBER));
			m_guilddata.GuildChr[m_nMcount].btClass = pga->btClass;
			m_guilddata.GuildChr[m_nMcount].sLevel = pga->sLevel;
			m_guilddata.GuildChr[m_nMcount].btPosition = m_nMcount + 1;
			memcpy(m_guilddata.GuildChr[m_nMcount].strName,pga->writer,CNAME_LENGTH);
			m_guilddata.GuildChr[m_nMcount].bIsMaster = pga->bismaster;
			m_guilddata.GuildChr[m_nMcount].btChangeClass = pga->btChangeClass;
			m_guilddata.GuildChr[m_nMcount].fexp = 0;
			m_guilddata.GuildChr[m_nMcount].nPVPPoint = 0;
			m_guilddata.GuildChr[m_nMcount].nBPoint = 0;		
			m_guilddata.GuildChr[m_nMcount].nTPoint = 0;

			m_nMcount++;

			return m_nMcount - 1;
		}
	}

	return -1;
}
#else //_RENEWAL_GUILD
// 20111017 ����(�̼���:���ϼ��� DBȭ ���� ��� ��� �߰� �� ��ȯ�� bool���� int�� ����)
int Guild::newMember(char* cname, BYTE cclass, short level)
{
	if(m_nMcount < 30)
	{
		ZeroMemory(&m_guilddata.GuildChr[m_nMcount],sizeof(MEMBER));
		m_guilddata.GuildChr[m_nMcount].btClass = cclass;
		m_guilddata.GuildChr[m_nMcount].sLevel = level;
		m_guilddata.GuildChr[m_nMcount].btPosition = m_nMcount + 1;
		memcpy(m_guilddata.GuildChr[m_nMcount].strName,cname,CNAME_LENGTH);
		m_nMcount++;

		// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
		//g_GCMSM.SendGuildListAppend(m_nGldIndex, m_guilddata.strName, NULL, cname);

		return m_nMcount - 1;
	}

	return -1;
}
#endif // _RENEWAL_GUILD

void Guild::deleteMember(char* cname)
{
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(strncmp(cname, m_guilddata.GuildChr[i].strName, CNAME_LENGTH) == 0)
		{
			ZeroMemory(&m_guilddata.GuildChr[i], sizeof(MEMBER));
			m_nMcount--;

			// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
			//g_GCMSM.SendGuildListDelete(m_nGldIndex, m_guilddata.strName, NULL, cname);

			break;
		}
	}
}

void Guild::sendGuildMember(char* cname)
{
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(strncmp(cname, m_guilddata.GuildChr[i].strName, CNAME_LENGTH) == 0)
		{
			sendguildmember(i);
			break;
		}
	}
}

void Guild::sendGuildMember()
{
	///< 20130320 �߰�(����ȣ:��� ������ - ���� ���Ե� �ο����Ը� ����)
	for(int i = 0; i < getMemberCount(); i++)
	{
		sendguildmember(i);
	}
}

void Guild::sendguildmember(int pos)
{
	MEMBER* mem = &m_guilddata.GuildChr[pos];			//pos�� member�� ������
	for(int j = 0; j < m_nJoincount; j++)
	{					//join�� ������� �˷���
		int uindex = m_nJoinmap[j];
		if(uindex >= 0)
		{
			//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
			userinfo* ui = g_UserList->GetUser(uindex);
			if(ui && ui->isLogIn())
			{
				if(mem->btPosition > 0)
				{
#ifdef _RENEWAL_GUILD
					///< 20130320 �߰�(����ȣ:��� ������ - ��� �ɹ� �����Ͱ� �߰�)
					ui->sendguildmemberRenewal(mem);
#else
					ui->sendguildmember(mem->strName,mem->btClass,mem->sLevel,mem->btPosition,mem->strPreview);
#endif //_RENEWAL_GUILD
					ui->sendguild(gufmemberjoin,pos,m_nMembermap[pos]);
				}
				else
				{
					ui->sendblankguildmember(pos+1);
					ui->sendguild(gufmemberjoin,pos,m_nMembermap[pos]);
				}
			}
		}
	}
}

bool Guild::setMember(MEMBER* mem)
{
	memcpy(m_guilddata.GuildChr,mem,sizeof(MEMBER)*MAX_POSITION_NUM);
	return checkMemberChange();
}

bool Guild::checkMemberChange(int sit)
{
#ifndef _SINGLETHREAD
	//XLOG("s-Guild::checkMemberChange");
	EnterCriticalSection(&m_cs);
#endif
	m_nMcount = 0;
	int checkmap[MAX_POSITION_NUM];			//������ ���� ǥ�ÿ� map
	ZeroMemory(checkmap,sizeof(checkmap));			//checkmap�ʱ�ȭ
	int i = 0;
	
	for(i = 0; i < MAX_POSITION_NUM; i++)
	{			//memebermap�� ����
		m_nMembermap[i] = -1;						//membermap - �������� userindex
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{		//������ ������
		/*	if(guilddata.GuildChr[i].btPosition != i+1){
				_RPTF3(_CRT_WARN,"wrong position - %s,%d,%d\n",guilddata.GuildChr[i].strName,i+1,guilddata.GuildChr[i].btPosition);
				guilddata.GuildChr[i].btPosition = i+1;
			}*/
			m_nMcount++;									//membermap�� ������
			if(m_nJoincount < MAX_POSITION_NUM)
			{				//
				for(int j = 0; j < m_nJoincount; j++)
				{
					int uindex = m_nJoinmap[j];			//join�� ������ ���Ͽ�
					if(uindex >= 0)
					{
						userinfo* ui = g_UserList->GetUser(uindex);
						if(ui)
						{
							if(g_fm.IsArenaServer())
							{
								if(strncmp(ui->getName() + 2, m_guilddata.GuildChr[i].strName, CNAME_LENGTH) == 0)
								{	//join�� ������
									m_nMembermap[i] = uindex;

									if(i==0)
									{			//�����϶� ǥ������
										m_nLeaderindex = uindex;
									}
									checkmap[j]  = 1;		//j��° �ι��� ��Ͽ� ����
									break;
								}
							}
							else
							{
								if(strncmp(ui->getName(), m_guilddata.GuildChr[i].strName, CNAME_LENGTH) == 0)
								{	//join�� ������
									m_nMembermap[i] = uindex;
									
									if(i==0)
									{			//�����϶� ǥ������
										m_nLeaderindex = uindex;
									}
									
									checkmap[j]  = 1;		//j��° �ι��� ��Ͽ� ����
									break;
								}
							}
						}
					}
				}
			}
			else
			{
				_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
			}
		}
	}

	if(sit != 3)
	{
		if(m_nJoincount<MAX_POSITION_NUM)
		{
			for(i = 0; i < m_nJoincount; i++)
			{				//üũ�ؼ� ��Ͽ� ���� ����� �߹���� ����..
				if(checkmap[i] ==0)
				{
					int uindex = m_nJoinmap[i];
					if(uindex>=0)
					{
						userinfo* ui = g_UserList->GetUser(uindex);
						if(ui)
						{
							ui->expulsioned(m_guilddata.strName);
							if(guildLeave(uindex))
							{
#ifndef _SINGLETHREAD
								LeaveCriticalSection(&m_cs);
								//XLOG("e-Guild::checkMemberChange");
#endif
								return true;
							}
						}
					}
				}
			}
		}
		else
		{
			_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
		}
	}
	
	for(i = 0; i < MAX_POSITION_NUM; i++)
	{
		sendguildmember(i);
	}

#ifndef _SINGLETHREAD
	LeaveCriticalSection(&m_cs);
	//XLOG("e-Guild::checkMemberChange");
#endif
	return false;
}

#ifdef _RENEWAL_GUILD
BANKINGLOG* Guild::setBankingLog(pGuildBankingLog* _pgb, int uindex) //����
{

	time_t ttime = 0;  // <djelee> : 2011.04.08 : DWORD -> time_t
	time(&ttime);

	int n;
	userinfo* ui = g_UserList->GetUser(uindex);

	if(m_guilddata.BankingData[MAX_BANKINGLOG_COUNT-1].dwWrittenTime) // ������ ���� ���ִ�.
	{
		for ( n = 0; ( n + 1 ) < MAX_BANKINGLOG_COUNT; n++ )
		{
			memcpy( &m_guilddata.BankingData[n], &m_guilddata.BankingData[n+1], sizeof(BANKINGLOG) );

			if ( !m_guilddata.BankingData[n+1].dwWrittenTime )
			{
				n++;
				break;
			}

			ZeroMemory( &m_guilddata.BankingData[n+1], sizeof(BANKINGLOG) );
		}

		m_guilddata.BankingData[n].dwWrittenTime = ttime;
		m_guilddata.BankingData[n].bIO = _pgb->IO;
		m_guilddata.BankingData[n].nIOGold = _pgb->IOGold;
		memcpy(m_guilddata.BankingData[n].strWriter,_pgb->writer,CNAME_LENGTH);

		ui->setfsguildflag(EN_GUILDBANKING,n);
		return &m_guilddata.BankingData[n];
	}
	else // �������� ��������Ƿ� �߰��� ������� ã�ƶ�
	{
		for ( n = 0; n < MAX_BANKINGLOG_COUNT; n++)
		{
			if (!m_guilddata.BankingData[n].dwWrittenTime)
			{
				m_guilddata.BankingData[n].dwWrittenTime = ttime;
				m_guilddata.BankingData[n].bIO = _pgb->IO;
				m_guilddata.BankingData[n].nIOGold = _pgb->IOGold;
				memcpy(m_guilddata.BankingData[n].strWriter,_pgb->writer,CNAME_LENGTH);

				ui->setfsguildflag(EN_GUILDBANKING,n);
				return &m_guilddata.BankingData[n];
			}
		}

		return NULL;
	}
}

ADMISSION* Guild::setAdmission(pGuildAdmission* _pga, int uindex) //���� ���
{
	time_t ttime = 0;  // <djelee> : 2011.04.08 : DWORD -> time_t
	time(&ttime);

	userinfo* ui = g_UserList->GetUser(uindex);

	if(*m_guilddata.AdmissionList[MAX_ADMISSIONLIST_COUNT-1].strWriter)
	{
		return NULL;
	}
	else
	{
		for(int i = 0; i < MAX_ADMISSIONLIST_COUNT; i++)
		{
			if(!*m_guilddata.AdmissionList[i].strWriter)
			{
				m_guilddata.AdmissionList[i].dwWrittenTime = ttime;
				m_guilddata.AdmissionList[i].bIsMaster = _pga->bismaster;
				m_guilddata.AdmissionList[i].btChangeClass = _pga->btChangeClass;
				m_guilddata.AdmissionList[i].btClass = _pga->btClass;
				m_guilddata.AdmissionList[i].sLevel = _pga->sLevel;
				memcpy(m_guilddata.AdmissionList[i].strWriter,_pga->writer,CNAME_LENGTH);

				ui->setfsguildflag(EN_GUILDADMISSION,i);
				return &m_guilddata.AdmissionList[i];
			}
		}
		return NULL;
	}

}

#endif //_RENEWAL_GUILD

/**
@brief ��� ���� ���� �Լ�
@date 20111020
@author �̼���(bestdev@gameonstudio.co.kr)
@param &pos(��� ���� ��ġ)
@param *notice(��� ���� ����)
@param *cname(��� ���� �ۼ��� ĳ����)
@return NOTICE*(��� ���� ����), NULL(��� ���� ���� �Ұ�)
*/
NOTICE* Guild::setNotice(int &pos, char *notice, char *cname)
{
	if(pos >= 0 && pos < MAX_NOTICE_COUNT)
	{
		setnotice(pos, notice, cname);
		return &m_guilddata.NoticeData[pos];
	}
	else
	{
		if(pos == -1)
		{
#ifdef _RENEWAL_GUILD
			// 20130320 �߰�(����ȣ:��� ������ - ��� ���� ���� 5�� ���̸鼭 0�� ��ġ�� ��� �Ұ� �޽����� ���, ��������� ��� ������ 6���̴�.)
			for(int i = START_NOTICE_POS; i < MAX_NOTICE_COUNT; i++)
#else
			for(int i = 0; i < MAX_NOTICE_COUNT; i++)
#endif //_RENEWAL_GUILD			
			{
				if(!*m_guilddata.NoticeData[i].strNotice)
				{
					setnotice(i, notice, cname);
					pos = i;
					return &m_guilddata.NoticeData[i];
				}
			}
			return NULL;
		}
		else
		{
			_RPTF1(_CRT_WARN, "pos - %d\n", pos);
			return NULL;
		}
	}
}

void Guild::setNotice(NOTICE* no, int pos)
{
	if(pos >= 0 && pos < MAX_NOTICE_COUNT)
	{
		memcpy(&m_guilddata.NoticeData[pos], no, sizeof(NOTICE));
		sendNotice(pos);
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
}

/**
@brief ��� ���� ���� �Լ�
@date 20111020
@author �̼���(bestdev@gameonstudio.co.kr)
@param pos(��� ���� ��ġ)
@param *notice(��� ���� ����)
@param *cname(��� ���� �ۼ��� ĳ����)
@return ����
*/
void Guild::setnotice(int pos, char *notice, char *cname)
{
	if(pos >= 0 && pos < MAX_NOTICE_COUNT)
	{
		time_t ttime = 0;  // <djelee> : 2011.04.08 : DWORD -> time_t
		time(&ttime);
		m_guilddata.NoticeData[pos].dwWrittenTime = ttime;

		memcpy(m_guilddata.NoticeData[pos].strNotice,notice,300);
		memcpy(m_guilddata.NoticeData[pos].strWriter,cname,CNAME_LENGTH);
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
}

void Guild::deleteNotice(int pos)
{
	if(pos >= 0 && pos < MAX_NOTICE_COUNT)
	{
		ZeroMemory(&m_guilddata.NoticeData[pos],sizeof(NOTICE));
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
}

void Guild::sendNotice(int pos)
{
	NOTICE* no = &m_guilddata.NoticeData[pos];
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int j = 0; j < m_nJoincount; j++)
		{
			int uindex = m_nJoinmap[j];
			if(uindex >= 0)
			{
				//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui && ui->isLogIn())
				{
					ui->sendguildnotice(pos,no->strNotice,no->strWriter,no->dwWrittenTime);
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
}

#ifdef _RENEWAL_GUILD
/**
@brief ��� �ڱ� ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@return void
@see 
@warning 
*/
void Guild::sendguildgold()
{
	pGuildsendgold sg;
	sg.header = fguildsendgold;
	sg.gold = getGuildGold();
	
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int j = 0; j < m_nJoincount; j++)
		{
			int uindex = m_nJoinmap[j];
			if(uindex >= 0)
			{
				//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui && ui->isLogIn())
				{
					ui->senddata((char*)&sg,sizeof(pGuildsendgold));
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",1);
	}
}
/**
@brief ��� ���� ��û ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param char * _cname ()
@return void
@see 
@warning 
*/
void Guild::deleteAdmission(char* _cname)
{
	for(int i = 0; i < MAX_ADMISSIONLIST_COUNT; i++)
	{
		if (!strncmp(m_guilddata.AdmissionList[i].strWriter, _cname, CNAME_LENGTH))
		{
			ZeroMemory(&m_guilddata.AdmissionList[i],sizeof(ADMISSION));
			return;
		}
		
	}
}

/**
@brief ��� ���� ��û ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int pos ()
@return void
@see 
@warning 
*/
void Guild::sendAdmission(int pos) //����
{
	ADMISSION* ad = &m_guilddata.AdmissionList[pos];

	//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
	userinfo* ui = g_UserList->GetUser(getMaster());
	if(ui && ui->isLogIn())
	{
		ui->sendguildadmission(ad);
	}
}
/**
@brief ��� ���� ��û ����Ʈ ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int _loadtype (DB���� �Ѿ�� �����Ͱ� ������ ������ ������ 0�ʰ�, �޸� �� ���۽� 0 ����)
@return void
@see 
@warning 
*/
void Guild::sendAdmissionList(int _loadtype)
{
	if (_loadtype >= 0)
	{
		ZeroMemory(&m_guilddata.AdmissionList, sizeof(m_guilddata.AdmissionList));
		memcpy(&m_guilddata.AdmissionList, &m_tgal.Guildadmissionlist, sizeof(m_guilddata.AdmissionList));
	}

	pGuildAdmissionListResponse stGadmissionlist;
	ZeroMemory(&stGadmissionlist, sizeof(pGuildAdmissionListResponse));

	stGadmissionlist.header = fguildAdmissionList;
	stGadmissionlist.result = 0;

	for(int i = 0; i < MAX_ADMISSIONLIST_COUNT; i++)
	{
		ADMISSION* adl = &m_guilddata.AdmissionList[i];
		if(adl)
		{
			if (adl->sLevel > 0)
			{
				stGadmissionlist.sGuildAdmission[i].bismaster = adl->bIsMaster;
				stGadmissionlist.sGuildAdmission[i].btChangeClass = adl->btChangeClass;
				stGadmissionlist.sGuildAdmission[i].btClass = adl->btClass;
				stGadmissionlist.sGuildAdmission[i].sLevel = adl->sLevel;
				stGadmissionlist.sGuildAdmission[i].ntime = adl->dwWrittenTime;
				memcpy(stGadmissionlist.sGuildAdmission[i].writer, adl->strWriter, CNAME_LENGTH);
			}

		}
	}
	userinfo* ui = g_UserList->GetUser(m_nLeaderindex);
	//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
	if(ui && ui->isLogIn())
	{
	ui->senddata((char*)&stGadmissionlist, sizeof(pGuildAdmissionListResponse));
	}
}

/**
@brief ��� �ڱ� �α� ����Ʈ ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int _loadtype (DB���� �Ѿ�� �����Ͱ� ������ ������ ������ 0�ʰ�, �޸� �� ���۽� 0 ����)
@return void
@see 
@warning 
*/
void Guild::sendBankingLogList(int _loadtype)
{
	if (_loadtype >= 0)
	{
		ZeroMemory(&m_guilddata.BankingData, sizeof(m_guilddata.BankingData));
		memcpy(&m_guilddata.BankingData, &m_tgbl.Guildbankingloglist, sizeof(m_guilddata.BankingData));
	}

	pGuildBankingLogListResponse stGbankingloglist;
	// 20130113 ����(�̼���:ZeroMemory�� Header ���� ���� ��ġ ����, ����ü ������ ZeroMemory�ϰ� ��� ����)
	ZeroMemory(&stGbankingloglist, sizeof(pGuildBankingLogListResponse));

	stGbankingloglist.header = fguildBankingList;
	stGbankingloglist.result = 0;

	for(int i = 0; i < MAX_BANKINGLOG_COUNT; i++)
	{
		//BANKINGLOG* bkl = g_guildlist.getBankingLog(m_nGldIndex,i);
		BANKINGLOG* bkl = &m_guilddata.BankingData[i];
		if(bkl)
		{
			if (bkl->nIOGold > 0)
			{
				stGbankingloglist.sGuildBankingLog[i].IO = bkl->bIO;
				stGbankingloglist.sGuildBankingLog[i].IOGold = bkl->nIOGold;
				stGbankingloglist.sGuildBankingLog[i].ntime = bkl->dwWrittenTime;
				memcpy(stGbankingloglist.sGuildBankingLog[i].writer, bkl->strWriter, CNAME_LENGTH);
			}		
		}
	}

	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int j = 0; j < m_nJoincount; j++)
		{
			int uindex = m_nJoinmap[j];
			if(uindex >= 0)
			{
				//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui && ui->isLogIn())
				{
					ui->senddata((char*)&stGbankingloglist, sizeof(pGuildBankingLogListResponse));
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"bankinglog - %d\n",1);
	}

}

/**
@brief �������� �ڱ� �α� ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param BANKINGLOG * _pgb ()
@return void
@see 
@warning 
*/
void Guild::sendBankingLog(BANKINGLOG* _pgb)
{
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int j = 0; j < m_nJoincount; j++)
		{
			int uindex = m_nJoinmap[j];
			if(uindex >= 0)
			{
				//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui && ui->isLogIn())
				{
					ui->sendguildbankinglog(_pgb);
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"bankinglog - %d\n",1);
	}
}

#endif //_RENEWAL_GUILD

bool Guild::changeDesignate(int pos, char* des)
{
	if(pos >= 0 && pos < MAX_POSITION_NUM)
	{
		if(m_guilddata.GuildChr[pos].btPosition > 0)
		{
			//copy
			memcpy(m_guilddata.GuildChr[pos].strPreview,des,MAX_PREVIEW_LEN);
			return true;
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
	return false;
}

bool Guild::changerank(int pos1, int pos2)
{
	if(pos1 >= 0 && pos1 < MAX_POSITION_NUM && pos2 >= 0 && pos2 < MAX_POSITION_NUM)
	{
		if(m_guilddata.GuildChr[pos1].btPosition > 0 && m_guilddata.GuildChr[pos2].btPosition > 0)
		{
			//copy
			MEMBER temp;
			memcpy(&temp,&m_guilddata.GuildChr[pos1],sizeof(MEMBER));
			memcpy(&m_guilddata.GuildChr[pos1],&m_guilddata.GuildChr[pos2],sizeof(MEMBER));
			memcpy(&m_guilddata.GuildChr[pos2],&temp,sizeof(MEMBER));
			m_guilddata.GuildChr[pos1].btPosition = pos1+1;
			m_guilddata.GuildChr[pos2].btPosition = pos2+1;
			return true;
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos1);
	}
	return false;
}

bool Guild::expulsion(int pos)
{
	if(pos >= 0 && pos < MAX_POSITION_NUM)
	{
		if(m_guilddata.GuildChr[pos].btPosition > 0)
		{
#ifndef _SINGLETHREAD
			XLOG("s-Guild::expulsion");
			EnterCriticalSection(&m_cs);
#endif
			// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
			//g_GCMSM.SendGuildListDelete(m_nGldIndex,m_guilddata.strName,NULL,m_guilddata.GuildChr[pos].strName);
			m_guilddata.GuildChr[pos].init();
			for(int i = pos + 1; i < MAX_POSITION_NUM; i++)
			{
				if(m_guilddata.GuildChr[i].btPosition > 0)
				{
					memcpy(&m_guilddata.GuildChr[i-1],&m_guilddata.GuildChr[i],sizeof(MEMBER));
					m_guilddata.GuildChr[i-1].btPosition = i;
				}
				else
				{
					m_guilddata.GuildChr[i-1].init();
					m_nMcount--;
					break;
				}
			}
#ifndef _SINGLETHREAD
			LeaveCriticalSection(&m_cs);
			XLOG("e-Guild::expulsion");
#endif
			return true;
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
	}
	return false;
}

bool Guild::withdraw(char* cname)
{
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{
			if(strncmp(m_guilddata.GuildChr[i].strName,cname,CNAME_LENGTH) == 0)
			{
				expulsion(i);
				return true;
			}
		}
	}
	return false;
}

void Guild::Disband()
{
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int i = 0; i < m_nJoincount; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui)
				{
					ui->disbanded(m_guilddata.strName);
#ifdef _RENEWAL_SIEGE
					// 20120828 �߰�(�Ź�ȣ: ĳ���� ����ڵ� �ʱ�ȭ)
					ui->SetGuildCode(0);
#endif // _RENEWAL_SIEGE
				}
			}
		}

		int ucode = m_guilddata.unioncode;
		if(ucode)
		{
			int uindex = g_ulist.getUnionIndex(ucode);
			g_ulist.checkGuildCount(uindex,m_guilddata.guildcode);
			g_clist.ClearSiegeList(ucode);
		}

		// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
		//g_GCMSM.SendClearGuild(m_guilddata.strName);

#ifdef _RENEWAL_GUILD
		for (int i = 0; i < MAX_ADMISSIONLIST_COUNT; i++)
		{
			if(m_guilddata.AdmissionList[i].dwWrittenTime > 0)
			{
				userinfo* ui = g_UserList->GetUser(g_UserList->Find(m_guilddata.AdmissionList[i].strWriter));
					
				if(ui && ui->isInGame())
				{
					ui->SetAdmissionCode(-1);
				}
			}
		}
		
#endif // RENEWAL_GUILD

		init();
	}
	else
	{
		_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
	}
}

int Guild::getMemberMap(int pos)
{
	if(pos >= 0 && pos < MAX_POSITION_NUM)
	{
		return m_nMembermap[pos];
	}
	else
	{
		_RPTF1(_CRT_WARN,"pos - %d\n",pos);
		return -1;
	}
}

void Guild::guildChat(int userindex, char* msg,char* cname)
{
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int i = 0; i < m_nJoincount; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				//UJ 120118, �̹� ���� �������� data ������ socket �����ϰ� userinfo lock�� ������ ������� ���� �� ����
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui && ui->isLogIn())
				{
					ui->sendmsg(userindex, msg,cname);
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
	}
}

void Guild::sendGuild(BYTE subheader,DWORD data1, DWORD data2)
{
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int i = 0; i < m_nJoincount; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui)
				{
					ui->sendguild(subheader,data1,data2);
				}
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
	}
}

int Guild::getMemberPos(char* cname)
{
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{
			if(strncmp(cname,m_guilddata.GuildChr[i].strName,CNAME_LENGTH)==0)
			{
				return i;
			}
		}
	}
	return -1;
}

int Guild::getMemberPos(int userindex)
{
#ifdef _RENEWAL_GUILD
	for(int i = 0; i < MAX_POSITION_NUM; i++)
#else
	for(int i = 0; i < 40; i++)
#endif //_RENEWAL_GUILD
	{
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{
			if(m_nMembermap[i] == userindex)
			{
				return i;
			}
		}
	}
	return -1;
}

bool Guild::memberLevelUp(int userindex, short level)
{
#ifdef _RENEWAL_GUILD
	for(int i = 0; i < MAX_POSITION_NUM; i++)
#else
	for(int i = 0; i < 40; i++)
#endif //_RENEWAL_GUILD
	{
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{
			if(m_nMembermap[i] == userindex)
			{
				m_guilddata.GuildChr[i].sLevel = level;
				return true;
			}
		}
	}
	return false;
}

void Guild::setUnionCode(DWORD ucode)
{
	if(m_guilddata.unioncode != ucode)
	{
		m_guilddata.unioncode = ucode;
		for(int i = 0; i < m_nJoincount && m_nJoincount < MAX_POSITION_NUM; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui)
				{
					ui->setUnionCode(ucode);
					ui->checkUnion();
				}
			}
		}
	}
}

void Guild::SendData(void* data,int size)
{
	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int i = 0; i < m_nJoincount; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				g_UserList->SendData(data,size,uindex);
			}
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"m_nJoinmap - %d\n",m_nJoinmap);
	}
}

void Guild::ExpeledFromUnion()
{
	m_guilddata.unioncode = 0;

	if(m_nJoincount < MAX_POSITION_NUM)
	{
		for(int i = 0; i < m_nJoincount; i++)
		{
			int uindex = m_nJoinmap[i];
			if(uindex >= 0)
			{
				userinfo* ui = g_UserList->GetUser(uindex);
				if(ui)
				{
					ui->ExpeledFromUnion();
				}
			}
		}
	}
}

void Guild::SendListToCMS()
{
	for(int i = 0; i < MAX_POSITION_NUM; i++)
	{
		if(m_guilddata.GuildChr[i].btPosition >= 1)
		{
			// 20120321 ����(�̼���:CMS ���� connection �ڵ� ����, �ѱ� ä�ü��� ����)
			//g_GCMSM.SendGuildList(m_nGldIndex,m_guilddata.strName,NULL,m_guilddata.GuildChr[i].strName);
		}
	}
}

void Guild::setBase(GUILD_BASE* gb)
{
	if(gb)
	{
		m_guilddata.unioncode = gb->unionCode;
	}
}

GuildList::GuildList()
{
	m_Freeindex.init();
	m_nListsize = GUILD_NUM;
	for(int i = 0; i < m_nListsize; i++)
	{
		m_Freeindex.push(i);

		m_Guildlist[i].setIndex(i);
	}
	m_GuildTree.init(m_nListsize);
	m_chMaking = 0;
#ifdef _SPINLOCK
	InitializeCriticalSectionAndSpinCount(&m_cs, MAX_SPIN_COUNT);
#else
	InitializeCriticalSection(&m_cs);
#endif
}

GuildList::~GuildList()
{
	DeleteCriticalSection(&m_cs);
}

GuildList g_guildlist;

int GuildList::GetIndex()
{
#ifndef _SINGLETHREAD
	XLOG("s-GuildList::GetIndex");
	EnterCriticalSection(&m_cs);
#endif
	int index = m_Freeindex.pop();
#ifndef _SINGLETHREAD
	LeaveCriticalSection(&m_cs);
	XLOG("e-GuildList::GetIndex");
#endif
	if(index >= 0 && index < m_nListsize)
	{
		m_Guildlist[index].init();
		return index;
	}
	else
	{
		_RPTF1(_CRT_WARN,"index - %d\n",index);
	}
	return -1;
}

void GuildList::ReturnIndex(int index)
{
	if(index >= 0 && index < m_nListsize)
	{
#ifndef _SINGLETHREAD
		XLOG("s-GuildList::ReturnIndex");
		EnterCriticalSection(&m_cs);
#endif
		m_Guildlist[index].init();
#ifndef _SINGLETHREAD
		LeaveCriticalSection(&m_cs);
		XLOG("e-GuildList::ReturnIndex");
#endif

		m_Freeindex.push(index);
	}
	else
	{
		_RPTF1(_CRT_WARN,"index - %d\n",index);
	}
}

char GuildList::getGuildIndex(char* guildname,int* guildindex)
{
	char result = 0;
	int index = m_GuildTree.Find(guildname);
	if(index >= 0)
	{			//ã��
		*guildindex = index;
		result =0;
	}
	else
	{					//�� ã�� ���ο� �ε����� �ϳ� �Ҵ�
		*guildindex = GetIndex();
		if(*guildindex >= 0 && *guildindex < GUILD_NUM)
		{
			m_GuildTree.Insert(guildname,*guildindex);
			result = 1;
		}
		else
		{
			result = 2;
			_RPTF0(_CRT_WARN,"guild index full\n");
		}
	}
	return result;
}

int GuildList::makeGuildAlone(char* guildname,int index,char svn)
{
	int	nIndex;
	nIndex = m_GuildTree.Find(guildname);
	if(nIndex >= 0)
	{			//ã��
		return -1;							//����
	}
	else
	{				//�� ã�� ���ο� �ε����� �ϳ� �Ҵ�
		int gindex = GetIndex();
		if(gindex >= 0 && gindex < GUILD_NUM)
		{
			m_GuildTree.Insert(guildname,gindex);
			m_Guildlist[gindex].init();

			GUILD_DATA *gd = (GUILD_DATA*)m_Guildlist[gindex].getGuildData();		//GUILD_DATA����ü ����
			gd->init();
			time_t ttime = 0;  // <djelee> : 2011.04.08 : DWORD -> time_t
			time(&ttime);
			gd->dwCreationTime = ttime;

			gd->guildcode = 0;
			memcpy(gd->strName,guildname,MAX_GUILDNAME_LEN);
			
			userinfo* ui = g_UserList->GetUser(index);
			
			if(ui)
			{
				gd->GuildChr[0].btPosition = 1;
				memcpy(gd->GuildChr[0].strName,ui->getName(),CNAME_LENGTH);
				gd->GuildChr[0].sLevel = ui->getLev();

#ifdef _GUILDINITIAL
				// 20110428 �߰�(������: ���� �̴ϼ�(2�� Ŭ����))
				gd->GuildChr[0].btClass = ui->GetGuildCharClass();
#else
				gd->GuildChr[0].btClass = ui->getClass();
#endif
			}
			//memcpy(m_Guildlist[gindex].getGuildData(),&gd,sizeof(gd));	//�ش� guild����ü�� data copy

			m_Guildlist[gindex].guildInit(g_older.getServerNumber());					//�ش� guild�� data�� ����
			ui =  g_UserList->GetUser(index);
			if(ui)
			{
				m_Guildlist[gindex].guildJoin(ui->getName(),index);
			}
			return gindex;
		}
		else
		{
			_RPTF0(_CRT_WARN,"guild index full\n");
		}
		return -1;
	}
}

int GuildList::makeGuild(char* guildname,int* indexes,char svn)
{
	int index = m_GuildTree.Find(guildname);
	int i = 0;

	if(index >= 0)
	{			//ã��
		return -1;							//����
	}
	else
	{					//�� ã�� ���ο� �ε����� �ϳ� �Ҵ�
		int gindex = GetIndex();
		if(gindex >= 0 && gindex < GUILD_NUM)
		{
			m_GuildTree.Insert(guildname,gindex);
			m_Guildlist[gindex].init();

			GUILD_DATA *gd = (GUILD_DATA*)m_Guildlist[gindex].getGuildData();		//GUILD_DATA����ü ����
			gd->init();
			time_t ttime = 0;  // <djelee> : 2011.04.08 : DWORD -> time_t
			time(&ttime);
			gd->dwCreationTime = ttime;

			gd->guildcode = 0;
			memcpy(gd->strName,guildname,MAX_GUILDNAME_LEN);
			for(i = 0; i < 6; i++)
			{
				userinfo* ui = g_UserList->GetUser(indexes[i]);
				if(ui)
				{
					gd->GuildChr[i].btPosition = i + 1;
					memcpy(gd->GuildChr[i].strName,ui->getName(),CNAME_LENGTH);
					gd->GuildChr[i].sLevel = ui->getLev();
					gd->GuildChr[i].btClass = ui->getClass();
#ifdef _RENEWAL_GUILD
					gd->GuildChr[i].bIsMaster = ui->IsMaster();
					gd->GuildChr[i].btChangeClass = ui->GetChangeClass();
					gd->GuildChr[i].dwlastjointime = ui->GetLastLeaveTime();
#endif // _RENEWAL_GUILD
				}
			}

			m_Guildlist[gindex].guildInit(g_older.getServerNumber());					//�ش� guild�� data�� ����
			for(i = 0; i < 6; i++)
			{
				userinfo* ui = g_UserList->GetUser(indexes[i]);
				if(ui)
				{
					m_Guildlist[gindex].guildJoin(ui->getName(),indexes[i]);
				}
			}
			return gindex;
		}
		else
		{
			_RPTF0(_CRT_WARN,"guild index full\n");
		}
		return -1;
	}
}

//��� ����� ���� ��ȣ�� �ް� ó���ϴ� �Լ�
void GuildList::handleGuildMake(int guildindex, char result)
{
	if(result == 1)
	{	//����� ����
		if(guildindex >= 0 && guildindex < GUILD_NUM)
		{
			m_GuildTree.Delete(m_Guildlist[guildindex].getGuildName());
			m_Guildlist[guildindex].init();
			ReturnIndex(guildindex);
		}
		else
		{
			_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
		}
	}
}

char* GuildList::getGuildData(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildData();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

char* GuildList::getGuildName(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildName();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

DWORD GuildList::getMakeTime(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMakeTime();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}
__int64 GuildList::getGuildGold(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildGold();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

#ifdef _RENEWAL_GUILD
/**
@brief guildindex�� GUILDŬ���� setGuildGold ȣ��
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param __int64 _nGGold ()
@return void
@see 
@warning 
*/
void GuildList::setGuildGold(int guildindex, __int64 _nGGold)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].setGuildGold(_nGGold);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ��� ���� ��û ó���� ������ ó������ �ӽ÷� ��û�� �̸� ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param char * cname ()
@return void
@see 
@warning 
*/
void GuildList::setGuildAdmissionName(int guildindex, char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].setGuildAdmissionName(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ��� ���� ��û ó���� ������ ó������ ������ ��û�� �̸� ������
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return char*
@see 
@warning 
*/
char* GuildList::getGuildAdmissionName(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildAdmissionName();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

/**
@brief ��� ���� �ý��� ���� ��� �ִ� �ο� ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param short _sMemMax ()
@return void
@see 
@warning 
*/
void GuildList::setMemMAX(int guildindex, short _sMemMax)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].setMemMAX(_sMemMax);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ��� ���� �ý��� ���� ��� �ִ� �ο� �ε�
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return short
@see 
@warning 
*/
short GuildList::getMemMAX(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMemMAX();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

BANKINGLOG* GuildList::getBankingLog(int guildindex,int nindex)	//����
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getBankingLog(nindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

ADMISSION* GuildList::getAdmission(int guildindex,int nindex)	//����
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getAdmission(nindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}
#endif //_RENEWAL_GUILD

void GuildList::setGuildLevelUpPoint(int _GuildIndex, int _GlevelPoint, BYTE _PointType)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		m_Guildlist[_GuildIndex].setLevelUpPoint(_GlevelPoint, _PointType);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
}

short GuildList::getGuildLevel(int _GuildIndex)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		return m_Guildlist[_GuildIndex].getGuildLevel();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
	return 0;
}

short GuildList::getGuildSpecialPoint(int _GuildIndex)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		return m_Guildlist[_GuildIndex].getSpecialPoint();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
	return 0;
}

__int64* GuildList::getGuildSpecialBuff(int _GuildIndex)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		return m_Guildlist[_GuildIndex].getSpecialBuff();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
	return 0;
}

__int64 GuildList::getGuildTimePoint(int _GuildIndex)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		return m_Guildlist[_GuildIndex].getGuildTimePoint();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
	return 0;
}

__int64 GuildList::getGuildBattlePoint(int _GuildIndex)
{
	if(_GuildIndex >= 0 && _GuildIndex < GUILD_NUM)
	{
		return m_Guildlist[_GuildIndex].getGuildBattlePoint();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",_GuildIndex);
	}
	return 0;
}

int GuildList::getNonPayment(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getNonPayment();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

int GuildList::getNonPaymentCount(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getNonPaymentCount();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

char GuildList::guildJoin(char* cname,int userindex, int guildindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].guildJoin(cname,userindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

void GuildList::guildLeave(int userindex, int guildindex,char* gname)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		if(m_Guildlist[guildindex].guildLeave(userindex))
		{
		/*	m_GuildTree.Delete(gname);
			m_Guildlist[guildindex].init();
			ReturnIndex(guildindex);*/
		}
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}


void GuildList::guildInit(int guildindex,char svn)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].guildInit(svn);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}


int GuildList::getJoinCount(int guildindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getJoinCount();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

MEMBER* GuildList::getMember(int guildindex,int mindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMember(mindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

MEMBER* GuildList::getMember(int guildindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMember();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

NOTICE* GuildList::getNotice(int guildindex,int nindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getNotice(nindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

char GuildList::checkDataLoad(int guildindex,int userindex)
{	
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].checkDataLoad(userindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

int GuildList::getMaster(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMaster();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return -1;
}

char* GuildList::getViceMaster(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getViceMaster();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

int GuildList::getMemberCount(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMemberCount();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return -1;
}

#ifdef _RENEWAL_GUILD
/**
@brief ��� �ű� �ɹ� ���� ��ƾ
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param int uindex ()
@return int
@see 
@warning 
*/
int GuildList::newMember(int guildindex,int uindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].newMember(uindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}

	return -1;
}

/**
@brief ��� ���� ��û�� ���� ���� ��û ó��
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param pGuildAdmission * pga ()
@return int
@see 
@warning 
*/
int GuildList::newMemberAdmission(int guildindex, pGuildAdmission* pga)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].newMemberAdmission(pga);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}

	return -1;
}
#else
// 20111017 ����(�̼���:���ϼ��� DBȭ ���� ��� ��� �߰� �� ��ȯ�� bool���� int�� ����)
int GuildList::newMember(int guildindex,char* cname,BYTE cclass,BYTE level)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].newMember(cname,cclass,level);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}

	return -1;
}
#endif //_RENEWAL_GUILD

void GuildList::deleteMember(int guildindex,char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].deleteMember(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

void GuildList::sendGuildMember(int guildindex,char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendGuildMember(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

void GuildList::sendGuildMember(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendGuildMember();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

void GuildList::SetData(char* data,int size,int kind, int nServerID)
{
#ifdef _RENEWAL_GUILD
	if(kind == 1)
	{
		GUILD_MEMBER* gm = (GUILD_MEMBER*) data;
		if(gm)
		{
			BYTE	strGuildName[22];

			if(g_fm.IsArenaServer())
			{
				wsprintf((LPSTR)strGuildName, "%d.%s", nServerID, gm->strName);
			}
			else
			{
				strcpy((LPSTR)strGuildName, (LPCSTR)gm->strName);
			}

			int guildindex = m_GuildTree.Find((LPSTR)strGuildName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				if (gm->btType == EN_DELETEMEMBER) //���� ���� ó�� �޽���
				{
					if (gm->btMessageType == gufexpulsion)
					{
						g_guildlist.sendGuild(guildindex,gufexpulsion,7,gm->btPosition);
					} 
					else if (gm->btMessageType == gufwithdraw)
					{
						g_guildlist.sendGuild(guildindex,gufwithdraw,6,gm->btPosition);
					}

					//20131118 ����(����ȣ: ��� ä�� ����ȭ �޽��� ó������ ��ġ ����)
					// ��� �ɹ� ���� ���� ������Ʈ
					if(m_Guildlist[guildindex].setMember(gm->GuildChr))
					{
						m_GuildTree.Delete((LPSTR)strGuildName);
						m_Guildlist[guildindex].init();
						ReturnIndex(guildindex);
					}

				}
				else if(gm->btType == EN_INSERTMEMBER)
				{
					//20131118 ����(����ȣ: ��� ä�� ����ȭ �޽��� ó������ ��ġ ����)
					// ��� �ɹ� ���� ���� ������Ʈ
					if(m_Guildlist[guildindex].setMember(gm->GuildChr))
					{
						m_GuildTree.Delete((LPSTR)strGuildName);
						m_Guildlist[guildindex].init();
						ReturnIndex(guildindex);
					}

					g_guildlist.sendGuild(guildindex,gufresinvite,3,gm->btPosition);	
				}
				else if(gm->btType == EN_UPDATEMEMBER)
				{
					//20131118 ����(����ȣ: ��� ä�� ����ȭ �޽��� ó������ ��ġ ����)
					// ��� �ɹ� ���� ���� ������Ʈ
					if(m_Guildlist[guildindex].setMember(gm->GuildChr))
					{
						m_GuildTree.Delete((LPSTR)strGuildName);
						m_Guildlist[guildindex].init();
						ReturnIndex(guildindex);
					}

					// �θ����� �Ӹ� �޽���
					if (gm->btMessageType == gufrank && gm->btDescPosition == 1)
					{
						g_guildlist.sendGuild(guildindex,gufrank,7,1);
					}
				}
			}
			else
			{
				//_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}

			if (gm->btType == EN_INSERTMEMBER) // Ÿä�� ���� ó��(��� ������ �ε� �� ���� ������ ó���κ� ����, ����� ���� ������ ������ �ε��� �ְ� �� ���� ����)
			{
				int puserindex = g_UserList->Find(gm->strCName);
				if(puserindex >= 0 && puserindex < MAX_USER)
				{
					g_UserList->GetUser(puserindex)->setguild(guildindex,gm->strName);
					g_UserList->GetUser(puserindex)->SendEventMessage(1248,MSGTYPE_EVENT,NULL,0);
				}
								
			}

		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
#else
	if(kind == 1)
	{
		GUILD_MEMBER* gm = (GUILD_MEMBER*) data;
		if(gm)
		{
			BYTE	strGuildName[22];

			if(g_fm.IsArenaServer())
			{
				wsprintf((LPSTR)strGuildName, "%d.%s", nServerID, gm->strName);
			}
			else
			{
				strcpy((LPSTR)strGuildName, (LPCSTR)gm->strName);
			}

			int guildindex = m_GuildTree.Find((LPSTR)strGuildName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{	
				if(m_Guildlist[guildindex].setMember(gm->GuildChr))
				{
					m_GuildTree.Delete((LPSTR)strGuildName);
					m_Guildlist[guildindex].init();
					ReturnIndex(guildindex);
				}
			}
			else
			{
				//_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);		
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
#endif // _RENEWAL_GUILD
	else if(kind == 2)
	{
		GUILD_NOTICE* gn = (GUILD_NOTICE*) data;
		if(gn)
		{
			int guildindex = m_GuildTree.Find(gn->strName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].setNotice(&gn->NoticeData,gn->btPosition);
			}
			else
			{
//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
	else if(kind == 3)
	{
		if(data)
		{
			BYTE	strGuildName[22];

			if(g_fm.IsArenaServer())
			{
				wsprintf((LPSTR)strGuildName, "%d.%s", nServerID, data);
			}
			else
			{
				strcpy((LPSTR)strGuildName, (LPCSTR)data);
			}

			int guildindex = m_GuildTree.Find((LPSTR)strGuildName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].Disband();
				ReturnIndex(guildindex);
				m_GuildTree.Delete((LPSTR)strGuildName);
			}
			else
			{
				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
	else if(kind == 4)
	{
		GUILD_BASE* gn = (GUILD_BASE*) data;
		if(gn)
		{
			int guildindex = m_GuildTree.Find(gn->strName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].setBase(gn);
			}
			else
			{
//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
#ifdef _RENEWAL_GUILD
	else if(kind == EN_GUILDBANKING)
	{
		int _nTmpUindex = nServerID;

		GUILD_BANKING* gb = (GUILD_BANKING*) data;
		if(gb)
		{
			int _nTmpGindex = m_GuildTree.Find(gb->strName);
			__int64 nTempGGold = m_Guildlist[_nTmpGindex].getGuildGold();
			__int64 nTempAmount = gb->BankingData.nIOGold;

			if (_nTmpGindex >= 0 && _nTmpGindex < GUILD_NUM)
			{
#ifdef _KOREA
				if (!strncmp(gb->BankingData.strWriter,"��� �ý���",CNAME_LENGTH))
#else
				if (!strncmp(gb->BankingData.strWriter,"Guild System",CNAME_LENGTH))
#endif // _KOREA
				{
					if (gb->BankingData.bIO == true) // �Ա�
					{
						if ((nTempGGold+nTempAmount) <= MAX_GOLD)
						{
							m_Guildlist[_nTmpGindex].setGuildGold(nTempGGold+nTempAmount);
						}
						else
						{
							m_Guildlist[_nTmpGindex].setGuildGold(MAX_GOLD);
						}						
					}
					else if (gb->BankingData.bIO == false) // ���
					{
						if (nTempGGold-nTempAmount >= 0)
						{
							m_Guildlist[_nTmpGindex].setGuildGold(nTempGGold-nTempAmount);
						}
						else
						{
							m_Guildlist[_nTmpGindex].setGuildGold(0);
						}
						
					}
					m_Guildlist[_nTmpGindex].sendBankingLog(&gb->BankingData);
					m_Guildlist[_nTmpGindex].sendguildgold();
				}
				else
				{
					if (_nTmpUindex == -1)	// �ٸ� ���� ó��
					{
							m_Guildlist[_nTmpGindex].setGuildGold(gb->nCurGuildGold);
							m_Guildlist[_nTmpGindex].sendBankingLog(&gb->BankingData);
							m_Guildlist[_nTmpGindex].sendguildgold();
					}
					else	// ���� ó��
					{
						userinfo* ui = g_UserList->GetUser(_nTmpUindex);

						if(ui)
						{	
							__int64 nTempPCGold = ui->GetGolds();

							if (gb->BankingData.bIO == true) // �Ա�
							{
								if ( nTempAmount >= 0 && nTempGGold >= 0 )
								{
									nTempAmount = min( nTempAmount, nTempPCGold );

									if((nTempAmount + nTempGGold) <= MAX_STASHGOLD)
									{
										nTempPCGold -= nTempAmount;
										nTempGGold += nTempAmount;
									}
									else
									{
										nTempPCGold -= (MAX_STASHGOLD-nTempGGold);
										nTempGGold = MAX_STASHGOLD;
									}

									g_guildlist.setGuildGold(_nTmpGindex, nTempGGold);

									XLOG("s-LogBankingGuild");
									BEGIN_USERLOG("", gb->BankingData.strWriter, LogBankingGuild)
										ADD_STRINGFIELD(fldGuild, gb->strName)
										ADD_BIGINTFIELD(fldPutGold, (__int64)nTempAmount)	// 20140116 ����(����ȣ : fldGold -> fldPutGold)
										ADD_BIGINTFIELD(fldGold, (__int64)nTempGGold)	
										ADD_BIGINTFIELD(fldGold, (__int64)nTempPCGold)		// 20140116 �߰�(����ȣ : �Ա��� ���� �ݾ� ���)
										END_LOG()
										XLOG("e-LogBankingGuild");

									ui->SetGolds(nTempPCGold, "guildlist::setdata 1");
						
									ui->savecharacter("userinfoGuild::PlusGuildGold");
								}
							} 
							else
							{
								if (nTempGGold < 0 || nTempPCGold < 0)
								{
									nTempGGold = 0;
									nTempAmount = -1;
								}

								if (nTempPCGold < 0)
								{
									nTempPCGold = 0;
									nTempAmount = -1;
								}

								if(nTempAmount >= 0 && nTempGGold >= 0)
								{
									nTempAmount = min( nTempAmount, nTempGGold );

									if( nTempAmount + nTempPCGold <= MAX_GOLD && nTempAmount + nTempPCGold >= 0 )
									{
										nTempGGold -= nTempAmount;
										nTempPCGold += nTempAmount;
									}
									else
									{
										nTempAmount = MAX_GOLD - nTempPCGold;
										nTempPCGold = MAX_GOLD;
										nTempGGold -= nTempAmount;
									}

									g_guildlist.setGuildGold(_nTmpGindex, nTempGGold);

									XLOG("s-LogBankingGuild");
									BEGIN_USERLOG("", gb->BankingData.strWriter, LogBankingGuild)
										ADD_STRINGFIELD(fldGuild, gb->strName)
										ADD_BIGINTFIELD(fldGetGold, (__int64)nTempAmount)	// 20140116 ����(����ȣ : fldGold -> fldGetGold)
										ADD_BIGINTFIELD(fldGold, (__int64)nTempGGold)
										ADD_BIGINTFIELD(fldGold, (__int64)nTempPCGold)		// 20140116 �߰�(����ȣ : ��� �� ���� �ݾ� ���)
										END_LOG()
										XLOG("e-LogBankingGuild");

									ui->SetGolds(nTempPCGold, "guildlist::setdata 2");

									ui->savecharacter("userinfoGuild::MinusGuildGold");
								}
							}

							m_Guildlist[_nTmpGindex].sendBankingLog(&gb->BankingData);
							m_Guildlist[_nTmpGindex].sendguildgold();
						}
						else
						{
							_RPTF0(_CRT_WARN,"guildbanking - can't find user data\n");
						}
					}
				}
			}
			else
			{
				_RPTF0(_CRT_WARN,"guildbanking - can't find guild data\n");
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"guildbanking - null data\n");
		}
	}
	else if(kind == EN_GUILDSTATE)
	{
		GUILD_STATE* gms = (GUILD_STATE*) data;
		if(gms)
		{
			int guildindex = m_GuildTree.Find(gms->strGName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				if (EN_LOGINMEMBER == gms->btStateType)
				{
					g_guildlist.sendGuild(guildindex,gREfmemberLogin,0,gms->btPosition);
				} 
				else if (EN_LOGOUTMEMBER == gms->btStateType)
				{
					g_guildlist.sendGuild(guildindex,gREfmemberLogout,0,gms->btPosition);
				}
				else if (EN_BROADCASTCHAT == gms->btStateType)
				{
#ifdef _KOREA
					g_guildlist.guildChat(guildindex,0,gms->strChatMsg,gms->strCName);
#else
					g_guildlist.guildChat(guildindex,-1,gms->strChatMsg,gms->strCName);
#endif
				}
			}
			else
			{
				//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
#endif //_RENEWAL_GUILD
	else if (kind == EN_GUILDLEVELUPPROCESS)
	{
		int _nTmpUindex = nServerID;

		GUILD_LEVELUP_PROCESS* pglp = (GUILD_LEVELUP_PROCESS*) data;
		if(pglp)
		{
			int guildindex = m_GuildTree.Find(pglp->strName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].setGuildLevleUp(pglp);
			}
			else
			{
				//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
	else if (kind == EN_GUILDSAVELEVELUPPOINT)
	{
		int _nTmpUindex = nServerID;

		GUILD_LEVELUP_POINT* pglp = (GUILD_LEVELUP_POINT*) data;
		if(pglp)
		{
			int guildindex = m_GuildTree.Find(pglp->strName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].setLevelUpPoint(pglp->dwLevelUpPoint, pglp->btPointType);
			}
			else
			{
				//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
	else if (kind == EN_GUILDSAVESPECIALPOINT)
	{
		int _nTmpUindex = nServerID;

		GUILD_SPECIAL_POINT* pgsp = (GUILD_SPECIAL_POINT*) data;
		if(pgsp)
		{
			int guildindex = m_GuildTree.Find(pgsp->strName);
			if(guildindex >= 0 && guildindex < GUILD_NUM)
			{
				m_Guildlist[guildindex].setSpecialPoint(pgsp->sGuildSpecialPoint, pgsp->nGuildSpecialBuff, pgsp->btType);
			}
			else
			{
				//				_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
			}
		}
		else
		{
			_RPTF0(_CRT_WARN,"null data\n");
		}
	}
}

#ifdef _RENEWAL_GUILD
BANKINGLOG* GuildList::setBankingLog(int guildindex,pGuildBankingLog* _pgb, int uindex) //����
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].setBankingLog(_pgb, uindex);
	}
	else
	{
		_RPTF1(_CRT_WARN, "guildindex - %d\n", guildindex);
	}
	return NULL;
}

ADMISSION* GuildList::setAdmission(int guildindex,pGuildAdmission* _pga, int uindex) //���� ���
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].setAdmission(_pga, uindex);
	}
	else
	{
		_RPTF1(_CRT_WARN, "guildindex - %d\n", guildindex);
	}
	return NULL;
}
#endif //_RENEWAL_GUILD

/**
@brief ��� ���� ���� �Լ�
@date 20111020
@author �̼���(bestdev@gameonstudio.co.kr)
@param guildindex(��� �ε���, �������� �����ϴ� �ε���)
@param &pos(��� ���� ��ġ)
@param *notice(��� ���� ����)
@param *cname(��� ���� �ۼ��� ĳ����)
@return NOTICE*(��� ���� ����), NULL(��尡 ����)
*/
NOTICE* GuildList::setNotice(int guildindex, int &pos, char *notice, char *cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].setNotice(pos, notice, cname);
	}
	else
	{
		_RPTF1(_CRT_WARN, "guildindex - %d\n", guildindex);
	}
	return NULL;
}

void GuildList::deleteNotice(int guildindex,int pos)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].deleteNotice(pos);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

#ifdef _RENEWAL_GUILD
/**
@brief ��� �ڱ� �α� ����Ʈ ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param int kind ()
@return void
@see 
@warning 
*/
void GuildList::sendBankingLogList(int guildindex, int kind)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendBankingLogList(kind);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ��� ���� ��û ����Ʈ ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param int kind ()
@return void
@see 
@warning 
*/
void GuildList::sendAdmissionList(int guildindex, int kind)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendAdmissionList(kind);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ���� �̸����� �ش� ����� ���� ��û ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@param char * cname ()
@return void
@see 
@warning 
*/
void GuildList::deleteAdmission(int guildindex, char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].deleteAdmission(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

/**
@brief ��� �ڱ� ����
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return void
@see 
@warning 
*/
void GuildList::sendGuildGold(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendguildgold();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}
#endif //_RENEWAL_GUILD

void GuildList::sendNotice(int guildindex,int pos)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].sendNotice(pos);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

bool GuildList::changeDesignate(int guildindex,int pos, char* des)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].changeDesignate(pos,des);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return false;
}

bool GuildList::changerank(int guildindex, int pos1, int pos2)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].changerank(pos1,pos2);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return false;
}

bool GuildList::expulsion(int guildindex, int pos)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].expulsion(pos);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return false;
}

bool GuildList::withdraw(int guildindex, char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].withdraw(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return false;
}

void GuildList::Disband(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_GuildTree.Delete(m_Guildlist[guildindex].getGuildName());
		m_Guildlist[guildindex].Disband();
		ReturnIndex(guildindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
}

void GuildList::checkMemberChange(int guildindex,int sit)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		m_Guildlist[guildindex].checkMemberChange(sit);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
}

int GuildList::getMemberMap(int guildindex,int pos)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getMemberMap(pos);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return -1;
}

void GuildList::guildChat(int guildindex,int userindex, char* msg,char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].guildChat(userindex,msg,cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
}

void GuildList::sendGuild(int guildindex, BYTE subheader,DWORD data1, DWORD data2)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].sendGuild(subheader,data1,data2);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
}

int GuildList::getMemberPos(int guildindex, char* cname)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getMemberPos(cname);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return -1;
}

int GuildList::getMemberPos(int guildindex, int userindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getMemberPos(userindex);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}	
	return -1;
}

bool GuildList::memberLevelUp(int guildindex,int userindex,BYTE level)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].memberLevelUp(userindex,level);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return false;
}

char* GuildList::getGuildNotice(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getGuildNotice();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

#ifdef _RENEWAL_GUILD
/**
@brief ��� �ڱ� ����³��� ���ϰ� DB�ε�� ���� �޸�
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return char*
@see 
@warning 
*/
char* GuildList::getGuildBankingLog(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildBankingLog();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

/**
@brief ��� ���� ��û���� ���ϰ� DB�ε�� ���� �޸�
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return char*
@see 
@warning 
*/
char* GuildList::getGuildAdmission(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildAdmission();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

/**
@brief ��� �ڱ� ����³��� ����Ʈ DB�ε�� ���� �޸�
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return char*
@see 
@warning 
*/
char* GuildList::getGuildBankingLogList(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildBankingLogList();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

/**
@brief ��� ���� ��û ����Ʈ DB�ε�� ���� �޸�
@date 2013/03/19
@author ����ȣ(toxin2k@neowiz.com)
@param int guildindex ()
@return char*
@see 
@warning 
*/
char* GuildList::getGuildAdmissionList(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].getGuildAdmissionList();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

#endif //_RENEWAL_GUiLD

char* GuildList::getGuildMember(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getGuildMember();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return NULL;
}

DWORD GuildList::getGuildCode(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getGuildCode();
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

void GuildList::setGuildCode(int guildindex,DWORD gcode)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].setGuildCode(gcode);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

DWORD GuildList::getUnionCode(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 return m_Guildlist[guildindex].getUnionCode();
	}
	else
	{
	//	_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return 0;
}

void GuildList::setUnionCode(int guildindex,DWORD ucode)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].setUnionCode(ucode);
	}
}

void GuildList::SendData(int guildindex,void* data,int size)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].SendData(data,size);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
}

void GuildList::ExpeledFromUnion(int guildindex)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		 m_Guildlist[guildindex].ExpeledFromUnion();
	}
}

void GuildList::SendListToCMS(char* gname)
{
	int index = m_GuildTree.Find(gname);
	if(index >= 0 && index < GUILD_NUM)
	{
		m_Guildlist[index].SendListToCMS();
	}
}

#ifdef _GUILDINITIAL

/**
@brief ��� ����Ʈ���� 2�� Ŭ���� ����
@date 20110511
@author ������(jongi@gameonstudio.co.kr)
@param guildindex(��� �ε���)
@param userindex(���� �ε���)
@param cclass(ĳ���� Ŭ����)
@return true(���� ����), false(���� ����)
*/
bool GuildList::MemberSecondClassNormal(int guildindex,int userindex,BYTE cclass)
{
	if(guildindex >= 0 && guildindex < GUILD_NUM)
	{
		return m_Guildlist[guildindex].MemberSecondClassNormal(userindex,cclass);
	}
	else
	{
		_RPTF1(_CRT_WARN,"guildindex - %d\n",guildindex);
	}
	return false;
}

/**
@brief ��忡�� 2�� Ŭ���� ����
@date 20110511
@author ������(jongi@gameonstudio.co.kr)
@param userindex(���� �ε���)
@param cclass(ĳ���� Ŭ����)
@return true(���� ����), false(���� ����)
*/
bool Guild::MemberSecondClassNormal(int userindex,BYTE cclass)
{
#ifdef _RENEWAL_GUILD
	for(int i = 0; i < MAX_POSITION_NUM; i++)
#else
	for(int i = 0; i < 40; i++)
#endif //_RENEWAL_GUILD
	{
		if(m_guilddata.GuildChr[i].btPosition > 0)
		{
			if(m_nMembermap[i] == userindex)
			{
				m_guilddata.GuildChr[i].btClass = cclass;
				return true;
			}
		}
	}
	return false;
}

#endif

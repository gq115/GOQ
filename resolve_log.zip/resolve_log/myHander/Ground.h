// Ground.h: interface for the CGround class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GROUND_H__B4DCB8FF_048C_4782_886C_F7E3C03814A1__INCLUDED_)
#define AFX_GROUND_H__B4DCB8FF_048C_4782_886C_F7E3C03814A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "value.h"
//#include "LList.h"
#include "SQUE.h"
#include "DBlock.h"
#include "GroundThread.h"
#include "struct.h"
#include "item.h"
#include "bitmap.h"

typedef enum _tagGroundHeaeder
{
	grhdead = 1,
	grhalive,
	grhleave,
	grhout,
	grhin,
	grhmove,
	grhitemin,
	grhitemout,
	grhnotice,
	grhchat,
	grhshout,
	grhmovezone,
	grhgetcl,
	grhuseskill,
	grhuseoskill,
	grhnoticept,
	grhnoticeblock,
	grhsetdamage,
	grhjout,
	grhoutnin,
	grhclearblock,
	grhchecknpc,
	grhteleport,
	grhbeholderin,
	grhsmallnotice
};

typedef enum _taginstate
{
	isdefault =0,
	isalive,
	isportal,
	isteleport,
	issummon
};

typedef struct _tagPointnShort
{
	Point pt;
	short st;
}pns;

typedef struct _tagPointn2Dword
{
	Point pt;
	DWORD data1;
	DWORD data2;
}pn2d;

typedef struct _tagPointn64Int
{
	Point pt;
	__int64 data;
}pn64i;

typedef struct _tagUseSkillStruct
{
	int skillcode;
	Point target;
	int areatype;
	int slvl;
	char pk;
}uss;


class CLList
{
private:
	int m_iUserIndex; // 0 ~ MAX_USER ( User ) , -1 ~ ���� ( NPC ), MAX_USER ~ MAX_USER+MAX_SUMMON_NPC (summon)
	int m_iBlockIndex;
	int m_iZoneIndex;
	int m_BangIndex;

	CLList* m_pPrevious;
	CLList* m_pNext;
	SOCKET  sck; // <djelee> : DWORD -> SOCKET

public:
	CLList(){
		m_pPrevious = m_pNext = NULL;
		m_iUserIndex = m_iBlockIndex = m_iZoneIndex = -1;
		m_Checknum = -1;
		m_BangIndex = 0;
		m_dwThreadID = 0;
		chrnum = 0;
		sck = 0;
	};

	~CLList(){};

	int GetUserIdx() { return m_iUserIndex; }
	int GetBlockIdx() { return m_iBlockIndex; }
	int GetZoneIdx() { return m_iZoneIndex; } 

	CLList* GetPrev(){ return m_pPrevious; }
	CLList* GetNext(){ return m_pNext; }

	void SetPrev(CLList* pP){ m_pPrevious = pP; }
	void SetNext(CLList* pN){ m_pNext = pN; }

	void SetUserIdx(int ui) { m_iUserIndex = ui; }
	void SetBlockIdx(int bi) { m_iBlockIndex = bi; }
	void SetZoneIdx(int zi) { m_iZoneIndex = zi; }

	void SetSocket(SOCKET s) {sck = s;}; // <djelee> : DWORD -> SOCKET
	SOCKET GetSocket(){return sck;};     // <djelee> : DWORD -> SOCKET

	DWORD m_dwThreadID;
	DWORD chrnum;

	LONGLONG	m_Checknum;
};


class CBlock
{
private:
	int m_iChrNum;	// ĳ���� ��.
	int m_NPCNum;
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	int m_SummonNum;
///////////////////////////////////////////////////////////////////////////////////////

	CLList* m_pChrFirst; // ĳ���� ��ũ�� ����Ʈ�� ù��° �ּ�.
	CLList* m_pChrLast;	 // ĳ���� ��ũ�� ����Ʈ�� ������ �ּ�.
	CLList* m_NPCFirst;
	CLList* m_NPCLast;
	CLList* m_AdminFirst;
	CLList* m_AdminLast;
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	CLList* m_SummonFirst;
	CLList* m_SummonLast;
///////////////////////////////////////////////////////////////////////////////////////
	item* m_pItemFirst;	// �ٴڿ� ������ ��ũ�� ����Ʈ�� ù��° �ּ�.
	item* m_pItemLast;	// �ٴڿ� ������ ��ũ�� ����Ʈ�� ������ �ּ�.

	bool open;

public:
	CBlock() {
		Init();
	}

	SObject object;
	int objectindex;
	void Init() {
		m_iChrNum = 0;
		m_NPCNum = 0;
		m_SummonNum = 0;     // Ricky Added 2003.1.3
		m_pChrFirst = m_pChrLast = NULL;
		m_NPCFirst = m_NPCLast = NULL;
		m_SummonFirst = m_SummonLast = NULL;    // Ricky Added 2003.1.3
		m_AdminFirst = m_AdminLast = NULL;
		m_pItemFirst = m_pItemLast = NULL;
		open = true;

		// 20120511 �߰�(�̼���:CBlock ��� ���� �ʱ�ȭ)
		ZeroMemory(&object, sizeof(object));
		objectindex = 0;
	}
	
	int GetChrNum() { return m_iChrNum; }
	int GetNPCNum() { return m_NPCNum; }
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	int GetSummonNum() { return m_SummonNum; }
///////////////////////////////////////////////////////////////////////////////////////

	CLList * GetChrFirst() { return m_pChrFirst; }
	CLList * GetChrLast() { return m_pChrLast; }
	CLList * GetNPCFirst() { return m_NPCFirst; }
	CLList * GetNPCLast() { return m_NPCLast; }
	CLList * GetAdminFirst() { return m_AdminFirst; }
	CLList * GetAdminLast() { return m_AdminLast; }
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	CLList * GetSummonFirst() { return m_SummonFirst; }
	CLList * GetSummonLast() { return m_SummonLast; }
///////////////////////////////////////////////////////////////////////////////////////
	item * GetItemFirst() { return m_pItemFirst; }
	item * GetItemLast() { return m_pItemLast; }

	void SetChrFirst(CLList * pChrFirst) { m_pChrFirst = pChrFirst; }
	void SetChrLast(CLList * pChrLast) { m_pChrLast = pChrLast; }
	void SetNPCFirst(CLList * pNPCFirst) { m_NPCFirst = pNPCFirst;}
	void SetNPCLast(CLList * pNPCLast) { m_NPCLast = pNPCLast;}
	void SetAdminFirst(CLList * pAdminFirst) { m_AdminFirst = pAdminFirst; }
	void SetAdminLast(CLList * pAdminLast) { m_AdminLast = pAdminLast; }
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	void SetSummonFirst(CLList * sFirst) { m_SummonFirst = sFirst; }
	void SetSummonLast(CLList * sLast) { m_SummonLast = sLast; }
///////////////////////////////////////////////////////////////////////////////////////

	void SetItemFirst(item * pItemFirst) { m_pItemFirst = pItemFirst; }
	void SetItemLast(item * pItemLast) { m_pItemLast = pItemLast; }

	void SetChrNum(int iChrNum) { m_iChrNum = iChrNum; }
	void AddChrNum(){m_iChrNum++;}
	void SubChrNum(){if(m_iChrNum>0)m_iChrNum--;}
	void AddNPCNum(){m_NPCNum++;}
	void SubNPCNum(){if(m_NPCNum>0)m_NPCNum--;}
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	void AddSummonNum(){m_SummonNum++;}
	void SubSummonNum(){if(m_SummonNum>0)m_SummonNum--;}
///////////////////////////////////////////////////////////////////////////////////////

	bool isOpen(){return open;};
	void setOpen(bool value){open = value;};
};

class CGround : public CThread
{
private:
	CGroundThread m_gThread[MAX_GROUND_THREAD];
	int m_gThreadNum;
	CBlock m_Block[MAX_ZONE][BLOCK_NUM]; // ����
//	CLList m_Chrlist[MAX_USER_AND_NPC];// �����ε����� ���� �ִ� linked list
	CLList m_Chrlist[MAX_USER_AND_NPC+MAX_SUMMON_NPC];		// Ricky Changed 2003.1.3
	DWORD m_ChrlistOutFlags[(MAX_USER_AND_NPC+MAX_SUMMON_NPC) / 32 + 1]; //UJ 110729, m_Chrlist lookup ����ȭ

	short aroundBlockList[MAX_ZONE][BLOCK_NUM][AROUND_BLOCK_NUM+1];
	BitMap bitmap[MAX_ZONE];
	BitMap bitmapr[MAX_ZONE];

	void MoveIn(int userindex1, int userindex2,char instate);		//block �̵��� �ʿ� ������ �̵��ϴ� ĳ���� ������ �ش�.
	void MoveNPCIn(int npcindex, int userindex,char instate = isdefault);
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	void MoveSummonIn(int sindex, int userindex,char instate);
///////////////////////////////////////////////////////////////////////////////////////

	void MoveOut(int userindex1, int userindex2);		//block �̵��� �ʿ� ������ ĳ���Ͱ� �������� �˷��ش�.
	void SayMoveIn(int userindex,char instate);
	void SayMoveOut(int userindex, bool isleave);
	void MoveBlock(int userindex, int oldblockindex);			//block �̵��� �ʿ� ������ �������� �̵��� ĳ���Ϳ��� �˷��ش�.
	void ItemIn(int itemindex, int userindex1);					//�ش� ������ item�� ���������� �˷��ش�.
	void ItemOut(int itemindex, int userindex1);					//�ش� �������� item�� ��������� �˷��ش�.
	void SayItemIn(int itemindex, int blockindex,int zone);
	void SayItemOut(int itemindex, int blockindex,int zone);

	int _Out(int iChrIdx);
	int _In(int iChrIdx, Point pt, short nZoneIdx);
	void PCBlockIn(int _iChrIdx,int iBlkIdx,int nZoneIdx);
	void NPCBlockIn(int _iChrIdx,int iBlkIdx,int nZoneIdx);
	void AdminBlockIn(int _iChrIdx,int iBlkIdx,int nZoneIdx);
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	void SummonBlockIn(int _iChrIdx, int iBlkIdx, int nZoneIdx);
	void SummonBlockOut(int _iChrIdx, int iBlkIdx, int nZoneIdx);
///////////////////////////////////////////////////////////////////////////////////////

	void PCBlockOut(int _iChrIdx,int iBlkIdx,int nZoneIdx);
	void NPCBlockOut(int _iChrIdx,int iBlkIdx,int nZoneIdx);
	void AdminBlockOut(int _iChrIdx,int iBlkIdx,int nZoneIdx);

	void checkCharacterList(int userindex);
	bool checkingoverlap(int temp, int index,int zone);

	void EnterBlockCS(char *tmp);
	void LeaveBlockCS(int block, int tindex);
	int blockSqrt;
	int blockNum;
	int aroundBlockNum;
	int aroundRange;

	void setAroundBlock();
	static void Run(void* LPARAM);
	int DoSomething();
	//SelectQUE	m_sque;
	//DataBlock std;

	void dead(int index);
	void alive(int index,Point pt,short zone);
	
	void movezone(int index, pn2d *pData);
	int out(int index);
	int in(int index,Point pt,short zone,char instate);
	int justout(int index);
	int move(int index,Point pt,short zone);
	void itemin(int index,Point pt,short zone);
	bool itemout(int index,Point pt,short zone);
	void notice(void* dblock);
	void notice(void* dblock, int size);
	void notice(void* dblock, Point pt, int zone);
	void notice(void* dblock, int blockindex, int zone);
	void smallnotice(void* dblock);
	void chat(char* msg,int userindex,char* cname);
	void shout(char* msg,int userindex,char* cname);
	// 20140115 �߰�(���ٿ�:Ư�� ������ �������� ������ ������)
	void chatqualified(char* _pcMsg, int _nUserIndex, char* _pcName, int _nClassType, int _nMinLevel, int _nMaxLevel);
	void useskill(int skillcode, Point target, int arearange, int slvl, int userindex,char pk);
	void useoskill(int skillcode, Point target, short slvl, short zone);
	void saymove(int userindex,Point pt,int zone);
	void setdamage(int userindex, __int64 damage, int _nAttacker = 0 );
	void clearblock(Point pt,short zone);
	void checknpc(Point pt, short zone,int index);
	void beholderin(Point pt,int userindex);

	//void* GetNextWork();
	bool AddWork(void* data,int zone);
	bool AddWork(void* data,int zone, int size);
	CRITICAL_SECTION	m_cs;
	//UJ 110729, _Out() ���ο� ũ��Ƽ�ü����� ������ �����Ƿ� �̰� �ʿ���� --start
	//// 20070727 �߰�(�̼���:�׶��� ������ ũ��Ƽ�ü���)
	//CRITICAL_SECTION m_Critical;
	//UJ --end
	// 20080516 �߰�(�̼���:pcinout���� ũ��Ƽ�ü���)
	CRITICAL_SECTION m_pcinout_critical;
	DWORD tcountsum;

	int GetThreadNum(DWORD tid);
	void initAssignedThread();
	int AssignedThread[MAX_ZONE];
	int zoneUserCount[MAX_ZONE];
	int zoneNPCCount[MAX_ZONE];
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	int zoneSummonCount[MAX_ZONE];
///////////////////////////////////////////////////////////////////////////////////////

	void gch(int iChrIdx);
//	void getcharacterlist(int iChrIdx, int aiUserList[1000], int * pUserNum,
//							       int aiNPCList[1000], int * pNPCNum);

//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	void getcharacterlist(int iChrIdx, int aiUserList[2000], int * pUserNum,
									int aiNPCList[1000], int * pNPCNum);
/*	void ngetcharacterlist(int iChrIdx, int aiUserList[2000], int * pUserNum,
							       int aiNPCList[1000], int * pNPCNum);
	void sgetcharacterlist(int iChrIdx, int aiUserList[2000], int * pUserNum,
							       int aiNpclist[1000], int * pNPCNum);
*/
///////////////////////////////////////////////////////////////////////////////////////

	bool PCLoopCheck(CLList*, int zone,int block, LONGLONG counter);
	bool NPCLoopCheck(CLList*,int zone, int block, LONGLONG counter);
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	bool SummonLoopCheck(CLList*,int zone, int block, LONGLONG counter);
///////////////////////////////////////////////////////////////////////////////////////

	bool ItemLoopCheck(item*, int zone, int block, LONGLONG counter);

	void checkobject(int userindex, int zone,int objectindex);
	
	void LockAllThread();
	void UnlockAllThread();
	void ResetLinkedList();
	bool IsInRange(int areatype,Point castpoint1,Point castpoint2,Point targetpoint,int arearange,int distance, float mv, float nv);

	int servercount;

	// 20081230 �߰�(�̼���:���� ���� �����ϴ� ������ ����)
	int m_ZoneItemCnt[MAX_ZONE];

public:
	void EnableThread();
	int leave(int index);	// 20061031 ����(�̼���:��ġ�̵�, private -> public)
	BOOL NoticeMoveOut(int nUserIndex, int nNPCIndex);
	BOOL NoticeMoveIn(int nUserIndex, int nNpcIndex);
	void OutInDirect(int nIndex, Point pt, short zone, char instate);
	void Frame();
	void ChatDirect(LPSTR strMsg, int nIndex, LPSTR strName);
	void StopThread();
	void DoWork(void* data);
	void SetSocket(int userindex,SOCKET socket); // <djelee> : DWORD -> SOCKET
	void InitCharacterList(int userindex);
	void Dead(int iChrIdx);
	void Alive(int iChrIdx, Point pt, short nZoneIdx);

	// 20060411 ����(�̼���:�� �̵� �� ȭ�� �ޱ� �⺻�� ���� : int nDirection = 0)
	void MoveZone(int userindex,short movezoneindex,Point movingPoint, int nDirection);
	void Join(int userindex,int zone, Point pt);
	int Leave(int iChrIdx);
	int Out(int iChrIdx);
//	int Out(int iChrIdx,int zone)
	int JustOut(int iChrIdx);
	int OutnIn(int userindex,Point pt,short zoneindex,char instate);
	int Teleport(int userindex, Point pt, short zoneindex, char instate);
	//int In(int iChrIdx, Point pt, short z, short nZoneIdx);
	int In(int iChrIdx, Point pt, short nZoneIdx,char instate);
	//int MoveOne(int iChrIdx, Point pt, short z, short nZoneIdx);
	int MoveOne(int iChrIdx, Point pt, short nZoneIdx);
	void ItemIntoGround(int index,Point pt,short nZoneIdx);
	void ItemOutfromGround(int index,Point pt, short nZoneIdx);
	void Chat(char *msg,int userindex,char* cname = NULL);
	void Shout(char *msg,int userindex,char* cname = NULL);
	void NoticebyUserindex(void *dblock,Point pt,int userindex);
	void Notice(void *dblock);
	void Notice(void *dblock,Point pt,int zone);
	void Notice(void *dblock,int blockindex,int zone);
	void Notice(void *dblock,BYTE header,int userindex);
	void SmallNotice(void *dblock,BYTE header,int userindex,int zone =-1);
	void UseSkill(int skillcode,Point target,int arearange,int slvl,int userindex,char pk);
	void UseObjectSkill(int skillcode, Point target,short zone,short slvl);
	void NPCCheck(int userindex, Point pt, int zone);
	void SetDamage(int userindex, __int64 damage, int _nAttacker = 0);

	void ClearBlock(int x, int y, short zone);
	void BeholderIn(Point pt,short zone,int userindex);

	//void Notice(void* dblock,int userindex,int size);
	int GetBlockIndex(int userindex);
	void GetCharacterList(int iChrIdx);
	int GetThreadStateString(char* buf);
	CGround();
	virtual ~CGround();
	void RunThread();
	void InsertListViewItems(HWND hwndListView);
	void SetAssignedThread(int zone,int thread);
	int GetAssignedThread(int zone);
	int GetUserCount(int zone);
	int* GetZoneUserCount(){return zoneUserCount;};
	int GetNPCCount(int zone);
	void InitZoneUserCount( int _nZone );
//////////////////////////// Ricky Added 2003.1.3 /////////////////////////////////////
	int GetSummonCount(int zone);
///////////////////////////////////////////////////////////////////////////////////////
	void AddGroundThread();
	void CheckRoom();
	bool CheckRoom(int zone, int roomindex);
	int GetRoomIndex(int zone);
	bool checkbitmap(Point a,int zone);
	bool checkbitmapr(Point a,int zone);

	bool CheckBitmap(int zone, Point *curpos, Point *nextpos);
	bool CheckBitmapNotCheckCurrentBlock(int zone, Point *curpos, Point *nextpos);

#ifdef _OCCUPATION_RENEWAL
	// 20140414 ����(����ȣ: ���� Zone, Zoner �̿��� ��Ʈ������ ��ü �����ϰ� �Լ� ����)
	void loadbitmap(int zone, char InCnt = 0);
	void loadbitmapr(int zone, char InCnt = 0);
#else // _OCCUPATION_RENEWAL
	void loadbitmap(int zone);
	void loadbitmapr(int zone);
#endif // _OCCUPATION_RENEWAL

	void AddObject(int zone,SObject object);
	void ChangeObject(int zone, Point pt);
	void ChangeObject(int zone, int roomindex);
	//winpro insert
	BOOL ZoneKill(int nZoneNumber);
	BOOL ZoneReset(int nZoneNumber);
	BOOL ZoneNpcOut(int nZoneNumber, int nOpt);
	BOOL ZoneNpcActive(int nZoneNumber, BOOL bActive);

	int getServerCount(){return servercount;};
	void setServerCount(int svn){servercount = svn;};

	// 20081230 �߰�(�̼���:���� ���� �����ϴ� ������ ����)
	int GetZoneItemCount(int nZone) { return m_ZoneItemCnt[nZone]; };

#ifdef _STORYQUEST
	// 20101103 �߰�(������:��Ż ���� ����Ʈ ���� ���� ���� ���� �� ��� �� �̵� ó�� �Լ� ����)
	void SetUserLossResi(int nUserIdx, int nMoveZone);
#endif

#ifdef _QPS
	CQpsLog m_kQps;
#endif

	void MoveOutParty(int userindex1, int userindex2);//block �̵��� �ʿ� ������ ĳ���Ͱ� �������� �˷��ش�.

	// 20140115 �߰�(���ٿ�:Ư�� Ŭ���� �Ǵ� Ư�� ���� �������Ը� ������ ������.)
	void ChatDirect(LPSTR strMsg, int nIndex, LPSTR strName, int nClassType, int nMinLevel, int nMaxLevel);

#ifdef _ATTACH_ITEM_SKILL
	int GetFirstIndexInRange(int _nUserIndex, char _chPK, Point _ptTargetpoint, int _nArearange, int _nTargetrange);
#endif	// _ATTACH_ITEM_SKILL


#ifdef _REMAIN_LOG
	bool	IsRemainLog ( int _nZoneID, __int64 _n64CID );
#endif //
};

#endif // !defined(AFX_GROUND_H__B4DCB8FF_048C_4782_886C_F7E3C03814A1__INCLUDED_)

#pragma once
#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <map>
#include <algorithm>
#include <atlcoll.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "itemhander.h"
#include "commonhander.h"
#include "myConmon.h"
#include "npcinfo.h"

class GQGrowth
{
public:
	GQGrowth();
	~GQGrowth();

	SGrowth growthitemlist[MAX_GROWTHITEM];
	int 	growthitemindex[MAX_BASE_ITEM_CODE];
	int 	nextbitemindex[MAX_BASE_ITEM_CODE];
	int 	maxgrowthitem;
	void makegindex();
	void LoadGrowth();
	void WriteGrowth();

	CNewGrowthTable			m_cNewGrowth;
	void GQOpen();
	void GQWrite();
};


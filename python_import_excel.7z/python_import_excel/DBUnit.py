#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import sys
import pymssql
import traceback
import datetime
import _mssql
print(_mssql.__version__)
import socket
import uuid
import decimal
print(decimal.__version__)


class DBUnit:
	def __init__(self,user=None,passwd=None,host=None,database=None ,contype = None):
		try:			
                    self.connection = pymssql.connect(host=host, user = user, password =passwd, database=database)
		except Exception(e):
			print (e)
			msg = "Could not connect to DB server."
			print (msg)
			self.connection =False
			errtips = traceback.format_exc() 
                        print(errtips)
			
			
	def conn(self):
		return self.connection 
	def get_conn(self):
		return self.connection
		
	def close(self):
		self.connection.close()
		self.connection = False
        
	def __del__(self):
		if self.connection != False :
			self.connection.close()

	def exec_sql(self,Sql,param=None):
		if self.connection == False :
			print ("the connection is wrong") 
			return	False
		try:
			cursor = self.connection.cursor()
			if param==None:
				cursor.execute(Sql)
			else:
				cursor.execute(Sql,param)
			return cursor 
		except Exception(e):
				print (e)
				cursor.close()
				errtips = traceback.format_exc() 
				print (errtips)
				return False
			
	def exec_querysql(self,Sql,param=None):
		return self.exec_sql(Sql,param)
						
	def commit(self):
		self.connection.commit()





if __name__ == '__main__':
	print ('hello ,my friend ' )
        db = DBUnit('sa','123','127.0.0.1','dr2_def','MSSQL') 
	# db = DBUnit('root','123','localhost','test') 
	if db.connection == False:
		print ('wrong con')
	else:
		rs = db.exec_querysql("select * from TB_DefRes_Item")

                print(rs.description)

                while True:
                    data =  rs.fetchone()
                    if not data:
                        break
                    print(data)




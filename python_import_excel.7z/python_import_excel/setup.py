from distutils.core import setup
import py2exe
import sys

includes = ["encodings", "encodings.*"]
sys.argv.append("py2exe")
options = {"py2exe": {
			"compressed": 1,
			"optimize": 2,
			"ascii": 0,
			"bundle_files": 1,
		}
}
setup(
    version = "",
    description = "",
    name = "",
    options = options,
    zipfile=None,
    console = [{"script":'ExcelExtractor.py', }])


#!/usr/bin/env python
# -*- coding: utf-8 -*-
#  thanks for  https://github.com/praveenmax/Excel2MySQL-Importer/tree/master/src

import xlrd
import datetime
import read_config

print(read_config.excelConfigs)

import _mssql
print('sqlserver version ' + _mssql.__version__)


#记录日志文件
log = open('log.txt','w')
def Log(content):
    if(type(content) != str):
        content = str(content)
    log.write(content+"\n")
    log.flush()

Log(datetime.datetime.now())

from DBUnit import DBUnit
print('begin connect db host{0} user:{1}'.format(read_config.DB_HOST,read_config.DB_USER))
db = DBUnit(read_config.DB_USER,read_config.DB_PWD,read_config.DB_HOST) 

#用于检测表里面是不是有 identity 插入的时候需要关闭
CHECK_HAS_IDENTI = "select OBJECTPROPERTY(OBJECT_ID('dbo.{0}'),'TableHasIdentity')"

#每次从列表中取出 count 个数据的 迭代器
#返回新的列表 , 当前数据索引 , 新列表的数量
def listIter(_list,count):
    current_index = 0
    while True:
        sub_list = _list[current_index:current_index+count]
        yield sub_list,current_index,len(sub_list)
        current_index = current_index + count

        if current_index >= len(_list):
            break


#一个 excel 文件对应 数据库里面的表结构
class Excel2TableInfo():
        def __init__(self,tbName,header_list,data_list):
            self.tbName = tbName
            self.header_list = header_list
            self.data_list = data_list #[ (row data)] 一个列表里面存放的是每行的元祖数据,sql 的 param插入方式只支持元祖

        #根据表名字和header来生成插入sql
        def create_insert_header_sql(self):
          headers = ','.join(['[{0}]'.format(x) for x in self.header_list])
          _temp = ['%s'] * len(self.header_list) # sqlserver 用 %s ,mysql 用 ? 来当占位符
          placeheaders  = ','.join(_temp)

          sql = "INSERT INTO {tbName} ({headers})  VALUES({placeheaders})".format(tbName = self.tbName,headers = headers,placeheaders = placeheaders)
          return sql 

        def show_info(self,show_data = False):
            print('the tbName',self.tbName)
            print('the header_list',self.header_list)
            print(self.create_insert_header_sql())
            if show_data:
                print('the data_list',self.data_list)


        #检测表是否含有 TableHasIdentity 属性
        def checkHasIdentity(self,conn,tbName):
            c = conn.cursor()
            check_sql = CHECK_HAS_IDENTI.format(tbName)
            c.execute(check_sql)
            ret = int(c.fetchone()[0])
            return ret == 1


        def begin_insert(self,conn,databaseName):
            #根据选择的数据库然后 开始插入数据
            c = conn.cursor()
            #插入之前先清空表
            c.execute('use  '+databaseName)
            conn.commit()
            c.execute('delete from '+self.tbName)
            conn.commit()

            closeIdentity = self.checkHasIdentity(conn,self.tbName)
            if closeIdentity:
                c.execute('SET IDENTITY_INSERT '+self.tbName + " ON ")
                conn.commit()

            ite = listIter(self.data_list,read_config.INSERT_COUNT)
            total_insert = 0
            for data,current_index,count in ite:
                sql = self.create_insert_header_sql()
                print('begin insert ' ,self.tbName,current_index,count)
                c.executemany(sql, data)
                conn.commit()
                total_insert = total_insert + count

            Log('[{0}] ({1}) : {2}'.format(databaseName,self.tbName,total_insert))

            if closeIdentity:
                c.execute('SET IDENTITY_INSERT '+self.tbName + " OFF ")
                conn.commit()
            


#将 excel 中提取的字符串  校正成 sqlserver 能正确插入的形式 

def adjustNoneString(excel_string):
    if excel_string == 'NULL' or excel_string == '':
        return None
    
    return excel_string
            

class ExcelExtractor():
        def __init__(self,filename):
            self.filename = filename
            self.book = xlrd.open_workbook(filename);
            self.sheets_name_dict = {}
            self.sheets_name_list = [] 
            self.sheets_header_dict = {} 
            self.sheets_header_list = {} 
            self.sheets_data_list = {} 
            for i,name in enumerate(self.book.sheet_names()):
                self.sheets_name_dict[name] = self.book.sheet_by_index(i)
                self.sheets_name_list.append(name)
                self.sheets_header_dict.update({name:self.extractSheetData_ColNamesList(i)})

        def convert2TableInfo(self):
            table_info_list = []
            for sheet_index,sheet_name in  enumerate(self.sheets_name_list):
                tbName = sheet_name
                header_list = self.sheets_header_dict[sheet_name]
                data_list = self.extractSheetData_RecordsList(sheet_index)

                table_info = Excel2TableInfo(tbName,header_list,data_list)
                table_info_list.append(table_info)

            return table_info_list

        def extractSheetData_ColNamesList(self,sheetIndex):
            colMapList=[];
            sheet=self.book.sheet_by_index(sheetIndex);        
            for y in range(0,sheet.ncols): #for each column
                    colMapList.append(sheet.cell_value(0,y))
            return colMapList;



        #获取每行的数据 放在一个 list[list] 里面
        def extractSheetData_RecordsList(self,sheetIndex,row_offset=1,col_offset=0):
                masterList=[];#this List stores all the records(dictionary form).
                sheet=self.book.sheet_by_index(sheetIndex);        
                maxrows=sheet.nrows;
                maxcols=sheet.ncols;
                print "Extracting data from Sheet:",sheetIndex;
                for x in range(row_offset,maxrows):
                    one_row_record_list = []
                    for y in range(col_offset,maxcols): #for each column
                        val = adjustNoneString(sheet.cell_value(x,y))
                        one_row_record_list.append(val);
                    masterList.append(tuple(one_row_record_list));#adding to masterList 
                return masterList;



def start_import(dbname,excelName):
    excel_inifo=ExcelExtractor(excelName);
    print "--------------";

    tablelist = excel_inifo.convert2TableInfo()
    for x in tablelist:
        # x.show_info()
        print "\n\n[[[[[begin import {0} {1}:{2}]]]]]".format(dbname,excelName,x.tbName);
        x.begin_insert(db.conn(),dbname)


        
if __name__ == '__main__':
    if not read_config.excelConfigs:
        print('the excelConfig is empty')
    else:
        for excel_config in read_config.excelConfigs:
            db_name = excel_config.db_name
            for excel_path in excel_config.excel_list:
                start_import(db_name,excel_path)
    

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import yaml
import os

class ExportConfig:
    def __init__(self,export_file,sql):
        self.export_file = export_file
        self.sql = sql

    def __repr__(self):
        return self.export_file +":"+ self.sql
    

DB_USER = None
DB_PWD = None
DB_HOST = None
DB_PREFIX = None
EXCEL_PATH = None
INSERT_COUNT = None


excelConfigs = []


with open('config.yaml') as f:
    res = yaml.load(f)

    DB_USER = str(res['db_info']['user']).strip()
    DB_PWD = str(res['db_info']['passwd']).strip()
    DB_HOST = str(res['db_info']['host']).strip()
    DB_PREFIX = str(res['db_info']['db_prefix']).strip()
    EXCEL_PATH=str(res['misc_config']['excel_path']).strip()
    INSERT_COUNT=int(res['misc_config']['insert_count'])


class DATABASE_EXCEL_CONFIG:
    def __init__(self,db_name,excel_list):
        self.db_name = db_name
        self.excel_list = excel_list

    def __repr__(self):
        return str(self.__dict__)


for dirpath,dirnames,filenames in os.walk(EXCEL_PATH):
    print(dirpath)
    _dir = os.path.split(dirpath)[1]
    if _dir.startswith('dr2_'):
        db_name = _dir
        excel_list = []
        for file in filenames:
            if file.endswith('xls') or file.endswith('xlsx'):
                fullpath=os.path.join(dirpath,file)
                excel_list.append(fullpath)

        tbConfig = DATABASE_EXCEL_CONFIG(db_name,excel_list)
        excelConfigs.append(tbConfig)



if __name__ == '__main__':
    print(DB_USER)
    print(DB_PWD)
    print(excelConfigs)
    print(DB_HOST)
    print(DB_PREFIX)
    print(EXCEL_PATH)
    print(INSERT_COUNT)





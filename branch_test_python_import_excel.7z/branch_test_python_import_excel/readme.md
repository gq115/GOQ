excel导表工具
================================

#环境
    python2.7 
    
#第三方库
    pymssql
    xlrd
    py2exe(仅用于用于打包成exe)


# 运行
    ./start.bat(python.exe 需要放在环境变量里面)
    或者
    python excelextractor.py
    

#打包成exe
    ./py2exe_setup.bat
    

#配置说明
    config.yaml
    
```
        db_info:
            host: 127.0.0.1
            user: sa
            passwd: 123
            db_prefix: dr2_


        misc_config:
            #excel文件位置
            excel_path: ./excel

            #一次插入数量
            insert_count: 1000
```

# 程序原理说明
    1. 自动检测 excel_path 中 具有 db_prefix 前缀的目录名中的所有xls,xlsx结尾文件 
    2. 根据excel文件里面sheetname对应数据库表名, 目录名对应数据库名字 ,开始批量插入
    3. *注意* 插入之前会清理原表里面的所有数据


#注意事项
    1. excel 配置中 NULL 和 空单元格,空字符串 都会被转换成 sqlserver 中的 NULL值插入数据库
    2. sqlserver 日期字段 如果插入不是NULL 而是空字符串会自动变为 1900.01.01 
	3. 
